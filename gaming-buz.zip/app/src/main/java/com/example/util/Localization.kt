package com.example.util

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
  HINDI("hi", "Hindi", "हिन्दी"),
  ENGLISH("en", "English", "English"),
  BANGLA("bn", "Bangla", "বাংলা")
}

object Localization {
  private val translations = mapOf(
    // App & Header
    "app_name" to mapOf(
      AppLanguage.HINDI to "गेमिंग बज",
      AppLanguage.ENGLISH to "Gaming Buz",
      AppLanguage.BANGLA to "গেমিং বাজ"
    ),
    "cric_news" to mapOf(
      AppLanguage.HINDI to "गेमिंग बज",
      AppLanguage.ENGLISH to "Gaming Buz",
      AppLanguage.BANGLA to "গেমিং বাজ"
    ),
    "tagline" to mapOf(
      AppLanguage.HINDI to "भारत का विश्वसनीय क्रिकेट न्यूज़ नेटवर्क",
      AppLanguage.ENGLISH to "India's Trusted Cricket News Network",
      AppLanguage.BANGLA to "ভারতের বিশ্বস্ত ক্রিকেট নিউজ নেটওয়ার্ক"
    ),

    // Navigation Tabs
    "tab_top_news" to mapOf(
      AppLanguage.HINDI to "टॉप न्यूज़",
      AppLanguage.ENGLISH to "Top News",
      AppLanguage.BANGLA to "শীর্ষ খবর"
    ),
    "tab_live_score" to mapOf(
      AppLanguage.HINDI to "लाइव स्कोर",
      AppLanguage.ENGLISH to "Live Score",
      AppLanguage.BANGLA to "লাইভ স্কোর"
    ),
    "tab_team_india" to mapOf(
      AppLanguage.HINDI to "टीम इंडिया",
      AppLanguage.ENGLISH to "Team India",
      AppLanguage.BANGLA to "টিম ইন্ডিয়া"
    ),
    "tab_ipl" to mapOf(
      AppLanguage.HINDI to "आईपीएल 2025",
      AppLanguage.ENGLISH to "IPL 2025",
      AppLanguage.BANGLA to "আইপিএল ২০২৫"
    ),
    "tab_domestic" to mapOf(
      AppLanguage.HINDI to "घरेलू क्रिकेट",
      AppLanguage.ENGLISH to "Domestic",
      AppLanguage.BANGLA to "ঘরোয়া ক্রিকেট"
    ),
    "tab_videos" to mapOf(
      AppLanguage.HINDI to "वीडियो",
      AppLanguage.ENGLISH to "Videos",
      AppLanguage.BANGLA to "ভিডিও"
    ),

    // Bottom Navigation
    "nav_home" to mapOf(
      AppLanguage.HINDI to "होम",
      AppLanguage.ENGLISH to "Home",
      AppLanguage.BANGLA to "হোম"
    ),
    "nav_news" to mapOf(
      AppLanguage.HINDI to "न्यूज़",
      AppLanguage.ENGLISH to "News",
      AppLanguage.BANGLA to "খবর"
    ),
    "nav_live" to mapOf(
      AppLanguage.HINDI to "लाइव स्कोर",
      AppLanguage.ENGLISH to "Live Score",
      AppLanguage.BANGLA to "লাইভ স্কোর"
    ),
    "nav_videos" to mapOf(
      AppLanguage.HINDI to "वीडियो",
      AppLanguage.ENGLISH to "Videos",
      AppLanguage.BANGLA to "ভিডিও"
    ),
    "nav_more" to mapOf(
      AppLanguage.HINDI to "अधिक",
      AppLanguage.ENGLISH to "More",
      AppLanguage.BANGLA to "আরও"
    ),

    // Common Sections
    "view_all" to mapOf(
      AppLanguage.HINDI to "सभी देखें",
      AppLanguage.ENGLISH to "View All",
      AppLanguage.BANGLA to "সব দেখুন"
    ),
    "match_center" to mapOf(
      AppLanguage.HINDI to "मैच सेंटर",
      AppLanguage.ENGLISH to "Match Center",
      AppLanguage.BANGLA to "ম্যাচ সেন্টার"
    ),
    "upcoming" to mapOf(
      AppLanguage.HINDI to "आगामी",
      AppLanguage.ENGLISH to "Upcoming",
      AppLanguage.BANGLA to "আসন্ন"
    ),
    "results" to mapOf(
      AppLanguage.HINDI to "परिणाम",
      AppLanguage.ENGLISH to "Results",
      AppLanguage.BANGLA to "ফলাফল"
    ),
    "breaking_news" to mapOf(
      AppLanguage.HINDI to "ब्रेकिंग न्यूज़",
      AppLanguage.ENGLISH to "Breaking News",
      AppLanguage.BANGLA to "ব্রেকিং নিউজ"
    ),
    "search_hint" to mapOf(
      AppLanguage.HINDI to "खिलाड़ी, टीम या सीरीज़ खोजें...",
      AppLanguage.ENGLISH to "Search player, team or series...",
      AppLanguage.BANGLA to "খেলোয়াড়, দল বা সিরিজ অনুসন্ধান করুন..."
    ),
    "bookmarks" to mapOf(
      AppLanguage.HINDI to "बुकमार्क्स",
      AppLanguage.ENGLISH to "Bookmarks",
      AppLanguage.BANGLA to "বুকমার্ক"
    ),
    "no_bookmarks" to mapOf(
      AppLanguage.HINDI to "कोई बुकमार्क की गई खबर नहीं है।",
      AppLanguage.ENGLISH to "No bookmarked news found.",
      AppLanguage.BANGLA to "কোনো বুকমার্ক করা খবর নেই।"
    ),
    "notifications" to mapOf(
      AppLanguage.HINDI to "सूचनाएं",
      AppLanguage.ENGLISH to "Notifications",
      AppLanguage.BANGLA to "বিজ্ঞপ্তি"
    ),
    "select_language" to mapOf(
      AppLanguage.HINDI to "भाषा चुनें / Select Language",
      AppLanguage.ENGLISH to "Select Language",
      AppLanguage.BANGLA to "ভাষা নির্বাচন করুন"
    ),
    "dark_mode" to mapOf(
      AppLanguage.HINDI to "डार्क मोड",
      AppLanguage.ENGLISH to "Dark Mode",
      AppLanguage.BANGLA to "ডার্ক মোড"
    ),

    // Categories
    "cat_team_india" to mapOf(
      AppLanguage.HINDI to "टीम इंडिया",
      AppLanguage.ENGLISH to "Team India",
      AppLanguage.BANGLA to "টিম ইন্ডিয়া"
    ),
    "cat_international" to mapOf(
      AppLanguage.HINDI to "अंतरराष्ट्रीय",
      AppLanguage.ENGLISH to "International",
      AppLanguage.BANGLA to "আন্তর্জাতিক"
    ),
    "cat_domestic" to mapOf(
      AppLanguage.HINDI to "घरेलू क्रिकेट",
      AppLanguage.ENGLISH to "Domestic",
      AppLanguage.BANGLA to "ঘরোয়া ক্রিকেট"
    ),
    "cat_ipl" to mapOf(
      AppLanguage.HINDI to "आईपीएल",
      AppLanguage.ENGLISH to "IPL",
      AppLanguage.BANGLA to "আইপিএল"
    ),
    "cat_womens" to mapOf(
      AppLanguage.HINDI to "महिला क्रिकेट",
      AppLanguage.ENGLISH to "Women's Cricket",
      AppLanguage.BANGLA to "মহিলা ক্রিকেট"
    ),
    "cat_preview" to mapOf(
      AppLanguage.HINDI to "मैच प्रीव्यू",
      AppLanguage.ENGLISH to "Match Preview",
      AppLanguage.BANGLA to "ম্যাচ প্রিভিউ"
    ),
    "cat_records" to mapOf(
      AppLanguage.HINDI to "रिकॉर्ड्स",
      AppLanguage.ENGLISH to "Records",
      AppLanguage.BANGLA to "রেকর্ড"
    ),

    // Auth & Roles
    "login_role_title" to mapOf(
      AppLanguage.HINDI to "लॉगिन भूमिका चुनें",
      AppLanguage.ENGLISH to "Select Login Role",
      AppLanguage.BANGLA to "লগইন ভূমিকা নির্বাচন করুন"
    ),
    "role_admin" to mapOf(
      AppLanguage.HINDI to "डेवलपर / एडमिन लॉगिन",
      AppLanguage.ENGLISH to "Developer / Admin Login",
      AppLanguage.BANGLA to "ডেভেলপার / অ্যাডমিন লগইন"
    ),
    "role_user" to mapOf(
      AppLanguage.HINDI to "उपयोगकर्ता लॉगिन",
      AppLanguage.ENGLISH to "Normal User Login",
      AppLanguage.BANGLA to "সাধারণ ব্যবহারকারী লগইন"
    ),
    "admin_role_notice" to mapOf(
      AppLanguage.HINDI to "सुरक्षा सूचना: केवल अधिकृत व्यवस्थापक ही एडमिन पैनल में प्रवेश कर सकते हैं।",
      AppLanguage.ENGLISH to "Security Notice: Only authorized administrators can access the admin dashboard.",
      AppLanguage.BANGLA to "নিরাপত্তা বিজ্ঞপ্তি: শুধুমাত্র অনুমোদিত অ্যাডমিনেরাই অ্যাডমিন প্যানেলে প্রবেশ করতে পারেন।"
    ),
    "login_with_google" to mapOf(
      AppLanguage.HINDI to "Google से जारी रखें",
      AppLanguage.ENGLISH to "Continue with Google",
      AppLanguage.BANGLA to "Google দিয়ে চালিয়ে যান"
    ),
    "login_with_phone" to mapOf(
      AppLanguage.HINDI to "फोन नंबर से लॉगिन करें",
      AppLanguage.ENGLISH to "Login with Phone Number",
      AppLanguage.BANGLA to "ফোন নম্বর দিয়ে লগইন করুন"
    ),
    "login_with_email" to mapOf(
      AppLanguage.HINDI to "ईमेल से लॉगिन करें",
      AppLanguage.ENGLISH to "Login with Email",
      AppLanguage.BANGLA to "ইমেল দিয়ে লগইন করুন"
    ),
    "register_new" to mapOf(
      AppLanguage.HINDI to "नया खाता बनाएं",
      AppLanguage.ENGLISH to "Register New Account",
      AppLanguage.BANGLA to "নতুন অ্যাকাউন্ট তৈরি করুন"
    ),
    "forgot_password" to mapOf(
      AppLanguage.HINDI to "पासवर्ड भूल गए?",
      AppLanguage.ENGLISH to "Forgot Password?",
      AppLanguage.BANGLA to "পাসওয়ার্ড ভুলে গেছেন?"
    ),
    "logout" to mapOf(
      AppLanguage.HINDI to "लॉगआउट",
      AppLanguage.ENGLISH to "Logout",
      AppLanguage.BANGLA to "লগআউট"
    ),
    "phone_number_label" to mapOf(
      AppLanguage.HINDI to "मोबाइल नंबर (+91)",
      AppLanguage.ENGLISH to "Phone Number (+91)",
      AppLanguage.BANGLA to "মোবাইল নম্বর (+91)"
    ),
    "send_otp" to mapOf(
      AppLanguage.HINDI to "ओटीपी भेजें",
      AppLanguage.ENGLISH to "Send OTP",
      AppLanguage.BANGLA to "ওটিপি পাঠান"
    ),
    "enter_otp" to mapOf(
      AppLanguage.HINDI to "6 अंकों का ओटीपी दर्ज करें",
      AppLanguage.ENGLISH to "Enter 6-digit OTP",
      AppLanguage.BANGLA to "৬ অঙ্কের ওটিপি লিখুন"
    ),
    "verify_otp" to mapOf(
      AppLanguage.HINDI to "ओटीपी सत्यापित करें",
      AppLanguage.ENGLISH to "Verify OTP",
      AppLanguage.BANGLA to "ওটিপি যাচাই করুন"
    ),
    "email_label" to mapOf(
      AppLanguage.HINDI to "ईमेल पता",
      AppLanguage.ENGLISH to "Email Address",
      AppLanguage.BANGLA to "ইমেল ঠিকানা"
    ),
    "password_label" to mapOf(
      AppLanguage.HINDI to "पासवर्ड",
      AppLanguage.ENGLISH to "Password",
      AppLanguage.BANGLA to "পাসওয়ার্ড"
    ),
    "sign_in_button" to mapOf(
      AppLanguage.HINDI to "लॉगिन करें",
      AppLanguage.ENGLISH to "Sign In",
      AppLanguage.BANGLA to "লগইন করুন"
    ),

    // Admin Dashboard
    "admin_dashboard" to mapOf(
      AppLanguage.HINDI to "एडमिन न्यूज़ डैशबोर्ड",
      AppLanguage.ENGLISH to "Admin News Dashboard",
      AppLanguage.BANGLA to "অ্যাডমিন নিউজ ড্যাশবোর্ড"
    ),
    "add_news" to mapOf(
      AppLanguage.HINDI to "नई खबर जोड़ें",
      AppLanguage.ENGLISH to "Add New News",
      AppLanguage.BANGLA to "নতুন খবর যোগ করুন"
    ),
    "headline_label" to mapOf(
      AppLanguage.HINDI to "खबर की हेडलाइन (Headline)",
      AppLanguage.ENGLISH to "News Headline",
      AppLanguage.BANGLA to "খবরের শিরোনাম"
    ),
    "content_label" to mapOf(
      AppLanguage.HINDI to "खबर का पूरा विवरण (Details)",
      AppLanguage.ENGLISH to "Full News Content",
      AppLanguage.BANGLA to "খবরের বিস্তারিত বিবরণ"
    ),
    "image_url_label" to mapOf(
      AppLanguage.HINDI to "मुख्य फोटो URL (Image)",
      AppLanguage.ENGLISH to "Featured Image URL",
      AppLanguage.BANGLA to "প্রধান ছবির URL"
    ),
    "publish" to mapOf(
      AppLanguage.HINDI to "प्रकाशित करें (Publish)",
      AppLanguage.ENGLISH to "Publish",
      AppLanguage.BANGLA to "প্রকাশ করুন"
    ),
    "save_draft" to mapOf(
      AppLanguage.HINDI to "ड्राफ्ट में सेव करें",
      AppLanguage.ENGLISH to "Save Draft",
      AppLanguage.BANGLA to "ড্রাফটে সংরক্ষণ করুন"
    ),
    "breaking_news_toggle" to mapOf(
      AppLanguage.HINDI to "ब्रेकिंग न्यूज़ के रूप में चिह्नित करें",
      AppLanguage.ENGLISH to "Mark as Breaking News",
      AppLanguage.BANGLA to "ব্রেকিং নিউজ হিসেবে চিহ্নিত করুন"
    ),
    "delete" to mapOf(
      AppLanguage.HINDI to "हटाएं (Delete)",
      AppLanguage.ENGLISH to "Delete",
      AppLanguage.BANGLA to "মুছুন"
    ),

    // Legal & Info
    "about_us" to mapOf(
      AppLanguage.HINDI to "हमारे बारे में",
      AppLanguage.ENGLISH to "About Us",
      AppLanguage.BANGLA to "আমাদের সম্পর্কে"
    ),
    "privacy_policy" to mapOf(
      AppLanguage.HINDI to "गोपनीयता नीति (Privacy Policy)",
      AppLanguage.ENGLISH to "Privacy Policy",
      AppLanguage.BANGLA to "গোপনীয়তা নীতি"
    ),
    "terms_conditions" to mapOf(
      AppLanguage.HINDI to "नियम और शर्तें",
      AppLanguage.ENGLISH to "Terms & Conditions",
      AppLanguage.BANGLA to "শর্তাবলী"
    ),
    "contact_us" to mapOf(
      AppLanguage.HINDI to "संपर्क करें",
      AppLanguage.ENGLISH to "Contact Us",
      AppLanguage.BANGLA to "যোগাযোগ করুন"
    ),
    "share_news" to mapOf(
      AppLanguage.HINDI to "शेयर करें",
      AppLanguage.ENGLISH to "Share",
      AppLanguage.BANGLA to "শেয়ার করুন"
    )
  )

  fun get(key: String, lang: AppLanguage = AppLanguage.HINDI): String {
    return translations[key]?.get(lang) ?: translations[key]?.get(AppLanguage.ENGLISH) ?: key
  }
}
