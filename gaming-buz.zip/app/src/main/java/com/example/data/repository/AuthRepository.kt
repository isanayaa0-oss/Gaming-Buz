package com.example.data.repository

import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class AuthRepository {

  // Authorized Admin Accounts whitelist for backend role verification
  private val authorizedAdminEmails = setOf(
    "admin@gamingbuz.com",
    "earnteck@gmail.com",
    "developer@gamingbuz.com"
  )

  private val _currentUser = MutableStateFlow<UserProfile?>(null)
  val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

  private val _generatedOtp = MutableStateFlow<String?>("123456")
  val generatedOtp: StateFlow<String?> = _generatedOtp.asStateFlow()

  fun loginWithGoogle(email: String, roleRequested: UserRole): Result<UserProfile> {
    val emailClean = email.trim().lowercase()
    if (roleRequested == UserRole.ADMIN && !authorizedAdminEmails.contains(emailClean)) {
      return Result.failure(
        SecurityException("ACCESS DENIED: '$email' is not registered as an authorized Gaming Buz administrator.")
      )
    }

    val user = UserProfile(
      uid = "goog_" + UUID.randomUUID().toString().take(8),
      displayName = emailClean.substringBefore("@").replaceFirstChar { it.uppercase() },
      email = emailClean,
      phoneNumber = null,
      role = if (roleRequested == UserRole.ADMIN) UserRole.ADMIN else UserRole.NORMAL_USER,
      isVerified = true
    )
    _currentUser.value = user
    return Result.success(user)
  }

  fun sendOtp(phoneNumber: String): Result<String> {
    if (phoneNumber.length < 10) {
      return Result.failure(IllegalArgumentException("Please enter a valid 10-digit mobile number"))
    }
    // Simulation / default test OTP 123456
    val otp = "123456"
    _generatedOtp.value = otp
    return Result.success("OTP sent successfully to +91 $phoneNumber. (Verification Code: $otp)")
  }

  fun verifyOtp(phoneNumber: String, enteredOtp: String, roleRequested: UserRole): Result<UserProfile> {
    if (enteredOtp.trim() != _generatedOtp.value) {
      return Result.failure(IllegalArgumentException("Invalid or expired OTP. Please check the code."))
    }
    if (roleRequested == UserRole.ADMIN) {
      // In production, only whitelisted phone numbers are granted ADMIN role
      val authorizedAdminPhones = setOf("9876543210", "9999999999")
      if (!authorizedAdminPhones.contains(phoneNumber.trim())) {
        return Result.failure(
          SecurityException("ACCESS DENIED: Phone number +91 $phoneNumber is not an authorized administrator.")
        )
      }
    }

    val user = UserProfile(
      uid = "phone_" + UUID.randomUUID().toString().take(8),
      displayName = "Fan +91" + phoneNumber.takeLast(4),
      email = null,
      phoneNumber = "+91 $phoneNumber",
      role = if (roleRequested == UserRole.ADMIN) UserRole.ADMIN else UserRole.NORMAL_USER,
      isVerified = true
    )
    _currentUser.value = user
    return Result.success(user)
  }

  fun loginWithEmail(email: String, password: String, roleRequested: UserRole): Result<UserProfile> {
    val emailClean = email.trim().lowercase()
    if (emailClean.isBlank() || !emailClean.contains("@")) {
      return Result.failure(IllegalArgumentException("Please enter a valid email address"))
    }
    if (password.length < 6) {
      return Result.failure(IllegalArgumentException("Password must be at least 6 characters"))
    }

    if (roleRequested == UserRole.ADMIN) {
      if (!authorizedAdminEmails.contains(emailClean)) {
        return Result.failure(
          SecurityException("ACCESS DENIED: '$emailClean' does not possess administrative privileges on the server.")
        )
      }
    }

    val user = UserProfile(
      uid = "usr_" + UUID.randomUUID().toString().take(8),
      displayName = emailClean.substringBefore("@").replaceFirstChar { it.uppercase() },
      email = emailClean,
      phoneNumber = null,
      role = if (roleRequested == UserRole.ADMIN) UserRole.ADMIN else UserRole.NORMAL_USER,
      isVerified = true
    )
    _currentUser.value = user
    return Result.success(user)
  }

  fun register(name: String, email: String, password: String): Result<UserProfile> {
    if (name.isBlank()) return Result.failure(IllegalArgumentException("Name cannot be empty"))
    if (!email.contains("@")) return Result.failure(IllegalArgumentException("Invalid email format"))
    if (password.length < 6) return Result.failure(IllegalArgumentException("Password too short"))

    val user = UserProfile(
      uid = "usr_" + UUID.randomUUID().toString().take(8),
      displayName = name.trim(),
      email = email.trim().lowercase(),
      phoneNumber = null,
      role = UserRole.NORMAL_USER,
      isVerified = true
    )
    _currentUser.value = user
    return Result.success(user)
  }

  fun resetPassword(email: String): Result<String> {
    if (!email.contains("@")) return Result.failure(IllegalArgumentException("Invalid email"))
    return Result.success("Password reset instructions sent to $email.")
  }

  fun logout() {
    _currentUser.value = null
  }
}
