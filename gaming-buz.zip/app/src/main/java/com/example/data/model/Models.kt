package com.example.data.model

import com.example.util.AppLanguage

enum class NewsCategory(val id: String, val translationKey: String) {
  TOP_NEWS("top_news", "tab_top_news"),
  TEAM_INDIA("team_india", "cat_team_india"),
  INTERNATIONAL("international", "cat_international"),
  DOMESTIC("domestic", "cat_domestic"),
  IPL("ipl", "cat_ipl"),
  WOMENS("womens", "cat_womens"),
  PREVIEWS("previews", "cat_preview"),
  RECORDS("records", "cat_records")
}

data class NewsArticle(
  val id: String,
  val titleHi: String,
  val titleEn: String,
  val titleBn: String,
  val contentHi: String,
  val contentEn: String,
  val contentBn: String,
  val imageUrl: String,
  val category: NewsCategory,
  val timeAgo: String,
  val dateFormatted: String,
  val author: String = "Gaming Buz Desk",
  val isBreaking: Boolean = false,
  val isFeatured: Boolean = false,
  val isDraft: Boolean = false,
  val viewsCount: Int = 1200,
  val relatedVideoId: String? = null
) {
  fun getTitle(lang: AppLanguage): String = when (lang) {
    AppLanguage.HINDI -> titleHi
    AppLanguage.ENGLISH -> titleEn
    AppLanguage.BANGLA -> titleBn
  }

  fun getContent(lang: AppLanguage): String = when (lang) {
    AppLanguage.HINDI -> contentHi
    AppLanguage.ENGLISH -> contentEn
    AppLanguage.BANGLA -> contentBn
  }
}

enum class MatchFormat {
  T20, ODI, TEST
}

enum class MatchStatus {
  LIVE, UPCOMING, FINISHED
}

data class CricketScorecardBatter(
  val name: String,
  val runs: Int,
  val balls: Int,
  val fours: Int,
  val sixes: Int,
  val strikeRate: Double,
  val isStriker: Boolean = false,
  val dismissalInfo: String = "not out"
)

data class CricketScorecardBowler(
  val name: String,
  val overs: Double,
  val maidens: Int,
  val runs: Int,
  val wickets: Int,
  val economy: Double
)

data class CricketTeamInfo(
  val shortName: String,
  val fullName: String,
  val score: String,
  val overs: String,
  val flagEmoji: String,
  val logoUrl: String? = null
)

data class CricketMatch(
  val id: String,
  val title: String,
  val seriesName: String,
  val format: MatchFormat,
  val status: MatchStatus,
  val team1: CricketTeamInfo,
  val team2: CricketTeamInfo,
  val statusMessage: String,
  val tossDetails: String,
  val venue: String,
  val matchTime: String,
  val batsmen: List<CricketScorecardBatter> = emptyList(),
  val bowlers: List<CricketScorecardBowler> = emptyList(),
  val recentOvers: String = "1 . 4 6 1 2"
)

data class CricketVideo(
  val id: String,
  val titleHi: String,
  val titleEn: String,
  val titleBn: String,
  val duration: String,
  val thumbnailUrl: String,
  val youtubeVideoId: String,
  val category: String,
  val timeAgo: String
) {
  fun getTitle(lang: AppLanguage): String = when (lang) {
    AppLanguage.HINDI -> titleHi
    AppLanguage.ENGLISH -> titleEn
    AppLanguage.BANGLA -> titleBn
  }
}

enum class UserRole {
  ADMIN,
  NORMAL_USER
}

data class UserProfile(
  val uid: String,
  val displayName: String,
  val email: String?,
  val phoneNumber: String?,
  val role: UserRole,
  val isVerified: Boolean = false
)

data class IplTeamStanding(
  val rank: Int,
  val team: String,
  val matches: Int,
  val won: Int,
  val lost: Int,
  val nrr: String,
  val points: Int
)

data class PlayerStatLeader(
  val playerName: String,
  val team: String,
  val statValue: String,
  val label: String
)
