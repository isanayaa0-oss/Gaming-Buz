package com.example.data

import com.example.model.AdMobStats
import com.example.model.AppUser
import com.example.model.BatsmanScore
import com.example.model.CapHolder
import com.example.model.CricketTeam
import com.example.model.MatchScore
import com.example.model.NewsArticle
import com.example.model.PointsTableRow
import com.example.model.SectionItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class CricketRepository {

    // 1. Dynamic Sections
    private val _sections = MutableStateFlow(
        listOf(
            SectionItem(
                id = "sec_1",
                nameEn = "Top News",
                nameHi = "टॉप न्यूज़",
                nameBn = "টপ নিউজ",
                tagEn = "Featured",
                tagHi = "फीचर्ड",
                tagBn = "ফিচার্ড",
                iconName = "star",
                colorHex = "#0052FF",
                slug = "/top-news",
                isEnabled = true,
                order = 0
            ),
            SectionItem(
                id = "sec_2",
                nameEn = "Live Score",
                nameHi = "लाइव स्कोर",
                nameBn = "লাইভ স্কোর",
                tagEn = "Live",
                tagHi = "लाइव",
                tagBn = "লাইভ",
                iconName = "live",
                colorHex = "#E53935",
                slug = "/live-score",
                isEnabled = true,
                order = 1
            ),
            SectionItem(
                id = "sec_3",
                nameEn = "Team India",
                nameHi = "टीम इंडिया",
                nameBn = "টিম ইন্ডিয়া",
                tagEn = "Cricket",
                tagHi = "क्रिकेट",
                tagBn = "ক্রিকেট",
                iconName = "sports_cricket",
                colorHex = "#0052FF",
                slug = "/team-india",
                isEnabled = true,
                order = 2
            ),
            SectionItem(
                id = "sec_4",
                nameEn = "IPL",
                nameHi = "आईपीएल",
                nameBn = "আইপিএল",
                tagEn = "League",
                tagHi = "लीग",
                tagBn = "লিগ",
                iconName = "trophy",
                colorHex = "#FF8C00",
                slug = "/ipl",
                isEnabled = true,
                order = 3
            ),
            SectionItem(
                id = "sec_5",
                nameEn = "Domestic",
                nameHi = "घरेलू",
                nameBn = "ঘরোয়া",
                tagEn = "Cricket",
                tagHi = "क्रिकेट",
                tagBn = "ক্রিকেট",
                iconName = "shield",
                colorHex = "#4F46E5",
                slug = "/domestic",
                isEnabled = true,
                order = 4
            ),
            SectionItem(
                id = "sec_6",
                nameEn = "Videos",
                nameHi = "वीडियो",
                nameBn = "ভিডিও",
                tagEn = "Media",
                tagHi = "मीडिया",
                tagBn = "মিডিয়া",
                iconName = "video",
                colorHex = "#7C3AED",
                slug = "/videos",
                isEnabled = false,
                order = 5
            )
        )
    )
    val sections: StateFlow<List<SectionItem>> = _sections.asStateFlow()

    // 2. News Articles
    private val _news = MutableStateFlow(
        listOf(
            NewsArticle(
                id = "n_1",
                titleEn = "Rohit Sharma's magnificent knock of 91 runs",
                titleHi = "Rohit Sharma ki shandar 91 run ki pari",
                titleBn = "রোহিত শর্মার দুর্দান্ত ৯১ রানের ইনিংস",
                contentEn = "India skipper Rohit Sharma led from the front with a blistering 91 off 60 balls, hitting 8 boundaries and 4 towering sixes. His aggressive approach set the tone for India's massive chase against the West Indies at the Wankhede.",
                contentHi = "भारतीय कप्तान रोहित शर्मा ने सिर्फ 60 गेंदों में 91 रनों की तूफानी पारी खेली। उनकी पारी में 8 चौके और 4 गगनचुंबी छक्के शामिल रहे। वानखेड़े स्टेडियम में फैंस उनके शॉट्स देखकर झूम उठे।",
                contentBn = "ভারত অধিনায়ক রোহিত শর্মা ৬০ বলে ৯১ রানের বিধ্বংসী ইনিংস খেলেছেন। তাঁর ইনিংসে ছিল ৮টি চার ও ৪টি দানবীয় ছক্কা। তাঁর এই ইনিংস ভারতকে সুবিধাজনক অবস্থানে রেখেছে।",
                timeAgoEn = "5 minutes ago",
                timeAgoHi = "5 minute pehle",
                timeAgoBn = "৫ মিনিট আগে",
                views = "1.2k views",
                category = "Top News",
                isBreaking = true,
                author = "Gaming Buz News Desk",
                thumbnailType = "rohit"
            ),
            NewsArticle(
                id = "n_2",
                titleEn = "Kohli plays resilient 72, India inches closer to victory",
                titleHi = "Kohli ne khele 72 run, India jeet ke kareeb",
                titleBn = "কোহলির অসাধারণ ৭২ রান, জয়ের দোরগোড়ায় ভারত",
                contentEn = "Virat Kohli anchored the innings with composure, notching up 72 off 54 deliveries. His masterclass in strike rotation and boundary placement has brought India within striking distance of the target.",
                contentHi = "विराट कोहली ने 54 गेंदों पर धैर्य और आक्रामकता का शानदार मिश्रण दिखाते हुए 72 रन बनाए। लगातार सिंगल्स और सटीक बाउंड्रीज के दम पर उन्होंने भारत को जीत की चौखट पर खड़ा कर दिया है।",
                contentBn = "বিরাট কোহলি ৫৪ বলে ৭২ রান করে ক্রিজে অবিচল রয়েছেন। তাঁর দুর্দান্ত ব্যাটিংয়ে ভারত জয়ের দিকে এগিয়ে চলেছে।",
                timeAgoEn = "12 minutes ago",
                timeAgoHi = "12 minute pehle",
                timeAgoBn = "১২ মিনিট আগে",
                views = "980 views",
                category = "Top News",
                isBreaking = false,
                author = "Senior Cricket Analyst",
                thumbnailType = "kohli"
            ),
            NewsArticle(
                id = "n_3",
                titleEn = "West Indies sets 326 target, India under pressure",
                titleHi = "West Indies ko 326 ka target, India dabav mein",
                titleBn = "ওয়েস্ট ইন্ডিজের ৩২৬ রানের লক্ষ্য, চাপে ভারত",
                contentEn = "Earlier in the day, the West Indies powerhouse lineup posted a steep total of 325/8 in their allotted 50 overs. High-voltage power hitting in the death overs posed a serious challenge for the Indian bowlers.",
                contentHi = "वेस्टइंडीज ने पहले बल्लेबाजी करते हुए 50 ओवर में 8 विकेट के नुकसान पर 325 रन बनाए। डेथ ओवर्स में तूफानी बल्लेबाजी ने भारतीय गेंदबाजों पर दबाव बना दिया था।",
                contentBn = "প্রথমে ব্যাট করে ওয়েস্ট ইন্ডিজ নির্ধারিত ৫০ ওভারে ৮ উইকেটে ৩২৫ রান তোলে। শেষ ওভারগুলোতে বিধ্বংসী ব্যাটিং ভারতীয় বোলারদের কঠিন পরীক্ষার মুখে ফেলে।",
                timeAgoEn = "25 minutes ago",
                timeAgoHi = "25 minute pehle",
                timeAgoBn = "২৫ মিনিট আগে",
                views = "756 views",
                category = "Top News",
                isBreaking = false,
                author = "Gaming Buz Desk",
                thumbnailType = "stadium"
            ),
            NewsArticle(
                id = "n_4",
                titleEn = "IPL 2025 Mega Auction: Big retentions and purse details",
                titleHi = "IPL 2025 मेगा ऑक्शन: प्रमुख रिटेंशन और पर्स का पूरा गणित",
                titleBn = "আইপিএল মেগা নিলাম: বড় বড় রিটেনশন ও টাকার হিসাব",
                contentEn = "Franchises announce key retentions as the road to the next edition of IPL heats up. Top stars make headlines with historic bids and tactical changes in team composition.",
                contentHi = "आईपीएल की सभी 10 टीमों ने अपनी रणनीतियों का खुलासा कर दिया है। रिटेन किए गए खिलाड़ियों की लिस्ट और नए पर्स के साथ ऑक्शन काफी रोमांचक होने वाला है।",
                contentBn = "আইপিএলের ফ্র্যাঞ্চাইজিগুলো রিটেন করা খেলোয়াড়দের তালিকা প্রকাশ করেছে। আসন্ন আসরের নিলাম ঘিরে উত্তেজনা তুঙ্গে।",
                timeAgoEn = "1 hour ago",
                timeAgoHi = "1 ghanta pehle",
                timeAgoBn = "১ ঘণ্টা আগে",
                views = "3.4k views",
                category = "IPL",
                isBreaking = true,
                author = "IPL Special Desk",
                thumbnailType = "ipl"
            )
        )
    )
    val news: StateFlow<List<NewsArticle>> = _news.asStateFlow()

    // 3. Live Match Score
    private val _liveMatch = MutableStateFlow(
        MatchScore(
            id = "match_ind_wi",
            team1Name = "INDIA",
            team1Code = "IND",
            team1FlagEmoji = "🇮🇳",
            team1Score = "287/4",
            team1Overs = "48.2",
            team2Name = "WEST INDIES",
            team2Code = "WI",
            team2FlagEmoji = "🌴",
            team2Score = "325/8",
            team2Overs = "50.0",
            target = 326,
            needRuns = 38,
            needBalls = 10,
            batsman1 = BatsmanScore(name = "Kohli", runs = 72, balls = 54, fours = 6, sixes = 2),
            batsman2 = BatsmanScore(name = "Rohit", runs = 91, balls = 60, fours = 8, sixes = 4),
            status = "LIVE",
            venue = "Wankhede Stadium, Mumbai",
            matchType = "2nd ODI (D/N)"
        )
    )
    val liveMatch: StateFlow<MatchScore> = _liveMatch.asStateFlow()

    // 4. IPL Lifetime & Seasonal Data
    private val pointsTableLifetime = listOf(
        PointsTableRow(1, "CSK", "Chennai Super Kings", 14, 9, 5, 18, "+0.80", 0xFFF9CD05, 0xFF0052FF),
        PointsTableRow(2, "MI", "Mumbai Indians", 14, 8, 6, 16, "+0.52", 0xFF004BA0, 0xFFD1AB3E),
        PointsTableRow(3, "RR", "Rajasthan Royals", 14, 8, 6, 16, "+0.35", 0xFFEA1A85, 0xFF254AA5),
        PointsTableRow(4, "KKR", "Kolkata Knight Riders", 14, 7, 7, 14, "+0.10", 0xFF3A225D, 0xFFB3A125),
        PointsTableRow(5, "GT", "Gujarat Titans", 14, 6, 8, 12, "-0.22", 0xFF1B2133, 0xFFE0C475)
    )

    private val pointsTable2024 = listOf(
        PointsTableRow(1, "KKR", "Kolkata Knight Riders", 14, 9, 3, 20, "+1.42", 0xFF3A225D, 0xFFB3A125),
        PointsTableRow(2, "SRH", "Sunrisers Hyderabad", 14, 8, 5, 17, "+0.41", 0xFFFF822A, 0xFF000000),
        PointsTableRow(3, "RR", "Rajasthan Royals", 14, 8, 5, 17, "+0.27", 0xFFEA1A85, 0xFF254AA5),
        PointsTableRow(4, "RCB", "Royal Challengers Bengaluru", 14, 7, 7, 14, "+0.45", 0xFFEC1C24, 0xFF000000),
        PointsTableRow(5, "CSK", "Chennai Super Kings", 14, 7, 7, 14, "+0.39", 0xFFF9CD05, 0xFF0052FF)
    )

    private val pointsTable2023 = listOf(
        PointsTableRow(1, "GT", "Gujarat Titans", 14, 10, 4, 20, "+0.80", 0xFF1B2133, 0xFFE0C475),
        PointsTableRow(2, "CSK", "Chennai Super Kings", 14, 8, 5, 17, "+0.65", 0xFFF9CD05, 0xFF0052FF),
        PointsTableRow(3, "LSG", "Lucknow Super Giants", 14, 8, 5, 17, "+0.28", 0xFF0057B8, 0xFFF47920),
        PointsTableRow(4, "MI", "Mumbai Indians", 14, 8, 6, 16, "-0.04", 0xFF004BA0, 0xFFD1AB3E),
        PointsTableRow(5, "RR", "Rajasthan Royals", 14, 7, 7, 14, "+0.14", 0xFFEA1A85, 0xFF254AA5)
    )

    fun getPointsTableForSeason(season: String): List<PointsTableRow> {
        return when (season) {
            "2024" -> pointsTable2024
            "2023" -> pointsTable2023
            else -> pointsTableLifetime
        }
    }

    val orangeCapLifetime = CapHolder("Orange Cap", "Virat Kohli", "783 Runs", "RCB")
    val purpleCapLifetime = CapHolder("Purple Cap", "Harshal Patel", "24 Wickets", "PBKS")

    val all10Teams = listOf(
        CricketTeam("CSK", "Chennai Super Kings", 0xFFF9CD05, 0xFF0052FF, 5),
        CricketTeam("MI", "Mumbai Indians", 0xFF004BA0, 0xFFD1AB3E, 5),
        CricketTeam("RR", "Rajasthan Royals", 0xFFEA1A85, 0xFF254AA5, 1),
        CricketTeam("KKR", "Kolkata Knight Riders", 0xFF3A225D, 0xFFB3A125, 3),
        CricketTeam("GT", "Gujarat Titans", 0xFF1B2133, 0xFFE0C475, 1),
        CricketTeam("RCB", "Royal Challengers", 0xFFEC1C24, 0xFF000000, 0),
        CricketTeam("SRH", "Sunrisers Hyderabad", 0xFFFF822A, 0xFF000000, 1),
        CricketTeam("DC", "Delhi Capitals", 0xFF004C97, 0xFFEF3340, 0),
        CricketTeam("LSG", "Lucknow Super Giants", 0xFF0057B8, 0xFFF47920, 0),
        CricketTeam("PBKS", "Punjab Kings", 0xFFED1B24, 0xFFD1AB3E, 0)
    )

    // 5. Auth & User Management
    private val _currentUser = MutableStateFlow<AppUser?>(
        AppUser(
            name = "Default User",
            phone = "+91 98765 43210",
            email = "user@email.com",
            role = "user",
            isOtpVerified = true
        )
    )
    val currentUser: StateFlow<AppUser?> = _currentUser.asStateFlow()

    // 6. AdMob Stats
    private val _admobStats = MutableStateFlow(AdMobStats())
    val admobStats: StateFlow<AdMobStats> = _admobStats.asStateFlow()

    // Actions
    fun toggleSection(sectionId: String) {
        _sections.value = _sections.value.map {
            if (it.id == sectionId) it.copy(isEnabled = !it.isEnabled) else it
        }
    }

    fun deleteSection(sectionId: String) {
        _sections.value = _sections.value.filterNot { it.id == sectionId }
    }

    fun moveSection(fromIndex: Int, toIndex: Int) {
        if (fromIndex == toIndex || fromIndex !in _sections.value.indices || toIndex !in _sections.value.indices) return
        val list = _sections.value.toMutableList()
        val item = list.removeAt(fromIndex)
        list.add(toIndex, item)
        _sections.value = list.mapIndexed { index, sec -> sec.copy(order = index) }
    }

    fun addSection(
        nameEn: String,
        nameHi: String,
        nameBn: String,
        iconName: String,
        colorHex: String,
        slug: String,
        isEnabled: Boolean
    ) {
        val newSection = SectionItem(
            id = "sec_${System.currentTimeMillis()}",
            nameEn = nameEn,
            nameHi = nameHi,
            nameBn = nameBn,
            tagEn = "Custom",
            tagHi = "कस्टम",
            tagBn = "কাস্টম",
            iconName = iconName,
            colorHex = colorHex,
            slug = slug,
            isEnabled = isEnabled,
            order = _sections.value.size
        )
        _sections.value = _sections.value + newSection
    }

    fun addNewsArticle(
        titleEn: String,
        titleHi: String,
        titleBn: String,
        contentEn: String,
        contentHi: String,
        contentBn: String,
        category: String,
        isBreaking: Boolean
    ) {
        val newArt = NewsArticle(
            id = "n_${System.currentTimeMillis()}",
            titleEn = titleEn,
            titleHi = titleHi,
            titleBn = titleBn,
            contentEn = contentEn,
            contentHi = contentHi,
            contentBn = contentBn,
            timeAgoEn = "Just now",
            timeAgoHi = "Abhi abhi",
            timeAgoBn = "এইমাত্র",
            views = "10 views",
            category = category,
            isBreaking = isBreaking,
            author = "Admin",
            thumbnailType = "stadium"
        )
        _news.value = listOf(newArt) + _news.value
    }

    fun deleteNewsArticle(id: String) {
        _news.value = _news.value.filterNot { it.id == id }
    }

    fun updateLiveScore(
        team1Score: String,
        team1Overs: String,
        needRuns: Int,
        needBalls: Int,
        kohliruns: Int,
        rohitruns: Int
    ) {
        _liveMatch.value = _liveMatch.value.copy(
            team1Score = team1Score,
            team1Overs = team1Overs,
            needRuns = needRuns,
            needBalls = needBalls,
            batsman1 = _liveMatch.value.batsman1.copy(runs = kohliruns),
            batsman2 = _liveMatch.value.batsman2.copy(runs = rohitruns)
        )
    }

    fun loginUser(name: String, email: String, phone: String) {
        _currentUser.value = AppUser(name = name, email = email, phone = phone, role = "user")
    }

    fun loginAdmin(name: String, email: String) {
        _currentUser.value = AppUser(name = name, email = email, phone = "+91 99999 88888", role = "admin")
    }

    fun logout() {
        _currentUser.value = null
    }

    fun updateAdMobStats(todayEarning: String, impressions: String) {
        _admobStats.value = _admobStats.value.copy(
            todayEarning = todayEarning,
            impressions = impressions
        )
    }
}
