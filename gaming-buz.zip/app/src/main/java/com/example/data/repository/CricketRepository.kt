package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class CricketRepository {

  private val _newsList = MutableStateFlow<List<NewsArticle>>(emptyList())
  val newsList: StateFlow<List<NewsArticle>> = _newsList.asStateFlow()

  private val _bookmarkedIds = MutableStateFlow<Set<String>>(setOf("news_1"))
  val bookmarkedIds: StateFlow<Set<String>> = _bookmarkedIds.asStateFlow()

  private val _matchesList = MutableStateFlow<List<CricketMatch>>(emptyList())
  val matchesList: StateFlow<List<CricketMatch>> = _matchesList.asStateFlow()

  private val _videosList = MutableStateFlow<List<CricketVideo>>(emptyList())
  val videosList: StateFlow<List<CricketVideo>> = _videosList.asStateFlow()

  private val _iplStandings = MutableStateFlow<List<IplTeamStanding>>(emptyList())
  val iplStandings: StateFlow<List<IplTeamStanding>> = _iplStandings.asStateFlow()

  init {
    loadSeedData()
  }

  private fun loadSeedData() {
    val initialNews = listOf(
      NewsArticle(
        id = "news_1",
        titleHi = "भारत ने वेस्टइंडीज को 4 रनों से हराकर सीरीज़ में 2-1 की बढ़त बनाई",
        titleEn = "India beat West Indies by 4 runs to take 2-1 lead in T20I series",
        titleBn = "ভারত ওয়েস্ট ইন্ডিজকে ৪ রানে হারিয়ে সিরিজে ২-১ ব্যবধানে এগিয়ে গেল",
        contentHi = "तीसरे टी-20 मुकाबले में भारतीय टीम ने टॉस जीतकर पहले बल्लेबाजी करते हुए 20 ओवर में 186/6 का स्कोर बनाया। जवाब में वेस्टइंडीज की टीम 20 ओवर में 8 विकेट खोकर 182 रन ही बना सकी। अर्शदीप सिंह ने अंतिम ओवर में शानदार गेंदबाजी करते हुए भारत को 4 रनों से रोमांचक जीत दिलाई। तिलक वर्मा ने 42 गेंदों में नाबाद 68 रनों की धुआंधार पारी खेली।",
        contentEn = "In the 3rd T20I thriller, Team India posted 186/6 in 20 overs after opting to bat first. Tilak Varma top-scored with a scintillating unbeaten 68 off 42 deliveries. In reply, despite Shai Hope's valiant century (102 off 59 balls), Arshdeep Singh's ice-cool final over restricted West Indies to 182/8, sealing a dramatic 4-run win for India.",
        contentBn = "তৃতীয় টি-টোয়েন্টি রোমাঞ্চকর ম্যাচে ভারতীয় দল প্রথমে ব্যাট করে ২০ ওভারে ১৮৬/৬ রান তোলে। তিলক বর্মা ৪২ বলে অপরাজিত ৬৮ রানের অনবद्य ইনিংস খেলেন। জবাবে শাই হোপের দুর্দান্ত শতরান সত্ত্বেও শেষ ওভারে অর্শদীপ সিংয়ের চমৎকার বোলিংয়ে ভারত ৪ রানে জয়লাভ করে।",
        imageUrl = "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=1200&q=80",
        category = NewsCategory.TEAM_INDIA,
        timeAgo = "10:15 AM",
        dateFormatted = "14 Oct 2025",
        author = "Gaming Buz Sports Desk",
        isBreaking = true,
        isFeatured = true,
        viewsCount = 14200
      ),
      NewsArticle(
        id = "news_2",
        titleHi = "शाई होप ने खेली शानदार शतकीय पारी, लेकिन टीम को जीत नहीं दिला सके",
        titleEn = "Shai Hope shines with sensational century but fails to cross the line",
        titleBn = "শাই হোপ দুর্দান্ত সেঞ্চুরি করলেন, কিন্তু দলকে জেতাতে পারলেন না",
        contentHi = "वेस्टइंडीज के कप्तान शाई होप ने 59 गेंदों में 8 चौकों और 6 छक्कों की मदद से 102 रनों की पारी खेली, लेकिन दूसरे छोर से विकेट गिरते रहे और टीम लक्ष्य से 4 रन दूर रह गई।",
        contentEn = "West Indies captain Shai Hope fought single-handedly with a majestic 102 off 59 balls including 8 fours and 6 massive sixes, but a lack of support in the death overs left the Windies short.",
        contentBn = "ওয়েস্ট ইন্ডিজের অধিনায়ক শাই হোপ ৫৯ বলে ১০২ রানের অনবদ্য লড়াই উপহার দেন, তবে ডেথ ওভারে অন্য ব্যাটসম্যানদের ব্যর্থতায় দল জয়ের প্রান্ত ছুঁতে পারেনি।",
        imageUrl = "https://images.unsplash.com/photo-1531415074968-036ba1b575da?auto=format&fit=crop&w=800&q=80",
        category = NewsCategory.INTERNATIONAL,
        timeAgo = "9:20 AM",
        dateFormatted = "14 Oct 2025",
        author = "Rohit Verma",
        viewsCount = 8900
      ),
      NewsArticle(
        id = "news_3",
        titleHi = "अर्शदीप सिंह ने आखिरी ओवर में पलटा मैच, लिए 2 विकेट",
        titleEn = "Arshdeep Singh turns the tables with ice-cold 20th over, grabs 2 wickets",
        titleBn = "শেষ ওভারে ম্যাচের মোড় ঘোরালেন অর্শদীপ সিং, তুলে নিলেন গুরুত্বপূর্ণ ২ উইকেট",
        contentHi = "अंतिम ओवर में वेस्टइंडीज को 11 रनों की दरकार थी। अर्शदीप सिंह ने सटीक यॉर्कर फेंकते हुए केवल 6 रन दिए और 2 महत्वपूर्ण विकेट चटकाकर भारत को जीत दिलाई।",
        contentEn = "Defending 11 runs in the final over, left-arm pacer Arshdeep Singh nailed wide yorkers with precision, conceding only 6 runs and claiming 2 crucial wickets under intense pressure.",
        contentBn = "শেষ ওভারে ক্যারিবিয়ানদের জয়ের জন্য প্রয়োজন ছিল ১১ রান। চাপের মুখে নিখুঁত ইয়র্কার ফেলে মাত্র ৬ রান খরচ করে ২ উইকেট শিকার করেন অর্শদীপ।",
        imageUrl = "https://images.unsplash.com/photo-1512719994953-eabf50895df7?auto=format&fit=crop&w=800&q=80",
        category = NewsCategory.TEAM_INDIA,
        timeAgo = "8:50 AM",
        dateFormatted = "14 Oct 2025",
        author = "Amit Sharma",
        viewsCount = 11200
      ),
      NewsArticle(
        id = "news_4",
        titleHi = "रणजी ट्रॉफी 2025-26: मुंबई ने सौराष्ट्र को 7 विकेट से हराया",
        titleEn = "Ranji Trophy 2025-26: Mumbai register emphatic 7-wicket victory over Saurashtra",
        titleBn = "রঞ্জি ট্রফি ২০২৫-২৬: সৌরাষ্ট্রকে ৭ উইকেটে হারিয়ে দুর্দান্ত জয় মুম্বইয়ের",
        contentHi = "घरेलू क्रिकेट के सबसे बड़े टूर्नामेंट रणजी ट्रॉफी में मुंबई के गेंदबाजों ने कमाल का प्रदर्शन किया। शार्दुल ठाकुर की शानदार गेंदबाजी की बदौलत सौराष्ट्र दूसरी पारी में मात्र 168 रन पर सिमट गई।",
        contentEn = "In a premier Ranji Trophy encounter, Mumbai bowlers dominated proceedings as Shardul Thakur's incisive spell folded Saurashtra for 168 in the second innings, paving an easy 7-wicket win.",
        contentBn = "ঘরোয়া ক্রিকেটের অন্যতম মর্যাদাপূর্ণ টুর্নামেন্ট রঞ্জি ট্রফিতে সৌরাষ্ট্রকে ৭ উইকেটে হারিয়ে পূর্ণ পয়েন্ট তুলে নিল মুম্বই দল। শার্দূল ঠাকুরের চমৎকার বোলিং ম্যাচে ব্যবধান গড়ে দেয়।",
        imageUrl = "https://images.unsplash.com/photo-1589487391730-58f20eb2c308?auto=format&fit=crop&w=800&q=80",
        category = NewsCategory.DOMESTIC,
        timeAgo = "Yesterday",
        dateFormatted = "13 Oct 2025",
        author = "Gaming Buz Domestic Cell",
        viewsCount = 6700
      ),
      NewsArticle(
        id = "news_5",
        titleHi = "आईपीएल 2025 मेगा ऑक्शन: टीमों की रणनीति और रिटेंशन सूची घोषित",
        titleEn = "IPL 2025 Mega Auction: Key retentions announced, purse analysis",
        titleBn = "আইপিএল ২০২৫ মেগা নিলাম: রিটেনশন তালিকা প্রকাশ ও দলগুলির কৌশল",
        contentHi = "आईपीएल 2025 की सभी 10 फ्रेंचाइजी ने अपनी रिटेंशन सूची जारी कर दी है। कई युवा खिलाड़ियों को बड़ी रकम में रिटेन किया गया है, जबकि कुछ स्टार खिलाड़ियों पर नीलामी में नज़रें होंगी।",
        contentEn = "All 10 IPL franchises have finalized their core squads ahead of the 2025 mega auction with record retentions and strategic purse management.",
        contentBn = "আইপিএল ২০২৫ মেগা নিলামের আগে ১০টি ফ্র্যাঞ্চাইজি তাদের রিটেইন করা খেলোয়াড়দের তালিকা চূড়ান্ত করেছে। তরুণ প্রতিভাদের ওপর আস্থা রেখেছে অধিকাংশ দল।",
        imageUrl = "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=800&q=80",
        category = NewsCategory.IPL,
        timeAgo = "Yesterday",
        dateFormatted = "13 Oct 2025",
        author = "Karan Patel",
        viewsCount = 22400
      ),
      NewsArticle(
        id = "news_6",
        titleHi = "महिला टी20 विश्व कप: भारत ने ऑस्ट्रेलिया को रोमांचक मैच में दी मात",
        titleEn = "Women's T20 World Cup: India pull off historic triumph against Australia",
        titleBn = "মহিলা টি-টোয়েন্টি বিশ্বকাপ: অস্ট্রেলিয়াকে নাটকীয় ম্যাচে হারাল ভারত",
        contentHi = "स्मृति मंधाना के 83 रन और दीप्ति शर्मा के 3 विकेटों के दम पर भारतीय महिला टीम ने ऑस्ट्रेलिया पर 15 रनों की ऐतिहासिक जीत दर्ज की।",
        contentEn = "Smriti Mandhana's classy 83 coupled with Deepti Sharma's 3-wicket haul guided the Indian Women's team to a monumental 15-run win over Australia.",
        contentBn = "স্মৃতি মান্ধনার চোখধাঁধানো ৮৩ রান ও দীপ্তি শর্মার ৩ উইকেটের ওপর ভর করে অস্ট্রেলিয়ার বিরুদ্ধে ১৫ রানে ঐতিহাসিক জয় পেল ভারত নারী ক্রিকেট দল।",
        imageUrl = "https://images.unsplash.com/photo-1531415074968-036ba1b575da?auto=format&fit=crop&w=800&q=80",
        category = NewsCategory.WOMENS,
        timeAgo = "2 days ago",
        dateFormatted = "12 Oct 2025",
        author = "Pooja Roy",
        viewsCount = 15800
      )
    )
    _newsList.value = initialNews

    val initialMatches = listOf(
      CricketMatch(
        id = "match_live_1",
        title = "India vs West Indies, 3rd T20I",
        seriesName = "West Indies Tour of India 2025",
        format = MatchFormat.T20,
        status = MatchStatus.LIVE,
        team1 = CricketTeamInfo(shortName = "IND", fullName = "India", score = "186/6", overs = "20.0 Overs", flagEmoji = "🇮🇳"),
        team2 = CricketTeamInfo(shortName = "WI", fullName = "West Indies", score = "182/8", overs = "20.0 Overs", flagEmoji = "🌴"),
        statusMessage = "India won by 4 runs",
        tossDetails = "India won the toss and elected to bat first",
        venue = "Eden Gardens, Kolkata",
        matchTime = "Live • Today",
        batsmen = listOf(
          CricketScorecardBatter("Tilak Varma", runs = 68, balls = 42, fours = 6, sixes = 3, strikeRate = 161.9, isStriker = true),
          CricketScorecardBatter("Hardik Pandya", runs = 34, balls = 19, fours = 2, sixes = 2, strikeRate = 178.9),
          CricketScorecardBatter("Suryakumar Yadav", runs = 28, balls = 16, fours = 3, sixes = 1, strikeRate = 175.0, dismissalInfo = "c Pooran b Joseph")
        ),
        bowlers = listOf(
          CricketScorecardBowler("Arshdeep Singh", overs = 4.0, maidens = 0, runs = 28, wickets = 2, economy = 7.0),
          CricketScorecardBowler("Jasprit Bumrah", overs = 4.0, maidens = 1, runs = 22, wickets = 2, economy = 5.5),
          CricketScorecardBowler("Axar Patel", overs = 4.0, maidens = 0, runs = 31, wickets = 1, economy = 7.75)
        ),
        recentOvers = "1 W 4 0 1 W"
      ),
      CricketMatch(
        id = "match_up_1",
        title = "India vs West Indies, 4th T20I",
        seriesName = "West Indies Tour of India 2025",
        format = MatchFormat.T20,
        status = MatchStatus.UPCOMING,
        team1 = CricketTeamInfo(shortName = "IND", fullName = "India", score = "--", overs = "0.0", flagEmoji = "🇮🇳"),
        team2 = CricketTeamInfo(shortName = "WI", fullName = "West Indies", score = "--", overs = "0.0", flagEmoji = "🌴"),
        statusMessage = "Starts at 7:00 PM IST",
        tossDetails = "Toss at 6:30 PM",
        venue = "Wankhede Stadium, Mumbai",
        matchTime = "Tomorrow • 7:00 PM"
      ),
      CricketMatch(
        id = "match_fin_1",
        title = "Australia vs England, 2nd ODI",
        seriesName = "England in Australia 2025",
        format = MatchFormat.ODI,
        status = MatchStatus.FINISHED,
        team1 = CricketTeamInfo(shortName = "AUS", fullName = "Australia", score = "315/7", overs = "50.0 Overs", flagEmoji = "🇦🇺"),
        team2 = CricketTeamInfo(shortName = "ENG", fullName = "England", score = "284", overs = "47.2 Overs", flagEmoji = "🏴󠁧󠁢󠁥󠁮󠁧󠁿"),
        statusMessage = "Australia won by 31 runs",
        tossDetails = "England won the toss and elected to bowl",
        venue = "MCG, Melbourne",
        matchTime = "Completed"
      )
    )
    _matchesList.value = initialMatches

    val initialVideos = listOf(
      CricketVideo(
        id = "vid_1",
        titleHi = "IND vs WI 3rd T20I Highlights",
        titleEn = "IND vs WI 3rd T20I Match Highlights",
        titleBn = "ভারত বনাম ওয়েস্ট ইন্ডিজ ৩য় টি২০ হাইলাইটস",
        duration = "04:35",
        thumbnailUrl = "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=600&q=80",
        youtubeVideoId = "dQw4w9WgXcQ",
        category = "Match Highlights",
        timeAgo = "1 hour ago"
      ),
      CricketVideo(
        id = "vid_2",
        titleHi = "Shai Hope Century Highlights",
        titleEn = "Shai Hope Magnificent 102 (59) Knock Highlights",
        titleBn = "শাই হোপের ১০২ রানের ধ্রুপদী ইনিংসের হাইলাইটস",
        duration = "03:12",
        thumbnailUrl = "https://images.unsplash.com/photo-1531415074968-036ba1b575da?auto=format&fit=crop&w=600&q=80",
        youtubeVideoId = "dQw4w9WgXcQ",
        category = "Player Innings",
        timeAgo = "2 hours ago"
      ),
      CricketVideo(
        id = "vid_3",
        titleHi = "Tilak Varma Batting Highlights",
        titleEn = "Tilak Varma 68* match-winning knock highlights",
        titleBn = "তিলক বর্মার ম্যাচ জেতানো ব্যাটিং হাইলাইটস",
        duration = "02:45",
        thumbnailUrl = "https://images.unsplash.com/photo-1512719994953-eabf50895df7?auto=format&fit=crop&w=600&q=80",
        youtubeVideoId = "dQw4w9WgXcQ",
        category = "Batting",
        timeAgo = "3 hours ago"
      )
    )
    _videosList.value = initialVideos

    _iplStandings.value = listOf(
      IplTeamStanding(1, "Kolkata Knight Riders", 14, 9, 3, "+0.759", 20),
      IplTeamStanding(2, "Sunrisers Hyderabad", 14, 8, 5, "+0.414", 17),
      IplTeamStanding(3, "Rajasthan Royals", 14, 8, 5, "+0.273", 17),
      IplTeamStanding(4, "Royal Challengers Bengaluru", 14, 7, 7, "+0.459", 14),
      IplTeamStanding(5, "Chennai Super Kings", 14, 7, 7, "+0.392", 14),
      IplTeamStanding(6, "Delhi Capitals", 14, 7, 7, "-0.377", 14),
      IplTeamStanding(7, "Lucknow Super Giants", 14, 7, 7, "-0.667", 14),
      IplTeamStanding(8, "Gujarat Titans", 14, 5, 7, "-1.063", 12),
      IplTeamStanding(9, "Punjab Kings", 14, 5, 9, "-0.353", 10),
      IplTeamStanding(10, "Mumbai Indians", 14, 4, 10, "-0.318", 8)
    )
  }

  fun toggleBookmark(articleId: String) {
    val current = _bookmarkedIds.value.toMutableSet()
    if (current.contains(articleId)) {
      current.remove(articleId)
    } else {
      current.add(articleId)
    }
    _bookmarkedIds.value = current
  }

  // Admin Operations
  fun publishArticle(
    title: String,
    content: String,
    category: NewsCategory,
    imageUrl: String,
    isBreaking: Boolean,
    isDraft: Boolean
  ): NewsArticle {
    val newArticle = NewsArticle(
      id = "news_" + UUID.randomUUID().toString().take(8),
      titleHi = title,
      titleEn = title,
      titleBn = title,
      contentHi = content,
      contentEn = content,
      contentBn = content,
      imageUrl = if (imageUrl.isBlank()) "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=800&q=80" else imageUrl,
      category = category,
      timeAgo = "Just now",
      dateFormatted = "Today",
      author = "Admin (Gaming Buz)",
      isBreaking = isBreaking,
      isFeatured = isBreaking,
      isDraft = isDraft
    )
    _newsList.value = listOf(newArticle) + _newsList.value
    return newArticle
  }

  fun deleteArticle(id: String) {
    _newsList.value = _newsList.value.filter { it.id != id }
  }

  fun addVideo(title: String, duration: String, youtubeId: String, category: String) {
    val newVid = CricketVideo(
      id = "vid_" + UUID.randomUUID().toString().take(8),
      titleHi = title,
      titleEn = title,
      titleBn = title,
      duration = duration.ifBlank { "03:00" },
      thumbnailUrl = "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=600&q=80",
      youtubeVideoId = youtubeId.ifBlank { "dQw4w9WgXcQ" },
      category = category.ifBlank { "Cricket" },
      timeAgo = "Just now"
    )
    _videosList.value = listOf(newVid) + _videosList.value
  }
}
