package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandDarkNavy
import com.example.ui.theme.LocalExtraColors

@Composable
fun GamingBuzIcon(
    size: Dp = 38.dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height

            // 1. Controller Base (Blue)
            val controllerPath = Path().apply {
                moveTo(w * 0.15f, h * 0.35f)
                cubicTo(w * 0.25f, h * 0.22f, w * 0.75f, h * 0.22f, w * 0.85f, h * 0.35f)
                cubicTo(w * 0.98f, h * 0.52f, w * 0.92f, h * 0.82f, w * 0.78f, h * 0.82f)
                cubicTo(w * 0.72f, h * 0.82f, w * 0.65f, h * 0.65f, w * 0.5f, h * 0.65f)
                cubicTo(w * 0.35f, h * 0.65f, w * 0.28f, h * 0.82f, w * 0.22f, h * 0.82f)
                cubicTo(w * 0.08f, h * 0.82f, w * 0.02f, h * 0.52f, w * 0.15f, h * 0.35f)
                close()
            }
            drawPath(path = controllerPath, color = BrandBlue)

            // 2. Cricket Ball in Center
            val ballCenter = Offset(w * 0.5f, h * 0.42f)
            val ballRadius = w * 0.18f
            drawCircle(
                color = Color(0xFFC62828),
                radius = ballRadius,
                center = ballCenter
            )

            // 3. Cricket Ball White Seam
            val seamPath = Path().apply {
                moveTo(ballCenter.x, ballCenter.y - ballRadius)
                cubicTo(
                    ballCenter.x - ballRadius * 0.6f, ballCenter.y - ballRadius * 0.4f,
                    ballCenter.x - ballRadius * 0.6f, ballCenter.y + ballRadius * 0.4f,
                    ballCenter.x, ballCenter.y + ballRadius
                )
            }
            drawPath(
                path = seamPath,
                color = Color.White,
                style = Stroke(width = w * 0.04f, cap = StrokeCap.Round)
            )

            // 4. Controller D-pad & Buttons (White highlights)
            drawCircle(Color.White, radius = w * 0.04f, center = Offset(w * 0.24f, h * 0.46f))
            drawCircle(Color.White, radius = w * 0.035f, center = Offset(w * 0.74f, h * 0.40f))
            drawCircle(Color.White, radius = w * 0.035f, center = Offset(w * 0.80f, h * 0.48f))
        }
    }
}

@Composable
fun GamingBuzLogo(
    iconSize: Dp = 38.dp,
    textSize: TextUnit = 24.sp,
    textColor: Color? = null,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current
    val effectiveTextColor = textColor ?: extraColors.textPrimary

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        GamingBuzIcon(size = iconSize)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "Gaming Buz",
            fontSize = textSize,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.SansSerif,
            color = effectiveTextColor,
            letterSpacing = (-0.5).sp
        )
    }
}
