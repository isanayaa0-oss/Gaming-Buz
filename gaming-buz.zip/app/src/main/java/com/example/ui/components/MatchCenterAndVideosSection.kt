package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsScore
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.CricketVideo
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

@Composable
fun MatchCenterQuickSection(
  currentLanguage: AppLanguage,
  onViewAllClick: () -> Unit,
  onLiveScoreClick: () -> Unit,
  onUpcomingClick: () -> Unit,
  onResultsClick: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 10.dp)
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = Localization.get("match_center", currentLanguage),
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = "${Localization.get("view_all", currentLanguage)} >",
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = CricketRed,
        modifier = Modifier.clickable(onClick = onViewAllClick)
      )
    }

    // 3 Cards in a row
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      MatchCenterItemCard(
        title = Localization.get("nav_live", currentLanguage),
        subtitle = "Live Matches",
        icon = Icons.Default.SportsScore,
        iconTint = Color(0xFF455A64),
        badge = "LIVE",
        badgeBg = CricketRed,
        onClick = onLiveScoreClick,
        modifier = Modifier.weight(1f)
      )
      MatchCenterItemCard(
        title = Localization.get("upcoming", currentLanguage),
        subtitle = "Next Matches",
        icon = Icons.Default.CalendarMonth,
        iconTint = Color(0xFF1976D2),
        badge = null,
        badgeBg = Color.Transparent,
        onClick = onUpcomingClick,
        modifier = Modifier.weight(1f)
      )
      MatchCenterItemCard(
        title = Localization.get("results", currentLanguage),
        subtitle = "Recent Results",
        icon = Icons.Default.EmojiEvents,
        iconTint = Color(0xFFFFA000),
        badge = null,
        badgeBg = Color.Transparent,
        onClick = onResultsClick,
        modifier = Modifier.weight(1f)
      )
    }
  }
}

@Composable
fun MatchCenterItemCard(
  title: String,
  subtitle: String,
  icon: ImageVector,
  iconTint: Color,
  badge: String?,
  badgeBg: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
        .padding(10.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Box(modifier = Modifier.fillMaxWidth()) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = iconTint,
          modifier = Modifier
            .size(32.dp)
            .align(Alignment.Center)
        )
        if (badge != null) {
          Box(
            modifier = Modifier
              .align(Alignment.TopEnd)
              .clip(RoundedCornerShape(4.dp))
              .background(badgeBg)
              .padding(horizontal = 4.dp, vertical = 1.dp)
          ) {
            Text(
              text = badge,
              color = Color.White,
              fontSize = 8.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = title,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )

      Text(
        text = subtitle,
        fontSize = 10.sp,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
        maxLines = 1
      )
    }
  }
}

@Composable
fun VideosHorizontalSection(
  videos: List<CricketVideo>,
  currentLanguage: AppLanguage,
  onViewAllClick: () -> Unit,
  onVideoClick: (CricketVideo) -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 10.dp)
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = Localization.get("tab_videos", currentLanguage),
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = "${Localization.get("view_all", currentLanguage)} >",
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = CricketRed,
        modifier = Modifier.clickable(onClick = onViewAllClick)
      )
    }

    // Horizontal Scroll Videos
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 14.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      videos.forEach { video ->
        Column(
          modifier = Modifier
            .width(170.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onVideoClick(video) }
        ) {
          // Thumbnail with Play Button & Duration
          Box(
            modifier = Modifier
              .width(170.dp)
              .height(105.dp)
              .clip(RoundedCornerShape(12.dp))
          ) {
            AsyncImage(
              model = video.thumbnailUrl,
              contentDescription = video.getTitle(currentLanguage),
              modifier = Modifier.fillMaxSize(),
              contentScale = ContentScale.Crop
            )

            // Dark subtle overlay
            Box(
              modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.2f))
            )

            // Play Icon in Center
            Box(
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.6f))
                .align(Alignment.Center),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Play",
                tint = Color.White,
                modifier = Modifier.size(22.dp)
              )
            }

            // Duration badge at bottom right
            Box(
              modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(6.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color.Black.copy(alpha = 0.75f))
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                text = video.duration,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = video.getTitle(currentLanguage),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 16.sp
          )
        }
      }
    }
  }
}
