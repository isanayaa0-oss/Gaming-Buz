package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.MatchScore
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LiveRed
import com.example.ui.theme.LocalExtraColors

@Composable
fun LiveMatchCard(
    match: MatchScore,
    currentLanguage: AppLanguage,
    onCardClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current

    val gradientBrush = Brush.verticalGradient(
        colors = listOf(
            extraColors.liveCardBrushStart,
            extraColors.liveCardBrushEnd
        )
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .clickable { onCardClick() }
            .testTag("live_match_card"),
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(gradientBrush)
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Tag: • LIVE + Stadium icon
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.85f))
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .background(LiveRed, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "LIVE",
                                color = LiveRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = "🏟️",
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Score Title: INDIA 287/4 vs WEST INDIES
                Text(
                    text = "${match.team1Name} ${match.team1Score} vs ${match.team2Name}",
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    color = extraColors.textPrimary,
                    letterSpacing = (-0.2).sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Target & Equation
                val equationText = when (currentLanguage) {
                    AppLanguage.ENGLISH -> "Target ${match.target} • Need ${match.needRuns} runs in ${match.needBalls} balls"
                    AppLanguage.HINDI -> "Target ${match.target} • Need ${match.needRuns} runs in ${match.needBalls} balls"
                    AppLanguage.BANGLA -> "Target ${match.target} • Need ${match.needRuns} runs in ${match.needBalls} balls"
                }

                Text(
                    text = equationText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = extraColors.textSecondary
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Batsmen Info Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🇮🇳", fontSize = 15.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${match.batsman1.name} 🏏 ${match.batsman1.runs} (${match.batsman1.balls})",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = extraColors.textPrimary
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "🏏 ${match.batsman2.name} ${match.batsman2.runs} (${match.batsman2.balls})",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = extraColors.textPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Full Scorecard Button
                Button(
                    onClick = onCardClick,
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BrandBlue,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .height(42.dp)
                        .testTag("full_scorecard_button")
                ) {
                    Text(
                        text = "Full Scorecard →",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
