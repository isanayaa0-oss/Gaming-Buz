package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NewsCategory
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

data class CategoryItemData(
  val category: NewsCategory,
  val icon: ImageVector,
  val iconBgColor: Color,
  val iconTint: Color,
  val labelKey: String
)

@Composable
fun CategoryTabsRow(
  selectedCategory: NewsCategory,
  currentLanguage: AppLanguage,
  onCategorySelected: (NewsCategory) -> Unit
) {
  val items = listOf(
    CategoryItemData(
      NewsCategory.TOP_NEWS,
      Icons.Default.Article,
      Color(0xFFFFEBEE),
      CricketRed,
      "tab_top_news"
    ),
    CategoryItemData(
      NewsCategory.PREVIEWS,
      Icons.Default.Sensors,
      Color(0xFFE8F5E9),
      Color(0xFF2E7D32),
      "tab_live_score"
    ),
    CategoryItemData(
      NewsCategory.TEAM_INDIA,
      Icons.Default.SportsCricket,
      Color(0xFFE3F2FD),
      Color(0xFF1976D2),
      "tab_team_india"
    ),
    CategoryItemData(
      NewsCategory.IPL,
      Icons.Default.EmojiEvents,
      Color(0xFFF3E5F5),
      Color(0xFF8E24AA),
      "tab_ipl"
    ),
    CategoryItemData(
      NewsCategory.DOMESTIC,
      Icons.Default.SportsBaseball,
      Color(0xFFFFEBEE),
      Color(0xFFB71C1C),
      "tab_domestic"
    ),
    CategoryItemData(
      NewsCategory.RECORDS,
      Icons.Default.PlayCircle,
      Color(0xFFFFEBEE),
      CricketRed,
      "tab_videos"
    )
  )

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(MaterialTheme.colorScheme.background)
      .horizontalScroll(rememberScrollState())
      .padding(horizontal = 12.dp, vertical = 12.dp),
    horizontalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    items.forEach { item ->
      val isSelected = selectedCategory == item.category
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
          .clip(CircleShape)
          .clickable { onCategorySelected(item.category) }
          .padding(4.dp)
      ) {
        Box(
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(item.iconBgColor),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = item.icon,
            contentDescription = Localization.get(item.labelKey, currentLanguage),
            tint = item.iconTint,
            modifier = Modifier.size(24.dp)
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = Localization.get(item.labelKey, currentLanguage),
          fontSize = 12.sp,
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
          color = if (isSelected) CricketRed else MaterialTheme.colorScheme.onSurface,
          textAlign = TextAlign.Center
        )
        if (isSelected) {
          Spacer(modifier = Modifier.height(2.dp))
          Box(
            modifier = Modifier
              .width(24.dp)
              .height(2.dp)
              .background(CricketRed)
          )
        }
      }
    }
  }
}
