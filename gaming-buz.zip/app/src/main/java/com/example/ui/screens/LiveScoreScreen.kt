package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CricketMatch
import com.example.data.model.MatchFormat
import com.example.data.model.MatchStatus
import com.example.ui.components.LiveMatchCard
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

@Composable
fun LiveScoreScreen(
  matches: List<CricketMatch>,
  currentLanguage: AppLanguage,
  onMatchClick: (CricketMatch) -> Unit
) {
  var selectedStatus by remember { mutableStateOf(MatchStatus.LIVE) }
  var selectedFormat by remember { mutableStateOf<MatchFormat?>(null) }
  var isRefreshing by remember { mutableStateOf(false) }

  val filteredMatches = matches.filter { match ->
    match.status == selectedStatus && (selectedFormat == null || match.format == selectedFormat)
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // Header Row with Title and Refresh
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = Localization.get("match_center", currentLanguage),
        fontSize = 22.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
      )
      IconButton(onClick = { isRefreshing = true }) {
        Icon(
          imageVector = Icons.Default.Refresh,
          contentDescription = "Refresh",
          tint = CricketRed
        )
      }
    }

    // Status Tab Row: LIVE, UPCOMING, RESULTS
    TabRow(
      selectedTabIndex = selectedStatus.ordinal,
      containerColor = MaterialTheme.colorScheme.background,
      contentColor = CricketRed
    ) {
      Tab(
        selected = selectedStatus == MatchStatus.LIVE,
        onClick = { selectedStatus = MatchStatus.LIVE },
        text = {
          Text(
            text = "LIVE",
            fontWeight = FontWeight.Bold,
            color = if (selectedStatus == MatchStatus.LIVE) CricketRed else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
          )
        }
      )
      Tab(
        selected = selectedStatus == MatchStatus.UPCOMING,
        onClick = { selectedStatus = MatchStatus.UPCOMING },
        text = {
          Text(
            text = Localization.get("upcoming", currentLanguage),
            fontWeight = FontWeight.Bold,
            color = if (selectedStatus == MatchStatus.UPCOMING) CricketRed else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
          )
        }
      )
      Tab(
        selected = selectedStatus == MatchStatus.FINISHED,
        onClick = { selectedStatus = MatchStatus.FINISHED },
        text = {
          Text(
            text = Localization.get("results", currentLanguage),
            fontWeight = FontWeight.Bold,
            color = if (selectedStatus == MatchStatus.FINISHED) CricketRed else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
          )
        }
      )
    }

    // Format Chips: ALL, T20, ODI, TEST
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      FilterChip(
        selected = selectedFormat == null,
        onClick = { selectedFormat = null },
        label = { Text("All Formats") },
        colors = FilterChipDefaults.filterChipColors(
          selectedContainerColor = CricketRed,
          selectedLabelColor = Color.White
        )
      )
      MatchFormat.entries.forEach { format ->
        FilterChip(
          selected = selectedFormat == format,
          onClick = { selectedFormat = format },
          label = { Text(format.name) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = CricketRed,
            selectedLabelColor = Color.White
          )
        )
      }
    }

    // Matches List
    if (filteredMatches.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "No matches available in this category.",
          color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
          fontSize = 14.sp
        )
      }
    } else {
      LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(filteredMatches) { match ->
          LiveMatchCard(
            match = match,
            onClick = { onMatchClick(match) }
          )
          Spacer(modifier = Modifier.height(6.dp))
        }
        item {
          Spacer(modifier = Modifier.height(24.dp))
        }
      }
    }
  }
}
