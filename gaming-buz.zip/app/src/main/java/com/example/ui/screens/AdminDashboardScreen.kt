package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NewsArticle
import com.example.data.model.NewsCategory
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.ui.theme.CricketRed
import com.example.ui.theme.IndiaBlue
import com.example.util.AppLanguage
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
  currentUser: UserProfile?,
  articlesList: List<NewsArticle>,
  currentLanguage: AppLanguage,
  onPublishNews: (String, String, NewsCategory, String, Boolean, Boolean) -> Unit,
  onDeleteNews: (String) -> Unit,
  onAddVideo: (String, String, String, String) -> Unit,
  onBackClick: () -> Unit
) {
  // Security Check: If not authorized ADMIN, block access
  if (currentUser?.role != UserRole.ADMIN) {
    Scaffold(
      topBar = {
        TopAppBar(
          title = { Text("Access Denied", fontWeight = FontWeight.Bold) },
          navigationIcon = {
            IconButton(onClick = onBackClick) {
              Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
          }
        )
      }
    ) { paddingValues ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues)
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              imageVector = Icons.Default.Lock,
              contentDescription = null,
              tint = CricketRed,
              modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
              text = "Unauthorized Access",
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              color = CricketRed
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "You must log in with an authorized Administrator account to access the Gaming Buz publishing panel.",
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
              textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
              onClick = onBackClick,
              colors = ButtonDefaults.buttonColors(containerColor = CricketRed)
            ) {
              Text("Return to Login")
            }
          }
        }
      }
    }
    return
  }

  // Admin Dashboard Active State
  var selectedTab by remember { mutableStateOf(0) } // 0: Publish News, 1: Manage Published, 2: Add Video

  // Form State for News
  var headlineInput by remember { mutableStateOf("") }
  var contentInput by remember { mutableStateOf("") }
  var imageUrlInput by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf(NewsCategory.TEAM_INDIA) }
  var isBreakingNews by remember { mutableStateOf(false) }

  // Form State for Video
  var videoTitleInput by remember { mutableStateOf("") }
  var videoDurationInput by remember { mutableStateOf("03:45") }
  var videoYoutubeIdInput by remember { mutableStateOf("dQw4w9WgXcQ") }
  var videoCategoryInput by remember { mutableStateOf("Highlights") }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = Localization.get("admin_dashboard", currentLanguage),
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp
            )
            Text(
              text = "Admin: ${currentUser.displayName} (${currentUser.email ?: "Secured"})",
              fontSize = 11.sp,
              color = IndiaBlue
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onBackClick) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
    ) {
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = CricketRed
      ) {
        Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text(Localization.get("add_news", currentLanguage), fontWeight = FontWeight.Bold) })
        Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Published (${articlesList.size})", fontWeight = FontWeight.Bold) })
        Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Add Video", fontWeight = FontWeight.Bold) })
      }

      when (selectedTab) {
        0 -> {
          // Add News Form
          Column(
            modifier = Modifier
              .fillMaxSize()
              .verticalScroll(rememberScrollState())
              .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            Text(
              text = "Publish Article Directly to App (No APK update required)",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )

            OutlinedTextField(
              value = headlineInput,
              onValueChange = { headlineInput = it },
              label = { Text(Localization.get("headline_label", currentLanguage)) },
              placeholder = { Text("उदा. भारत ने वेस्टइंडीज को हराकर शानदार जीत दर्ज की") },
              modifier = Modifier.fillMaxWidth()
            )

            // Category Picker
            Column {
              Text("Select Category", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
              Spacer(modifier = Modifier.height(4.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                listOf(NewsCategory.TEAM_INDIA, NewsCategory.INTERNATIONAL, NewsCategory.DOMESTIC, NewsCategory.IPL).forEach { cat ->
                  FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    label = { Text(Localization.get(cat.translationKey, currentLanguage), fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                      selectedContainerColor = CricketRed,
                      selectedLabelColor = Color.White
                    )
                  )
                }
              }
            }

            OutlinedTextField(
              value = imageUrlInput,
              onValueChange = { imageUrlInput = it },
              label = { Text(Localization.get("image_url_label", currentLanguage)) },
              placeholder = { Text("https://example.com/cricket.jpg (or leave empty for default)") },
              singleLine = true,
              modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
              value = contentInput,
              onValueChange = { contentInput = it },
              label = { Text(Localization.get("content_label", currentLanguage)) },
              placeholder = { Text("खबर का पूरा विवरण हिंदी, अंग्रेजी या बांग्ला में लिखें...") },
              minLines = 4,
              maxLines = 8,
              modifier = Modifier.fillMaxWidth()
            )

            // Breaking News Toggle
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = Localization.get("breaking_news_toggle", currentLanguage), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
              Switch(
                checked = isBreakingNews,
                onCheckedChange = { isBreakingNews = it },
                colors = SwitchDefaults.colors(checkedThumbColor = CricketRed)
              )
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              // Save Draft
              OutlinedButton(
                onClick = {
                  if (headlineInput.isNotBlank()) {
                    onPublishNews(
                      headlineInput,
                      contentInput.ifBlank { "विस्तृत रिपोर्ट जल्द ही अपडेट की जाएगी..." },
                      selectedCategory,
                      imageUrlInput,
                      isBreakingNews,
                      true
                    )
                    headlineInput = ""
                    contentInput = ""
                  }
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
              ) {
                Text(Localization.get("save_draft", currentLanguage))
              }

              // Publish Now
              Button(
                onClick = {
                  if (headlineInput.isNotBlank()) {
                    onPublishNews(
                      headlineInput,
                      contentInput.ifBlank { "विस्तृत मैच रिपोर्ट जल्द ही अपडेट की जाएगी..." },
                      selectedCategory,
                      imageUrlInput,
                      isBreakingNews,
                      false
                    )
                    headlineInput = ""
                    contentInput = ""
                    selectedTab = 1
                  }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = CricketRed),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(imageVector = Icons.Default.Publish, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(Localization.get("publish", currentLanguage), fontWeight = FontWeight.Bold)
              }
            }
          }
        }

        1 -> {
          // Manage Published Articles List
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            items(articlesList) { article ->
              Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = if (article.isDraft) Color.Gray.copy(alpha = 0.2f) else CricketRed.copy(alpha = 0.12f)
                    ) {
                      Text(
                        text = if (article.isDraft) "DRAFT" else "LIVE ON APP",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (article.isDraft) Color.DarkGray else CricketRed,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                      )
                    }
                    IconButton(
                      onClick = { onDeleteNews(article.id) },
                      modifier = Modifier.size(30.dp)
                    ) {
                      Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(18.dp))
                    }
                  }

                  Spacer(modifier = Modifier.height(6.dp))
                  Text(
                    text = article.getTitle(currentLanguage),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "${article.dateFormatted} • Author: ${article.author}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                  )
                }
              }
            }
          }
        }

        2 -> {
          // Add Video Form
          Column(
            modifier = Modifier
              .fillMaxSize()
              .verticalScroll(rememberScrollState())
              .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            Text("Publish YouTube Cricket Video to Gaming Buz", fontWeight = FontWeight.Bold, fontSize = 16.sp)

            OutlinedTextField(
              value = videoTitleInput,
              onValueChange = { videoTitleInput = it },
              label = { Text("Video Title") },
              placeholder = { Text("उदा. IND vs WI 3rd T20I Highlights") },
              modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
              value = videoDurationInput,
              onValueChange = { videoDurationInput = it },
              label = { Text("Duration (e.g. 04:35)") },
              modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
              value = videoYoutubeIdInput,
              onValueChange = { videoYoutubeIdInput = it },
              label = { Text("YouTube Video ID / URL") },
              placeholder = { Text("dQw4w9WgXcQ") },
              modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
              value = videoCategoryInput,
              onValueChange = { videoCategoryInput = it },
              label = { Text("Category") },
              placeholder = { Text("Highlights / Analysis") },
              modifier = Modifier.fillMaxWidth()
            )

            Button(
              onClick = {
                if (videoTitleInput.isNotBlank()) {
                  onAddVideo(videoTitleInput, videoDurationInput, videoYoutubeIdInput, videoCategoryInput)
                  videoTitleInput = ""
                }
              },
              modifier = Modifier.fillMaxWidth(),
              colors = ButtonDefaults.buttonColors(containerColor = CricketRed),
              shape = RoundedCornerShape(10.dp)
            ) {
              Text("Publish Video", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}
