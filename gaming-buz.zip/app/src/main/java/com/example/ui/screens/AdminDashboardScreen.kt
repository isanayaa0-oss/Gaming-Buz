package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AdMobStats
import com.example.model.AppLanguage
import com.example.model.SectionItem
import com.example.ui.components.GamingBuzLogo
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandOrange
import com.example.ui.theme.LiveRed
import com.example.ui.theme.LocalExtraColors
import com.example.viewmodel.GamingBuzViewModel
import com.example.viewmodel.ScreenState

@Composable
fun AdMobMetricCard(
    title: String,
    amount: String,
    growthText: String,
    badgeBg: Color,
    badgeTextColor: Color,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current

    Card(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, extraColors.borderColor, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(badgeBg),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "📈", fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = extraColors.textSecondary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = amount,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = extraColors.textPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = growthText,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = badgeTextColor
            )
        }
    }
}

@Composable
fun EarningsTrendChart(
    trendData: List<Pair<String, Float>>,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current

    Card(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, extraColors.borderColor, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Text(
                text = "Earnings Trend (Last 7 Days)",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = extraColors.textPrimary
            )

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val maxVal = 300f
                    val points = trendData.mapIndexed { index, pair ->
                        val x = (index.toFloat() / (trendData.size - 1)) * w
                        val y = h - ((pair.second / maxVal) * (h * 0.75f)) - (h * 0.15f)
                        Offset(x, y)
                    }

                    // Fill Gradient Area
                    if (points.isNotEmpty()) {
                        val fillPath = Path().apply {
                            moveTo(points.first().x, h)
                            points.forEach { lineTo(it.x, it.y) }
                            lineTo(points.last().x, h)
                            close()
                        }
                        drawPath(
                            path = fillPath,
                            brush = Brush.verticalGradient(
                                listOf(BrandBlue.copy(alpha = 0.25f), Color.Transparent)
                            )
                        )

                        // Line Curve
                        val linePath = Path().apply {
                            moveTo(points.first().x, points.first().y)
                            for (i in 1 until points.size) {
                                lineTo(points[i].x, points[i].y)
                            }
                        }
                        drawPath(
                            path = linePath,
                            color = BrandBlue,
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )

                        // Points dots
                        points.forEach { pt ->
                            drawCircle(BrandBlue, radius = 3.5.dp.toPx(), center = pt)
                            drawCircle(Color.White, radius = 1.5.dp.toPx(), center = pt)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Days Labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                trendData.forEach { (day, _) ->
                    Text(
                        text = day,
                        fontSize = 10.sp,
                        color = extraColors.textSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun AdminDashboardScreen(
    viewModel: GamingBuzViewModel,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current
    val sections by viewModel.sections.collectAsState()
    val admob by viewModel.admobStats.collectAsState()
    val currentLang by viewModel.currentLanguage.collectAsState()

    var newSecNameEn by remember { mutableStateOf("Top News") }
    var newSecNameHi by remember { mutableStateOf("टॉप न्यूज़") }
    var newSecNameBn by remember { mutableStateOf("টপ নিউজ") }
    var newSecColor by remember { mutableStateOf("#7C3AED") }
    var newSecSlug by remember { mutableStateOf("/videos") }
    var newSecEnabled by remember { mutableStateOf(true) }
    var showForm by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = extraColors.cardBackground,
        topBar = {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = extraColors.cardBackground,
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { viewModel.navigateTo(ScreenState.Home) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = extraColors.textPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        GamingBuzLogo(iconSize = 28.dp, textSize = 18.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(BrandBlue.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Admin Panel",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrandBlue
                            )
                        }
                    }

                    // Admin avatar badge
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(extraColors.pillUnselected)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(BrandBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "AD", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Admin User",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = extraColors.textPrimary
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Dashboard Welcome Title & Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Dashboard",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = extraColors.textPrimary
                    )
                    Text(
                        text = "Welcome back! Manage your Gaming Buz content and track earnings",
                        fontSize = 12.sp,
                        color = extraColors.textSecondary
                    )
                }
            }

            // Top action buttons: + Add New Section / Live Score Override
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { showForm = !showForm },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                    modifier = Modifier.weight(1f).testTag("admin_add_section_header_btn")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Add Section", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { viewModel.showScoreEditorDialog() },
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, extraColors.borderColor),
                    modifier = Modifier.weight(1f).testTag("admin_override_score_btn")
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp), tint = extraColors.textPrimary)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Edit Live Score", fontSize = 12.sp, color = extraColors.textPrimary)
                }
            }

            // 1. AdMob Earning Section (Exact match to Screenshot 2)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "AdMob Earning",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = extraColors.textPrimary
                )
                Text(
                    text = "Revenue insights from AdMob for your app",
                    fontSize = 12.sp,
                    color = extraColors.textSecondary
                )

                // 3 Metric Cards row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AdMobMetricCard(
                        title = "Today's Earning",
                        amount = admob.todayEarning,
                        growthText = admob.todayGrowth,
                        badgeBg = Color(0xFFDCFCE7),
                        badgeTextColor = Color(0xFF16A34A),
                        modifier = Modifier.weight(1f)
                    )
                    AdMobMetricCard(
                        title = "Total Earning",
                        amount = admob.totalEarning,
                        growthText = admob.totalGrowth,
                        badgeBg = Color(0xFFDBEAFE),
                        badgeTextColor = Color(0xFF2563EB),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AdMobMetricCard(
                        title = "Impressions",
                        amount = admob.impressions,
                        growthText = admob.impressionsGrowth,
                        badgeBg = Color(0xFFDCFCE7),
                        badgeTextColor = Color(0xFF16A34A),
                        modifier = Modifier.weight(1f)
                    )
                    EarningsTrendChart(
                        trendData = admob.trendData,
                        modifier = Modifier.weight(1.4f)
                    )
                }
            }

            // 2. Manage Sections (Dynamic App Builder - Most Important per requirement 7 & Screenshot 2)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, extraColors.borderColor, RoundedCornerShape(18.dp)),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Manage Sections",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = extraColors.textPrimary
                        )

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(extraColors.pillUnselected)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${sections.size} Sections",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = extraColors.textSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Drag to reorder, toggle to enable/disable, or delete sections. Add, remove, or reorder sections instantly — no code required.",
                        fontSize = 12.sp,
                        color = extraColors.textSecondary,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Sections List with Reorder buttons, Toggles, Tags & Delete
                    sections.forEachIndexed { index, sec ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Drag / Move Up/Down Controls
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { if (index > 0) viewModel.moveSection(index, index - 1) },
                                    enabled = index > 0,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = { if (index < sections.size - 1) viewModel.moveSection(index, index + 1) },
                                    enabled = index < sections.size - 1,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", modifier = Modifier.size(16.dp))
                                }
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            Text(
                                text = sec.nameEn,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = extraColors.textPrimary
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            // Tag Badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(
                                        when (sec.tagEn) {
                                            "Featured" -> Color(0xFFDBEAFE)
                                            "Live" -> Color(0xFFFEE2E2)
                                            "Media" -> Color(0xFFFCE7F3)
                                            else -> Color(0xFFE0E7FF)
                                        }
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = sec.tagEn,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (sec.tagEn) {
                                        "Featured" -> BrandBlue
                                        "Live" -> LiveRed
                                        "Media" -> Color(0xFFBE185D)
                                        else -> Color(0xFF4338CA)
                                    }
                                )
                            }

                            Spacer(modifier = Modifier.weight(1f))

                            // Switch Toggle
                            Switch(
                                checked = sec.isEnabled,
                                onCheckedChange = { viewModel.toggleSection(sec.id) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF22C55E),
                                    uncheckedThumbColor = Color.White,
                                    uncheckedTrackColor = Color(0xFFD1D5DB)
                                ),
                                modifier = Modifier.testTag("sec_toggle_${sec.id}")
                            )

                            Spacer(modifier = Modifier.width(6.dp))

                            // Delete Trash Icon
                            IconButton(
                                onClick = { viewModel.deleteSection(sec.id) },
                                modifier = Modifier.size(32.dp).testTag("delete_sec_${sec.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Delete,
                                    contentDescription = "Delete",
                                    tint = extraColors.textSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        if (index < sections.size - 1) {
                            HorizontalDivider(color = extraColors.borderColor.copy(alpha = 0.5f), thickness = 0.5.dp)
                        }
                    }
                }
            }

            // 3. Add New Section Form (Exact match to Screenshot 2)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, extraColors.borderColor, RoundedCornerShape(18.dp)),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Add New Section +",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = extraColors.textPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Name (English)", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = extraColors.textPrimary)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = newSecNameEn,
                                onValueChange = { newSecNameEn = it },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("add_sec_en_input")
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Name (Hindi)", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = extraColors.textPrimary)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = newSecNameHi,
                                onValueChange = { newSecNameHi = it },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("add_sec_hi_input")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Name (Bangla)", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = extraColors.textPrimary)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = newSecNameBn,
                                onValueChange = { newSecNameBn = it },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("add_sec_bn_input")
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Icon", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = extraColors.textPrimary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .border(1.dp, extraColors.borderColor, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "📹 video", fontSize = 13.sp, color = extraColors.textPrimary)
                                Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Color", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = extraColors.textPrimary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .border(1.dp, extraColors.borderColor, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF7C3AED))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = newSecColor, fontSize = 13.sp, color = extraColors.textPrimary)
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Section Slug", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = extraColors.textPrimary)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = newSecSlug,
                                onValueChange = { newSecSlug = it },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("add_sec_slug_input")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { newSecEnabled = !newSecEnabled }
                    ) {
                        Checkbox(
                            checked = newSecEnabled,
                            onCheckedChange = { newSecEnabled = it },
                            colors = CheckboxDefaults.colors(checkedColor = BrandBlue)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Enabled by default",
                            fontSize = 13.sp,
                            color = extraColors.textPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = {
                                newSecNameEn = ""
                                newSecNameHi = ""
                                newSecNameBn = ""
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("add_sec_cancel_btn")
                        ) {
                            Text("Cancel", fontSize = 13.sp, color = extraColors.textPrimary)
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Button(
                            onClick = {
                                if (newSecNameEn.isNotBlank()) {
                                    viewModel.addSection(
                                        nameEn = newSecNameEn,
                                        nameHi = newSecNameHi.ifBlank { newSecNameEn },
                                        nameBn = newSecNameBn.ifBlank { newSecNameEn },
                                        icon = "video",
                                        color = newSecColor,
                                        slug = newSecSlug,
                                        enabled = newSecEnabled
                                    )
                                    newSecNameEn = ""
                                    newSecNameHi = ""
                                    newSecNameBn = ""
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                            modifier = Modifier.testTag("add_sec_submit_btn")
                        ) {
                            Text("+ Add Section", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Bottom Informational Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFEFF6FF))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Outlined.Info,
                        contentDescription = "Info",
                        tint = BrandBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "All changes are saved instantly. Reorder sections by clicking arrow handles. No coding required — add or remove sections anytime.",
                        fontSize = 12.sp,
                        color = BrandBlue,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
