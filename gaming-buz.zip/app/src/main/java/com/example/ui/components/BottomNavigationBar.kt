package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LocalExtraColors

data class NavItem(
    val id: String,
    val titleEn: String,
    val titleHi: String,
    val titleBn: String,
    val iconFilled: ImageVector,
    val iconOutlined: ImageVector
)

@Composable
fun BottomNavigationBar(
    selectedTab: String,
    onTabSelected: (String) -> Unit,
    currentLanguage: AppLanguage,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current

    val navItems = listOf(
        NavItem(
            id = "home",
            titleEn = "Home",
            titleHi = "होम",
            titleBn = "হোম",
            iconFilled = Icons.Filled.Home,
            iconOutlined = Icons.Outlined.Home
        ),
        NavItem(
            id = "news",
            titleEn = "News",
            titleHi = "न्यूज़",
            titleBn = "নিউজ",
            iconFilled = Icons.Outlined.Description,
            iconOutlined = Icons.Outlined.Description
        ),
        NavItem(
            id = "live",
            titleEn = "Live Score",
            titleHi = "लाइव स्कोर",
            titleBn = "লাইভ স্কোর",
            iconFilled = Icons.Outlined.Assessment,
            iconOutlined = Icons.Outlined.Assessment
        ),
        NavItem(
            id = "videos",
            titleEn = "Videos",
            titleHi = "वीडियो",
            titleBn = "ভিডিও",
            iconFilled = Icons.Filled.PlayCircleOutline,
            iconOutlined = Icons.Outlined.PlayCircle
        ),
        NavItem(
            id = "more",
            titleEn = "More",
            titleHi = "अधिक",
            titleBn = "আরও",
            iconFilled = Icons.Filled.MoreHoriz,
            iconOutlined = Icons.Outlined.MoreHoriz
        )
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        color = extraColors.cardBackground
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            navItems.forEach { item ->
                val isSelected = selectedTab == item.id
                val label = when (currentLanguage) {
                    AppLanguage.ENGLISH -> item.titleEn
                    AppLanguage.HINDI -> item.titleHi
                    AppLanguage.BANGLA -> item.titleBn
                }
                val tint = if (isSelected) BrandBlue else extraColors.textSecondary

                Column(
                    modifier = Modifier
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() }
                        ) { onTabSelected(item.id) }
                        .padding(horizontal = 10.dp, vertical = 2.dp)
                        .testTag("bottom_nav_${item.id}"),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Small active dot above icon (as shown in Screenshot 3 for Home)
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .background(
                                color = if (isSelected) BrandBlue else Color.Transparent,
                                shape = CircleShape
                            )
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Icon(
                        imageVector = if (isSelected) item.iconFilled else item.iconOutlined,
                        contentDescription = label,
                        tint = tint,
                        modifier = Modifier.size(23.dp)
                    )

                    Spacer(modifier = Modifier.height(3.dp))

                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = tint
                    )
                }
            }
        }
    }
}
