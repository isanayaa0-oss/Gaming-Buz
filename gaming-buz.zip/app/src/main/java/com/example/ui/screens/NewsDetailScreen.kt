package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.NewsArticle
import com.example.ui.components.NewsThumbnail
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LiveRed
import com.example.ui.theme.LocalExtraColors
import com.example.viewmodel.GamingBuzViewModel
import com.example.viewmodel.ScreenState

@Composable
fun NewsDetailScreen(
    article: NewsArticle,
    viewModel: GamingBuzViewModel,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current
    val currentLang by viewModel.currentLanguage.collectAsState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = extraColors.cardBackground,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(extraColors.cardBackground)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenState.Home) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = extraColors.textPrimary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { /* Bookmark */ }, modifier = Modifier.size(36.dp)) {
                        Icon(imageVector = Icons.Default.BookmarkBorder, contentDescription = "Bookmark", tint = extraColors.textPrimary)
                    }
                    IconButton(onClick = { /* Share */ }, modifier = Modifier.size(36.dp)) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = extraColors.textPrimary)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Category & Breaking Badge Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(BrandBlue.copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = article.category,
                        color = BrandBlue,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (article.isBreaking) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(LiveRed.copy(alpha = 0.15f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "BREAKING",
                            color = LiveRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // In-article Language quick toggle (Requirement 3: multilingual news support)
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(extraColors.pillUnselected)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    AppLanguage.values().forEach { lang ->
                        val isSelected = currentLang == lang
                        Text(
                            text = lang.code.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) BrandBlue else extraColors.textSecondary,
                            modifier = Modifier
                                .clickable { viewModel.setLanguage(lang) }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Title
            Text(
                text = article.localizedTitle(currentLang),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = extraColors.textPrimary,
                lineHeight = 28.sp
            )

            // Author and Date info
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(BrandBlue.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "GB", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BrandBlue)
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = article.author,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = extraColors.textPrimary
                    )
                    Text(
                        text = "${article.localizedTimeAgo(currentLang)} • ${article.views}",
                        fontSize = 11.sp,
                        color = extraColors.textSecondary
                    )
                }
            }

            // Article Main Thumbnail Art
            NewsThumbnail(
                type = article.thumbnailType,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(16.dp))
            )

            // Article Body Content
            Text(
                text = article.localizedContent(currentLang),
                fontSize = 16.sp,
                color = extraColors.textPrimary,
                lineHeight = 26.sp,
                letterSpacing = 0.2.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Extra cricket highlights card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = extraColors.pillUnselected)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Match Highlights & Takeaways",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = extraColors.textPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• India needed 326 to win against a formidable West Indies total.\n• Rohit Sharma and Virat Kohli registered pivotal half-centuries.\n• Gaming Buz provides ball-by-ball commentary and live analysis.",
                        fontSize = 13.sp,
                        color = extraColors.textSecondary,
                        lineHeight = 20.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
