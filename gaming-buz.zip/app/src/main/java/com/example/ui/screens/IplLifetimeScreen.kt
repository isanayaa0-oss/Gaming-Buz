package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.components.BottomNavigationBar
import com.example.ui.components.CapCardsRow
import com.example.ui.components.CategoryPills
import com.example.ui.components.GamingBuzHeader
import com.example.ui.components.PointsTableView
import com.example.ui.components.TeamLogoBadge
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LocalExtraColors
import com.example.viewmodel.GamingBuzViewModel

@Composable
fun IplLifetimeScreen(
    viewModel: GamingBuzViewModel,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current
    val currentLang by viewModel.currentLanguage.collectAsState()
    val sections by viewModel.sections.collectAsState()
    val activeSeason by viewModel.activeIplSeason.collectAsState()
    val isSearchActive by viewModel.isSearchActive.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val notificationCount by viewModel.notificationCount.collectAsState()
    val selectedNav by viewModel.selectedBottomNav.collectAsState()

    val pointsTable = viewModel.getPointsTable()
    val seasons = listOf("Lifetime", "2024", "2023", "2022", "2021", "2020", "2019", "2008")

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = extraColors.cardBackground,
        topBar = {
            GamingBuzHeader(
                onMenuClick = { viewModel.openDrawer() },
                isSearchActive = isSearchActive,
                searchQuery = searchQuery,
                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                onSearchToggle = { viewModel.toggleSearch() },
                notificationCount = notificationCount
            )
        },
        bottomBar = {
            BottomNavigationBar(
                selectedTab = "ipl",
                onTabSelected = { viewModel.selectBottomNav(it) },
                currentLanguage = currentLang
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(extraColors.cardBackground),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Category navigation: News, IPL, Fantasy, Stats
            item {
                CategoryPills(
                    sections = sections,
                    selectedCategory = "IPL",
                    onCategorySelected = { viewModel.selectCategory(it) },
                    currentLanguage = currentLang
                )
            }

            // IPL Big Title & Lifetime coverage
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Text(
                        text = "IPL",
                        fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = extraColors.textPrimary,
                        letterSpacing = (-0.5).sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "lifetime coverage",
                            fontSize = 14.sp,
                            color = extraColors.textSecondary,
                            fontWeight = FontWeight.Normal
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Icon(
                            imageVector = Icons.Outlined.Info,
                            contentDescription = "Lifetime coverage info",
                            tint = extraColors.textSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Season Sub-tabs: Lifetime, 2024, 2023...
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(seasons) { season ->
                        val isSelected = activeSeason == season
                        val bg = if (isSelected) BrandBlue else extraColors.cardBackground
                        val textColor = if (isSelected) Color.White else extraColors.textSecondary
                        val borderMod = if (isSelected) Modifier else Modifier.clip(RoundedCornerShape(20.dp))

                        Box(
                            modifier = Modifier
                                .height(38.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(bg)
                                .clickable { viewModel.setIplSeason(season) }
                                .padding(horizontal = 22.dp)
                                .testTag("season_tab_$season"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = season,
                                color = textColor,
                                fontSize = 14.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // Points Table Card
            item {
                PointsTableView(
                    rows = pointsTable,
                    onSeeAllClick = {}
                )
            }

            // Orange Cap & Purple Cap Cards side by side
            item {
                CapCardsRow(
                    orangeCap = viewModel.orangeCapLifetime,
                    purpleCap = viewModel.purpleCapLifetime
                )
            }

            // Teams Section
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Teams",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = extraColors.textPrimary
                        )

                        Text(
                            text = "All 10 >",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandBlue,
                            modifier = Modifier.clickable { }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp)
                    ) {
                        items(viewModel.all10Teams) { team ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable { }
                                    .testTag("team_item_${team.code}")
                            ) {
                                TeamLogoBadge(
                                    code = team.code,
                                    primaryColor = Color(team.primaryColorHex),
                                    secondaryColor = Color(team.secondaryColorHex),
                                    size = 52
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = team.code,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = extraColors.textPrimary
                                )
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
