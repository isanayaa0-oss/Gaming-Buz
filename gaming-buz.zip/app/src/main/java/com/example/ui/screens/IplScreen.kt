package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.IplTeamStanding
import com.example.data.model.NewsArticle
import com.example.data.model.NewsCategory
import com.example.ui.components.CompactNewsItemRow
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IplScreen(
  standings: List<IplTeamStanding>,
  newsList: List<NewsArticle>,
  bookmarkedIds: Set<String>,
  currentLanguage: AppLanguage,
  onArticleClick: (NewsArticle) -> Unit,
  onBookmarkToggle: (String) -> Unit,
  onBackClick: () -> Unit
) {
  var selectedTab by remember { mutableStateOf(0) } // 0: Points Table, 1: Caps & Stats, 2: News

  val iplNews = newsList.filter { it.category == NewsCategory.IPL }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = null, tint = Color(0xFF8E24AA))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = Localization.get("tab_ipl", currentLanguage),
              fontWeight = FontWeight.Bold,
              fontSize = 18.sp
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onBackClick) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
    ) {
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = Color(0xFF8E24AA)
      ) {
        Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Points Table", fontWeight = FontWeight.Bold) })
        Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Orange/Purple Cap", fontWeight = FontWeight.Bold) })
        Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("IPL News", fontWeight = FontWeight.Bold) })
      }

      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        when (selectedTab) {
          0 -> {
            item {
              Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Team", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(2.4f))
                    Text("M", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.6f))
                    Text("W", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.6f))
                    Text("L", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.6f))
                    Text("NRR", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text("Pts", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                  }
                  HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                  standings.forEach { team ->
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                      horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                      Text("${team.rank}. ${team.team}", fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(2.4f), maxLines = 1)
                      Text("${team.matches}", fontSize = 12.sp, modifier = Modifier.weight(0.6f))
                      Text("${team.won}", fontSize = 12.sp, modifier = Modifier.weight(0.6f))
                      Text("${team.lost}", fontSize = 12.sp, modifier = Modifier.weight(0.6f))
                      Text(team.nrr, fontSize = 11.sp, modifier = Modifier.weight(1f))
                      Text("${team.points}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CricketRed, modifier = Modifier.weight(0.8f))
                    }
                  }
                }
              }
            }
          }
          1 -> {
            item {
              // Orange Cap Card
              Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🟠", fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Orange Cap Leader (Most Runs)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFFE65100))
                  }
                  Spacer(modifier = Modifier.height(10.dp))
                  Text("Virat Kohli (RCB)", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF212121))
                  Text("741 Runs in 15 Matches • 1x 100, 5x 50 • Avg: 61.75 • SR: 154.7", fontSize = 13.sp, color = Color(0xFF424242))
                }
              }
            }
            item {
              // Purple Cap Card
              Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF3E5F5)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🟣", fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Purple Cap Leader (Most Wickets)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF6A1B9A))
                  }
                  Spacer(modifier = Modifier.height(10.dp))
                  Text("Jasprit Bumrah (MI)", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF212121))
                  Text("24 Wickets in 14 Matches • Best: 5/21 • Economy: 6.48", fontSize = 13.sp, color = Color(0xFF424242))
                }
              }
            }
          }
          2 -> {
            items(iplNews) { article ->
              CompactNewsItemRow(
                article = article,
                currentLanguage = currentLanguage,
                isBookmarked = bookmarkedIds.contains(article.id),
                onBookmarkToggle = { onBookmarkToggle(article.id) },
                onClick = { onArticleClick(article) }
              )
            }
          }
        }
      }
    }
  }
}
