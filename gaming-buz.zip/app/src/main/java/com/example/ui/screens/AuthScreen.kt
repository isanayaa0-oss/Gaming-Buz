package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserRole
import com.example.ui.theme.CricketRed
import com.example.ui.theme.IndiaBlue
import com.example.util.AppLanguage
import com.example.util.Localization

enum class AuthMode {
  GOOGLE,
  PHONE_OTP,
  EMAIL_PASSWORD,
  REGISTER
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
  currentLanguage: AppLanguage,
  generatedOtp: String?,
  onLoginGoogle: (String, UserRole) -> Unit,
  onSendOtp: (String) -> Unit,
  onVerifyOtp: (String, String, UserRole) -> Unit,
  onLoginEmail: (String, String, UserRole) -> Unit,
  onRegister: (String, String, String) -> Unit,
  onForgotPassword: (String) -> Unit,
  onBackClick: () -> Unit
) {
  // Role Selection State
  var selectedRole by remember { mutableStateOf(UserRole.NORMAL_USER) }
  var currentAuthMode by remember { mutableStateOf(AuthMode.GOOGLE) }

  // Fields
  var emailInput by remember { mutableStateOf("") }
  var passwordInput by remember { mutableStateOf("") }
  var nameInput by remember { mutableStateOf("") }
  var phoneInput by remember { mutableStateOf("") }
  var otpInput by remember { mutableStateOf("") }
  var otpSent by remember { mutableStateOf(false) }

  var showForgotPasswordDialog by remember { mutableStateOf(false) }
  var forgotEmailInput by remember { mutableStateOf("") }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Gaming Buz Authentication", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
        navigationIcon = {
          IconButton(onClick = onBackClick) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Gaming Buz Logo & Title
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = Icons.Default.SportsCricket, contentDescription = null, tint = CricketRed, modifier = Modifier.size(28.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "GAMING BUZ",
          fontWeight = FontWeight.Black,
          fontSize = 22.sp,
          color = CricketRed
        )
      }
      Text(
        text = Localization.get("tagline", currentLanguage),
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
      )

      Spacer(modifier = Modifier.height(20.dp))

      // 1. Two Separate Account Roles Selection Card
      Text(
        text = Localization.get("login_role_title", currentLanguage),
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
        modifier = Modifier.align(Alignment.Start)
      )
      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // User Role Button
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = if (selectedRole == UserRole.NORMAL_USER) CricketRed.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
          border = if (selectedRole == UserRole.NORMAL_USER) androidx.compose.foundation.BorderStroke(1.5.dp, CricketRed) else null,
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(12.dp))
            .clickable { selectedRole = UserRole.NORMAL_USER }
        ) {
          Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = if (selectedRole == UserRole.NORMAL_USER) CricketRed else MaterialTheme.colorScheme.onSurface)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = Localization.get("role_user", currentLanguage),
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = if (selectedRole == UserRole.NORMAL_USER) CricketRed else MaterialTheme.colorScheme.onSurface
            )
          }
        }

        // Admin Role Button
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = if (selectedRole == UserRole.ADMIN) IndiaBlue.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
          border = if (selectedRole == UserRole.ADMIN) androidx.compose.foundation.BorderStroke(1.5.dp, IndiaBlue) else null,
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(12.dp))
            .clickable { selectedRole = UserRole.ADMIN }
        ) {
          Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null, tint = if (selectedRole == UserRole.ADMIN) IndiaBlue else MaterialTheme.colorScheme.onSurface)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = Localization.get("role_admin", currentLanguage),
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = if (selectedRole == UserRole.ADMIN) IndiaBlue else MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }

      if (selectedRole == UserRole.ADMIN) {
        Spacer(modifier = Modifier.height(10.dp))
        Card(
          shape = RoundedCornerShape(8.dp),
          colors = CardDefaults.cardColors(containerColor = IndiaBlue.copy(alpha = 0.08f))
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = IndiaBlue, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = Localization.get("admin_role_notice", currentLanguage),
              fontSize = 11.sp,
              color = IndiaBlue,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // Auth Mode Switcher (Google / Phone / Email / Register)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        listOf(
          AuthMode.GOOGLE to "Google",
          AuthMode.PHONE_OTP to "Phone OTP",
          AuthMode.EMAIL_PASSWORD to "Email",
          AuthMode.REGISTER to "Register"
        ).forEach { (mode, label) ->
          val isSelected = currentAuthMode == mode
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (isSelected) CricketRed else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(8.dp))
              .clickable { currentAuthMode = mode }
          ) {
            Text(
              text = label,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.padding(vertical = 8.dp),
              textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))

      // 2. Auth Method Contents
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          when (currentAuthMode) {
            AuthMode.GOOGLE -> {
              Text(
                text = Localization.get("login_with_google", currentLanguage),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = if (selectedRole == UserRole.ADMIN)
                  "Sign in with your authorized Administrator Google account (e.g. admin@gamingbuz.com)."
                else
                  "Sign in with your Google account for personalized news and alerts.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
              )
              Spacer(modifier = Modifier.height(14.dp))

              OutlinedTextField(
                value = emailInput,
                onValueChange = { emailInput = it },
                label = { Text("Google Account Email") },
                placeholder = { Text(if (selectedRole == UserRole.ADMIN) "admin@gamingbuz.com" else "fan@gmail.com") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
              )

              Spacer(modifier = Modifier.height(14.dp))

              Button(
                onClick = {
                  val email = emailInput.ifBlank {
                    if (selectedRole == UserRole.ADMIN) "admin@gamingbuz.com" else "cricketfan@gmail.com"
                  }
                  onLoginGoogle(email, selectedRole)
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = if (selectedRole == UserRole.ADMIN) IndiaBlue else CricketRed),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(imageVector = Icons.Default.AccountCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = Localization.get("login_with_google", currentLanguage), fontWeight = FontWeight.Bold)
              }
            }

            AuthMode.PHONE_OTP -> {
              Text(
                text = Localization.get("login_with_phone", currentLanguage),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
              )
              Spacer(modifier = Modifier.height(10.dp))

              OutlinedTextField(
                value = phoneInput,
                onValueChange = { phoneInput = it.filter { char -> char.isDigit() }.take(10) },
                label = { Text(Localization.get("phone_number_label", currentLanguage)) },
                prefix = { Text("+91 ") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
              )

              Spacer(modifier = Modifier.height(10.dp))

              if (!otpSent) {
                Button(
                  onClick = {
                    onSendOtp(phoneInput.ifBlank { "9876543210" })
                    otpSent = true
                  },
                  modifier = Modifier.fillMaxWidth(),
                  colors = ButtonDefaults.buttonColors(containerColor = CricketRed),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Text(text = Localization.get("send_otp", currentLanguage), fontWeight = FontWeight.Bold)
                }
              } else {
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = Color(0xFFE8F5E9),
                  modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                  Text(
                    text = "✓ OTP Sent: Test code is ${generatedOtp ?: "123456"}",
                    color = Color(0xFF2E7D32),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(8.dp)
                  )
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                  value = otpInput,
                  onValueChange = { otpInput = it.take(6) },
                  label = { Text(Localization.get("enter_otp", currentLanguage)) },
                  placeholder = { Text("123456") },
                  singleLine = true,
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                  onClick = {
                    onVerifyOtp(
                      phoneInput.ifBlank { "9876543210" },
                      otpInput.ifBlank { "123456" },
                      selectedRole
                    )
                  },
                  modifier = Modifier.fillMaxWidth(),
                  colors = ButtonDefaults.buttonColors(containerColor = CricketRed),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Text(text = Localization.get("verify_otp", currentLanguage), fontWeight = FontWeight.Bold)
                }
              }
            }

            AuthMode.EMAIL_PASSWORD -> {
              Text(
                text = Localization.get("login_with_email", currentLanguage),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
              )
              Spacer(modifier = Modifier.height(10.dp))

              OutlinedTextField(
                value = emailInput,
                onValueChange = { emailInput = it },
                label = { Text(Localization.get("email_label", currentLanguage)) },
                placeholder = { Text(if (selectedRole == UserRole.ADMIN) "admin@gamingbuz.com" else "user@example.com") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
              )

              Spacer(modifier = Modifier.height(10.dp))

              OutlinedTextField(
                value = passwordInput,
                onValueChange = { passwordInput = it },
                label = { Text(Localization.get("password_label", currentLanguage)) },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
              )

              Spacer(modifier = Modifier.height(4.dp))

              TextButton(
                onClick = { showForgotPasswordDialog = true },
                modifier = Modifier.align(Alignment.End)
              ) {
                Text(
                  text = Localization.get("forgot_password", currentLanguage),
                  fontSize = 12.sp,
                  color = CricketRed
                )
              }

              Spacer(modifier = Modifier.height(8.dp))

              Button(
                onClick = {
                  val email = emailInput.ifBlank { if (selectedRole == UserRole.ADMIN) "admin@gamingbuz.com" else "fan@cricket.com" }
                  val pass = passwordInput.ifBlank { "password123" }
                  onLoginEmail(email, pass, selectedRole)
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = if (selectedRole == UserRole.ADMIN) IndiaBlue else CricketRed),
                shape = RoundedCornerShape(10.dp)
              ) {
                Text(text = Localization.get("sign_in_button", currentLanguage), fontWeight = FontWeight.Bold)
              }
            }

            AuthMode.REGISTER -> {
              Text(
                text = Localization.get("register_new", currentLanguage),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
              )
              Spacer(modifier = Modifier.height(10.dp))

              OutlinedTextField(
                value = nameInput,
                onValueChange = { nameInput = it },
                label = { Text("Full Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
              )

              Spacer(modifier = Modifier.height(10.dp))

              OutlinedTextField(
                value = emailInput,
                onValueChange = { emailInput = it },
                label = { Text(Localization.get("email_label", currentLanguage)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
              )

              Spacer(modifier = Modifier.height(10.dp))

              OutlinedTextField(
                value = passwordInput,
                onValueChange = { passwordInput = it },
                label = { Text(Localization.get("password_label", currentLanguage)) },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
              )

              Spacer(modifier = Modifier.height(14.dp))

              Button(
                onClick = {
                  onRegister(
                    nameInput.ifBlank { "Cricket Fan" },
                    emailInput.ifBlank { "fan@cricket.com" },
                    passwordInput.ifBlank { "pass1234" }
                  )
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = CricketRed),
                shape = RoundedCornerShape(10.dp)
              ) {
                Text(text = Localization.get("register_new", currentLanguage), fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }

  // Forgot Password Dialog
  if (showForgotPasswordDialog) {
    AlertDialog(
      onDismissRequest = { showForgotPasswordDialog = false },
      title = { Text(Localization.get("forgot_password", currentLanguage), fontWeight = FontWeight.Bold) },
      text = {
        Column {
          Text("Enter your email address to receive password reset link:")
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = forgotEmailInput,
            onValueChange = { forgotEmailInput = it },
            label = { Text("Email") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onForgotPassword(forgotEmailInput.ifBlank { "fan@cricket.com" })
            showForgotPasswordDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = CricketRed)
        ) {
          Text("Send Reset Link")
        }
      },
      dismissButton = {
        TextButton(onClick = { showForgotPasswordDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }
}
