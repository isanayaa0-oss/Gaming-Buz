package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CricketMatch
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchDetailScreen(
  match: CricketMatch,
  currentLanguage: AppLanguage,
  onBackClick: () -> Unit
) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = match.title,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            maxLines = 1
          )
        },
        navigationIcon = {
          IconButton(onClick = onBackClick) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back"
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    }
  ) { paddingValues ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
        .padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // 1. Match Summary Banner
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = match.seriesName,
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Teams & Scores
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceAround,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = match.team1.flagEmoji, fontSize = 34.sp)
                Text(text = match.team1.shortName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(text = match.team1.score, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = CricketRed)
                Text(text = match.team1.overs, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
              }
              Text(
                text = "VS",
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                fontSize = 18.sp
              )
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = match.team2.flagEmoji, fontSize = 34.sp)
                Text(text = match.team2.shortName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(text = match.team2.score, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                Text(text = match.team2.overs, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
              }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = match.statusMessage,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = CricketRed
            )
            Text(
              text = "Toss: ${match.tossDetails}",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            Text(
              text = "Venue: ${match.venue}",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
          }
        }
      }

      // 2. Recent Balls Ticker
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Recent: ",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.width(8.dp))
            match.recentOvers.split(" ").forEach { ball ->
              Box(
                modifier = Modifier
                  .size(24.dp)
                  .clip(CircleShape)
                  .background(
                    when (ball) {
                      "W" -> CricketRed
                      "4", "6" -> Color(0xFF2E7D32)
                      else -> MaterialTheme.colorScheme.surface
                    }
                  ),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = ball,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (ball == "W" || ball == "4" || ball == "6") Color.White else MaterialTheme.colorScheme.onSurface
                )
              }
              Spacer(modifier = Modifier.width(6.dp))
            }
          }
        }
      }

      // 3. Batting Scorecard
      if (match.batsmen.isNotEmpty()) {
        item {
          Text(
            text = "Batting",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onBackground
          )
          Spacer(modifier = Modifier.height(6.dp))
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Batter", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(2f))
                Text("R", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                Text("B", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                Text("4s", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                Text("6s", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                Text("SR", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1f))
              }
              HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
              match.batsmen.forEach { batter ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "${batter.name}${if (batter.isStriker) " *" else ""}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (batter.isStriker) CricketRed else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(2f)
                  )
                  Text("${batter.runs}", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(0.8f))
                  Text("${batter.balls}", fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                  Text("${batter.fours}", fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                  Text("${batter.sixes}", fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                  Text(String.format("%.1f", batter.strikeRate), fontSize = 12.sp, modifier = Modifier.weight(1f))
                }
              }
            }
          }
        }
      }

      // 4. Bowling Scorecard
      if (match.bowlers.isNotEmpty()) {
        item {
          Text(
            text = "Bowling",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onBackground
          )
          Spacer(modifier = Modifier.height(6.dp))
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Bowler", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(2f))
                Text("O", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                Text("M", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                Text("R", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                Text("W", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                Text("Econ", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1f))
              }
              HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
              match.bowlers.forEach { bowler ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(bowler.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(2f))
                  Text("${bowler.overs}", fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                  Text("${bowler.maidens}", fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                  Text("${bowler.runs}", fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                  Text("${bowler.wickets}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CricketRed, modifier = Modifier.weight(0.8f))
                  Text(String.format("%.2f", bowler.economy), fontSize = 12.sp, modifier = Modifier.weight(1f))
                }
              }
            }
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  }
}
