package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NorthEast
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.components.GamingBuzLogo
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LiveRed
import com.example.ui.theme.LocalExtraColors
import com.example.viewmodel.GamingBuzViewModel
import com.example.viewmodel.ScreenState

@Composable
fun ProfileDrawerContent(
    viewModel: GamingBuzViewModel,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current
    val currentLang by viewModel.currentLanguage.collectAsState()
    val currentTheme by viewModel.currentTheme.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    var regName by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("+91 98765 43210") }
    var regEmail by remember { mutableStateOf("") }
    var regPassword by remember { mutableStateOf("••••••••") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var isOtpEnabled by remember { mutableStateOf(true) }
    var regSuccessMessage by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = modifier
            .fillMaxWidth(0.88f)
            .fillMaxHeight(),
        color = extraColors.cardBackground,
        shadowElevation = 16.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            // Header: Close 'X' and Logo
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("drawer_close_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = extraColors.textPrimary
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                GamingBuzLogo(
                    iconSize = 32.dp,
                    textSize = 20.sp,
                    textColor = extraColors.textPrimary
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Language Selector Pills (English, Hindi, Bangla)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(extraColors.pillUnselected)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.padding(start = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🌐", fontSize = 16.sp)
                }

                AppLanguage.values().forEach { lang ->
                    val isSelected = currentLang == lang
                    val bg = if (isSelected) BrandBlue else Color.Transparent
                    val textColor = if (isSelected) Color.White else extraColors.pillTextUnselected

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(bg)
                            .clickable { viewModel.setLanguage(lang) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                            .testTag("drawer_lang_${lang.code}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isSelected) "${lang.nativeName} ✓" else lang.nativeName,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = textColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Profile Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { /* open profile detail */ }
                    .testTag("drawer_profile_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = extraColors.pillUnselected),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(BrandBlue.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (currentUser?.role == "admin") "AD" else "U",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandBlue
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentUser?.name ?: "Profile",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = extraColors.textPrimary
                        )
                        Text(
                            text = currentUser?.email ?: "user@email.com",
                            fontSize = 13.sp,
                            color = extraColors.textSecondary
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Go",
                        tint = extraColors.textSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Theme Switcher Quick Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(extraColors.pillUnselected)
                    .clickable { viewModel.toggleTheme() }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.DarkMode,
                        contentDescription = "Theme",
                        tint = BrandBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (currentTheme == AppThemeMode.BLACK_WHITE) "Theme: Black & White" else "Theme: Navy Dark",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = extraColors.textPrimary
                    )
                }
                Text(
                    text = "Switch",
                    fontSize = 12.sp,
                    color = BrandBlue,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // LOGIN OPTIONS Section
            Text(
                text = "LOGIN OPTIONS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = extraColors.textSecondary,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Option 1: User Login (Blue filled button)
            Button(
                onClick = { viewModel.showUserLoginDialog() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("drawer_user_login_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandBlue,
                    contentColor = Color.White
                )
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "User",
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "User Login",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Arrow"
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Option 2: Admin / Developer Login (White outlined button)
            OutlinedButton(
                onClick = { viewModel.showAdminLoginDialog() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("drawer_admin_login_button"),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, BrandBlue),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = BrandBlue
                )
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Admin Shield",
                        tint = BrandBlue,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Admin / Developer Login",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = BrandBlue,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Arrow",
                        tint = BrandBlue
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // REGISTRATION Section
            Text(
                text = "REGISTRATION",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = extraColors.textSecondary,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Name Field
            Text(text = "Name", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = extraColors.textPrimary)
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = regName,
                onValueChange = { regName = it },
                placeholder = { Text("Enter your full name", fontSize = 13.sp) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().testTag("reg_name_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrandBlue,
                    unfocusedBorderColor = extraColors.borderColor
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Phone Field
            Text(text = "Phone Number", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = extraColors.textPrimary)
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = regPhone,
                onValueChange = { regPhone = it },
                placeholder = { Text("+91 98765 43210", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Phone, contentDescription = "Phone", tint = BrandBlue)
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().testTag("reg_phone_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrandBlue,
                    unfocusedBorderColor = extraColors.borderColor
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Email Field
            Text(text = "Email Address", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = extraColors.textPrimary)
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = regEmail,
                onValueChange = { regEmail = it },
                placeholder = { Text("Enter email address", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Email, contentDescription = "Email", tint = BrandBlue)
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().testTag("reg_email_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrandBlue,
                    unfocusedBorderColor = extraColors.borderColor
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Password Field
            Text(text = "Password", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = extraColors.textPrimary)
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = regPassword,
                onValueChange = { regPassword = it },
                placeholder = { Text("Password", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = "Lock", tint = BrandBlue)
                },
                trailingIcon = {
                    IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                        Icon(
                            imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle Password"
                        )
                    }
                },
                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().testTag("reg_password_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrandBlue,
                    unfocusedBorderColor = extraColors.borderColor
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // OTP Verification Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Enable OTP Verification",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = extraColors.textPrimary
                    )
                    Text(
                        text = "Receive OTP on your phone for secure registration",
                        fontSize = 11.sp,
                        color = extraColors.textSecondary
                    )
                }

                Switch(
                    checked = isOtpEnabled,
                    onCheckedChange = { isOtpEnabled = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = BrandBlue
                    ),
                    modifier = Modifier.testTag("otp_switch")
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val nameToSet = regName.ifBlank { "Cricket Fan" }
                    val emailToSet = regEmail.ifBlank { "fan@gamingbuz.com" }
                    viewModel.performUserLogin(nameToSet, emailToSet, regPhone)
                    regSuccessMessage = "Account registered successfully with OTP verified!"
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("complete_registration_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandBlue)
            ) {
                Text("Complete Registration", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            regSuccessMessage?.let {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = it, color = BrandBlue, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Logout Link (Red with arrow ↗)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.logout() }
                    .padding(vertical = 8.dp)
                    .testTag("drawer_logout_button"),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Logout",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = LiveRed
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.NorthEast,
                    contentDescription = "Logout",
                    tint = LiveRed,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Footer
            Text(
                text = "Gaming Buz v2.1.0 • Privacy Policy • Terms",
                fontSize = 11.sp,
                color = extraColors.textSecondary,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
