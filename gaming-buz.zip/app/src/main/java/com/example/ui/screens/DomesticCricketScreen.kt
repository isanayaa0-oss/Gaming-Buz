package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.SportsBaseball
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NewsArticle
import com.example.data.model.NewsCategory
import com.example.ui.components.CompactNewsItemRow
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

data class DomesticTournament(val name: String, val type: String, val currentWinner: String, val matchesCount: Int)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DomesticCricketScreen(
  newsList: List<NewsArticle>,
  bookmarkedIds: Set<String>,
  currentLanguage: AppLanguage,
  onArticleClick: (NewsArticle) -> Unit,
  onBookmarkToggle: (String) -> Unit,
  onBackClick: () -> Unit
) {
  var selectedTab by remember { mutableStateOf(0) } // 0: Tournaments, 1: News, 2: Points Table

  val domesticNews = newsList.filter { it.category == NewsCategory.DOMESTIC }

  val tournaments = listOf(
    DomesticTournament("Ranji Trophy", "First-Class (4-day)", "Mumbai", 38),
    DomesticTournament("Vijay Hazare Trophy", "List A (50 Overs)", "Haryana", 38),
    DomesticTournament("Syed Mushtaq Ali Trophy", "Domestic T20", "Punjab", 38),
    DomesticTournament("Duleep Trophy", "Zonal First-Class", "India A", 4),
    DomesticTournament("Irani Cup", "One-off First-Class", "Rest of India", 1)
  )

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.SportsBaseball, contentDescription = null, tint = CricketRed)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = Localization.get("tab_domestic", currentLanguage),
              fontWeight = FontWeight.Bold,
              fontSize = 18.sp
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onBackClick) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
    ) {
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = CricketRed
      ) {
        Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Tournaments", fontWeight = FontWeight.Bold) })
        Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("News", fontWeight = FontWeight.Bold) })
        Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Ranji Points", fontWeight = FontWeight.Bold) })
      }

      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        when (selectedTab) {
          0 -> {
            items(tournaments) { tourney ->
              Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(text = tourney.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = CricketRed.copy(alpha = 0.1f)
                    ) {
                      Text(
                        text = tourney.type,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = CricketRed,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                      )
                    }
                  }
                  Spacer(modifier = Modifier.height(6.dp))
                  Text(
                    text = "Defending Champions: ${tourney.currentWinner}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                  )
                  Text(
                    text = "Teams Participating: ${tourney.matchesCount} State Teams",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                  )
                }
              }
            }
          }
          1 -> {
            items(domesticNews) { article ->
              CompactNewsItemRow(
                article = article,
                currentLanguage = currentLanguage,
                isBookmarked = bookmarkedIds.contains(article.id),
                onBookmarkToggle = { onBookmarkToggle(article.id) },
                onClick = { onArticleClick(article) }
              )
            }
          }
          2 -> {
            item {
              Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  Text(
                    text = "Ranji Trophy 2025-26 (Elite Group A)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = CricketRed
                  )
                  Spacer(modifier = Modifier.height(10.dp))
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Team", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(2f))
                    Text("Mat", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                    Text("Won", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                    Text("Pts", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                  }
                  HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                  val standings = listOf(
                    Triple("1. Mumbai", "4", "23"),
                    Triple("2. Saurashtra", "4", "18"),
                    Triple("3. Tamil Nadu", "4", "14"),
                    Triple("4. Delhi", "4", "12"),
                    Triple("5. Railways", "4", "7")
                  )
                  standings.forEach { (team, mat, pts) ->
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                      horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                      Text(team, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(2f))
                      Text(mat, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                      Text("${mat.toInt() - 1}", fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                      Text(pts, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = CricketRed, modifier = Modifier.weight(0.8f))
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
