package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LiveRed
import com.example.ui.theme.LocalExtraColors
import com.example.viewmodel.GamingBuzViewModel

@Composable
fun UserLoginDialog(
    viewModel: GamingBuzViewModel,
    onDismiss: () -> Unit
) {
    val extraColors = LocalExtraColors.current
    var selectedMethodTab by remember { mutableIntStateOf(0) } // 0: Phone + OTP, 1: Email + Password
    var phoneNumber by remember { mutableStateOf("+91 98765 43210") }
    var otpCode by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var otpSent by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .testTag("user_login_dialog"),
            colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = BrandBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "User Login",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = extraColors.textPrimary
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                TabRow(
                    selectedTabIndex = selectedMethodTab,
                    containerColor = extraColors.pillUnselected,
                    contentColor = BrandBlue
                ) {
                    Tab(
                        selected = selectedMethodTab == 0,
                        onClick = { selectedMethodTab = 0 },
                        text = { Text("Phone + OTP", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedMethodTab == 1,
                        onClick = { selectedMethodTab = 1 },
                        text = { Text("Email + Pass", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (selectedMethodTab == 0) {
                    // Phone + OTP
                    Text(text = "Phone Number", fontSize = 12.sp, color = extraColors.textSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = phoneNumber,
                        onValueChange = { phoneNumber = it },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("user_phone_login_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (!otpSent) {
                        Button(
                            onClick = { otpSent = true; otpCode = "5421" },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrandBlue)
                        ) {
                            Text("Send OTP via SMS", fontSize = 13.sp)
                        }
                    } else {
                        Text(text = "Enter 4-digit OTP (Code: 5421 sent)", fontSize = 12.sp, color = BrandBlue, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = otpCode,
                            onValueChange = { otpCode = it },
                            placeholder = { Text("Enter OTP") },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("user_otp_input")
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                viewModel.performUserLogin("Cricket Fan", "user@gamingbuz.com", phoneNumber)
                            },
                            modifier = Modifier.fillMaxWidth().testTag("verify_otp_btn"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrandBlue)
                        ) {
                            Text("Verify OTP & Login", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    // Email + Password
                    Text(text = "Email Address", fontSize = 12.sp, color = extraColors.textSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        placeholder = { Text("user@email.com") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("user_email_login_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(text = "Password", fontSize = 12.sp, color = extraColors.textSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("user_pass_login_input")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.performUserLogin(
                                email.substringBefore("@").ifBlank { "User" },
                                email.ifBlank { "user@email.com" },
                                "+91 98765 43210"
                            )
                        },
                        modifier = Modifier.fillMaxWidth().testTag("user_email_login_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue)
                    ) {
                        Text("Login", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminLoginDialog(
    viewModel: GamingBuzViewModel,
    onDismiss: () -> Unit
) {
    val extraColors = LocalExtraColors.current
    var email by remember { mutableStateOf("admin@gamingbuz.com") }
    var adminPassword by remember { mutableStateOf("admin123") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .testTag("admin_login_dialog"),
            colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = BrandBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Admin / Dev Login",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = extraColors.textPrimary
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Security Note
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFEF3C7))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "🔒 Security: Only verified Admin accounts can access the Admin Panel & Section Builder.",
                        fontSize = 11.sp,
                        color = Color(0xFF92400E),
                        lineHeight = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(text = "Admin Email", fontSize = 12.sp, color = extraColors.textSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it; errorMessage = null },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("admin_email_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(text = "Password / Developer Key", fontSize = 12.sp, color = extraColors.textSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = adminPassword,
                    onValueChange = { adminPassword = it; errorMessage = null },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("admin_pass_input")
                )

                errorMessage?.let {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = it, color = LiveRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val success = viewModel.performAdminLogin(email, adminPassword)
                        if (!success) {
                            errorMessage = "Invalid admin credentials. Use admin@gamingbuz.com and admin123."
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("admin_login_submit_btn"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandBlue)
                ) {
                    Text("Authenticate & Open Dashboard", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ScoreEditorDialog(
    viewModel: GamingBuzViewModel,
    onDismiss: () -> Unit
) {
    val extraColors = LocalExtraColors.current
    val currentMatch = viewModel.liveMatch.value

    var team1Score by remember { mutableStateOf(currentMatch.team1Score) }
    var team1Overs by remember { mutableStateOf(currentMatch.team1Overs) }
    var needRuns by remember { mutableStateOf(currentMatch.needRuns.toString()) }
    var needBalls by remember { mutableStateOf(currentMatch.needBalls.toString()) }
    var kohliRuns by remember { mutableStateOf(currentMatch.batsman1.runs.toString()) }
    var rohitRuns by remember { mutableStateOf(currentMatch.batsman2.runs.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .testTag("score_editor_dialog"),
            colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Edit Live Match Score",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = extraColors.textPrimary
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Text(
                    text = "Manual override for when external live score API is delayed or fails",
                    fontSize = 11.sp,
                    color = extraColors.textSecondary
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Score", fontSize = 11.sp, color = extraColors.textSecondary)
                        OutlinedTextField(
                            value = team1Score,
                            onValueChange = { team1Score = it },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("edit_score_input")
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Overs", fontSize = 11.sp, color = extraColors.textSecondary)
                        OutlinedTextField(
                            value = team1Overs,
                            onValueChange = { team1Overs = it },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("edit_overs_input")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Need Runs", fontSize = 11.sp, color = extraColors.textSecondary)
                        OutlinedTextField(
                            value = needRuns,
                            onValueChange = { needRuns = it },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "In Balls", fontSize = 11.sp, color = extraColors.textSecondary)
                        OutlinedTextField(
                            value = needBalls,
                            onValueChange = { needBalls = it },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Kohli Runs", fontSize = 11.sp, color = extraColors.textSecondary)
                        OutlinedTextField(
                            value = kohliRuns,
                            onValueChange = { kohliRuns = it },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Rohit Runs", fontSize = 11.sp, color = extraColors.textSecondary)
                        OutlinedTextField(
                            value = rohitRuns,
                            onValueChange = { rohitRuns = it },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        viewModel.updateScore(
                            team1Score = team1Score,
                            team1Overs = team1Overs,
                            needRuns = needRuns.toIntOrNull() ?: currentMatch.needRuns,
                            needBalls = needBalls.toIntOrNull() ?: currentMatch.needBalls,
                            kohliruns = kohliRuns.toIntOrNull() ?: currentMatch.batsman1.runs,
                            rohitruns = rohitRuns.toIntOrNull() ?: currentMatch.batsman2.runs
                        )
                    },
                    modifier = Modifier.fillMaxWidth().testTag("save_score_override_btn"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandBlue)
                ) {
                    Text("Save & Push Live Update", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
