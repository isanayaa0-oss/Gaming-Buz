package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NewsArticle
import com.example.ui.components.CompactNewsItemRow
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
  newsList: List<NewsArticle>,
  bookmarkedIds: Set<String>,
  currentLanguage: AppLanguage,
  onArticleClick: (NewsArticle) -> Unit,
  onBookmarkToggle: (String) -> Unit,
  onBackClick: () -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }

  val searchResults = remember(searchQuery, newsList, currentLanguage) {
    if (searchQuery.isBlank()) emptyList()
    else {
      val query = searchQuery.trim().lowercase()
      newsList.filter {
        it.getTitle(currentLanguage).lowercase().contains(query) ||
        it.getContent(currentLanguage).lowercase().contains(query) ||
        it.author.lowercase().contains(query)
      }
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(Localization.get("search_hint", currentLanguage), fontSize = 13.sp) },
            singleLine = true,
            trailingIcon = {
              if (searchQuery.isNotEmpty()) {
                IconButton(onClick = { searchQuery = "" }) {
                  Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                }
              }
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(50.dp),
            shape = RoundedCornerShape(24.dp)
          )
        },
        navigationIcon = {
          IconButton(onClick = onBackClick) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
    ) {
      if (searchQuery.isBlank()) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
            modifier = Modifier.size(64.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "Type a player name, team, or match to search",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            fontSize = 14.sp
          )
        }
      } else if (searchResults.isEmpty()) {
        Box(
          modifier = Modifier.fillMaxSize().padding(32.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(text = "No results found for \"$searchQuery\"", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
      } else {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
          items(searchResults) { article ->
            CompactNewsItemRow(
              article = article,
              currentLanguage = currentLanguage,
              isBookmarked = bookmarkedIds.contains(article.id),
              onBookmarkToggle = { onBookmarkToggle(article.id) },
              onClick = { onArticleClick(article) }
            )
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookmarksScreen(
  newsList: List<NewsArticle>,
  bookmarkedIds: Set<String>,
  currentLanguage: AppLanguage,
  onArticleClick: (NewsArticle) -> Unit,
  onBookmarkToggle: (String) -> Unit,
  onBackClick: () -> Unit
) {
  val savedArticles = newsList.filter { bookmarkedIds.contains(it.id) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(Localization.get("bookmarks", currentLanguage), fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBackClick) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
      )
    }
  ) { paddingValues ->
    if (savedArticles.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues)
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = Localization.get("no_bookmarks", currentLanguage),
          color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues)
          .background(MaterialTheme.colorScheme.background)
      ) {
        items(savedArticles) { article ->
          CompactNewsItemRow(
            article = article,
            currentLanguage = currentLanguage,
            isBookmarked = true,
            onBookmarkToggle = { onBookmarkToggle(article.id) },
            onClick = { onArticleClick(article) }
          )
        }
      }
    }
  }
}

data class NotificationItem(val title: String, val body: String, val time: String, val isUnread: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
  currentLanguage: AppLanguage,
  onBackClick: () -> Unit
) {
  val notifications = listOf(
    NotificationItem("MATCH RESULT", "India won by 4 runs against West Indies in Kolkata thriller!", "10m ago", true),
    NotificationItem("WICKET ALERT", "Arshdeep Singh castles Shai Hope in the final over!", "35m ago", true),
    NotificationItem("MILESTONE", "Tilak Varma scores 50 off 32 balls for India!", "1h ago", true),
    NotificationItem("TOSS UPDATE", "India won the toss and elected to bat first at Eden Gardens.", "3h ago", true),
    NotificationItem("BREAKING NEWS", "BCCI announces 15-member squad for upcoming Australia series.", "5h ago", false),
    NotificationItem("DOMESTIC UPDATE", "Mumbai advances to Ranji Trophy finals with a 7-wicket victory.", "Yesterday", false),
    NotificationItem("IPL 2025 ALERT", "Mega Auction retention rules finalized by IPL Governing Council.", "Yesterday", false),
    NotificationItem("WOMEN'S CRICKET", "Smriti Mandhana named ICC Player of the Month.", "2 days ago", false)
  )

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(Localization.get("notifications", currentLanguage), fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBackClick) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
      )
    }
  ) { paddingValues ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
        .padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      items(notifications) { notif ->
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (notif.isUnread) CricketRed.copy(alpha = 0.05f) else MaterialTheme.colorScheme.surface
          ),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
          ) {
            Icon(
              imageVector = Icons.Default.NotificationsActive,
              contentDescription = null,
              tint = if (notif.isUnread) CricketRed else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = notif.title,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (notif.isUnread) CricketRed else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Text(
                  text = notif.time,
                  fontSize = 10.sp,
                  color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = notif.body,
                fontSize = 13.sp,
                fontWeight = if (notif.isUnread) FontWeight.SemiBold else FontWeight.Normal,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }
    }
  }
}
