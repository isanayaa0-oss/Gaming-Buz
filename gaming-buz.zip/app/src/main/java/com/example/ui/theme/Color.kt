package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Gaming Buz Cricket Brand Colors
val CricketRed = Color(0xFFD32F2F)
val CricketRedDark = Color(0xFFB71C1C)
val CricketRedLight = Color(0xFFFFEBEE)
val CricketAccent = Color(0xFFFF5252)

val LiveGreen = Color(0xFF2E7D32)
val LiveGreenLight = Color(0xFFE8F5E9)

val IndiaBlue = Color(0xFF1976D2)
val IndiaBlueLight = Color(0xFFE3F2FD)

val TrophyGold = Color(0xFFF57C00)
val TrophyGoldLight = Color(0xFFFFF3E0)

// Clean White Theme (Light)
val LightBackground = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF8F9FA)
val LightSurfaceVariant = Color(0xFFF1F3F4)
val LightOnBackground = Color(0xFF1A1A1A)
val LightOnSurface = Color(0xFF202124)
val LightOutline = Color(0xFFE0E0E0)
val LightTextSecondary = Color(0xFF5F6368)

// Dark Theme
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkSurfaceVariant = Color(0xFF2C2C2C)
val DarkOnBackground = Color(0xFFE0E0E0)
val DarkOnSurface = Color(0xFFEEEEEE)
val DarkOutline = Color(0xFF3E3E3E)
val DarkTextSecondary = Color(0xFFA0A0A0)
