package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Colors
val BrandBlue = Color(0xFF0052FF)
val BrandDarkNavy = Color(0xFF0A1931)
val BrandOrange = Color(0xFFFF8C00)
val BrandLightBlue = Color(0xFF1E90FF)
val LiveRed = Color(0xFFE53935)

// Theme 1: Black & White / Clean Professional Light
val LightBackground = Color(0xFFF7F9FC)
val LightSurface = Color(0xFFFFFFFF)
val LightCardBackground = Color(0xFFFFFFFF)
val LightTextPrimary = Color(0xFF000000)
val LightTextSecondary = Color(0xFF6B7280)
val LightBorder = Color(0xFFE5E7EB)
val LightPillUnselected = Color(0xFFF0F4F8)
val LightPillTextUnselected = Color(0xFF4B5563)

// Live Card Light
val LiveCardGradStart = Color(0xFFD6E4FF)
val LiveCardGradEnd = Color(0xFFEFF4FF)

// Caps
val OrangeCapBg = Color(0xFFFFE8D6)
val OrangeCapText = Color(0xFFC05621)
val PurpleCapBg = Color(0xFFEADBFF)
val PurpleCapText = Color(0xFF6B46C1)

// Theme 2: Navy Blue Dark Mode
val DarkNavyBackground = Color(0xFF0A1931)
val DarkNavySurface = Color(0xFF112240)
val DarkNavyCardBackground = Color(0xFF182A4D)
val DarkNavyTextPrimary = Color(0xFFFFFFFF)
val DarkNavyTextSecondary = Color(0xFF94A3B8)
val DarkNavyBorder = Color(0xFF233554)
val DarkNavyPillUnselected = Color(0xFF1E3156)
val DarkNavyPillTextUnselected = Color(0xFFCBD5E1)

// Live Card Dark
val LiveCardDarkGradStart = Color(0xFF162E5A)
val LiveCardDarkGradEnd = Color(0xFF1E3A6E)
