package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.ui.NavDestination
import com.example.ui.theme.CricketRed
import com.example.ui.theme.IndiaBlue
import com.example.util.AppLanguage
import com.example.util.Localization

@Composable
fun SettingsAndLegalScreen(
  currentUser: UserProfile?,
  currentLanguage: AppLanguage,
  isDarkTheme: Boolean,
  onLanguageChange: (AppLanguage) -> Unit,
  onToggleTheme: () -> Unit,
  onNavigate: (NavDestination) -> Unit,
  onLogout: () -> Unit
) {
  var showLegalDialog by remember { mutableStateOf<String?>(null) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(14.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. User Account Card
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          if (currentUser != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(50.dp)
                  .clip(CircleShape)
                  .background(if (currentUser.role == UserRole.ADMIN) IndiaBlue else CricketRed),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = currentUser.displayName.take(1).uppercase(),
                  color = Color.White,
                  fontSize = 20.sp,
                  fontWeight = FontWeight.Bold
                )
              }
              Spacer(modifier = Modifier.width(14.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = currentUser.displayName,
                  fontSize = 17.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = currentUser.email ?: currentUser.phoneNumber ?: "Authenticated Fan",
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = if (currentUser.role == UserRole.ADMIN) IndiaBlue.copy(alpha = 0.12f) else CricketRed.copy(alpha = 0.12f)
                ) {
                  Text(
                    text = if (currentUser.role == UserRole.ADMIN) "AUTHORIZED ADMIN" else "FAN MEMBER",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (currentUser.role == UserRole.ADMIN) IndiaBlue else CricketRed,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              if (currentUser.role == UserRole.ADMIN) {
                Button(
                  onClick = { onNavigate(NavDestination.ADMIN_DASHBOARD) },
                  colors = ButtonDefaults.buttonColors(containerColor = IndiaBlue),
                  shape = RoundedCornerShape(10.dp),
                  modifier = Modifier.weight(1f)
                ) {
                  Icon(imageVector = Icons.Default.Dashboard, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Admin Panel", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
              }

              OutlinedButton(
                onClick = onLogout,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
              ) {
                Text(Localization.get("logout", currentLanguage), fontSize = 12.sp, color = CricketRed)
              }
            }
          } else {
            // Not Logged In
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(46.dp)
                  .clip(CircleShape)
                  .background(CricketRed.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(imageVector = Icons.Default.AccountCircle, contentDescription = null, tint = CricketRed)
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(text = "Gaming Buz Account", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(text = "Sign in to bookmark news & access admin tools", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
              }
            }
            Spacer(modifier = Modifier.height(14.dp))
            Button(
              onClick = { onNavigate(NavDestination.AUTH_SCREEN) },
              colors = ButtonDefaults.buttonColors(containerColor = CricketRed),
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(10.dp)
            ) {
              Text("Login / Register", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }



    // 3. Cricket Sections Quick Links
    item {
      Text(text = "Cricket Hubs", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
      Spacer(modifier = Modifier.height(6.dp))
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column {
          SettingsItemRow(
            icon = Icons.Default.SportsCricket,
            title = Localization.get("tab_team_india", currentLanguage),
            subtitle = "Men's, Women's, Fixtures & Playing XI",
            onClick = { onNavigate(NavDestination.TEAM_INDIA_SECTION) }
          )
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
          SettingsItemRow(
            icon = Icons.Default.SportsBaseball,
            title = Localization.get("tab_domestic", currentLanguage),
            subtitle = "Ranji Trophy, Vijay Hazare, Mushtaq Ali & Irani Cup",
            onClick = { onNavigate(NavDestination.DOMESTIC_SECTION) }
          )
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
          SettingsItemRow(
            icon = Icons.Default.EmojiEvents,
            title = Localization.get("tab_ipl", currentLanguage),
            subtitle = "Points table, Orange Cap, Purple Cap & Squads",
            onClick = { onNavigate(NavDestination.IPL_SECTION) }
          )
        }
      }
    }

    // 4. Legal & Info
    item {
      Text(text = "Information & Support", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
      Spacer(modifier = Modifier.height(6.dp))
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column {
          SettingsItemRow(
            icon = Icons.Default.Info,
            title = Localization.get("about_us", currentLanguage),
            subtitle = "Learn more about Gaming Buz Cricket Network",
            onClick = { showLegalDialog = "ABOUT" }
          )
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
          SettingsItemRow(
            icon = Icons.Default.Policy,
            title = Localization.get("privacy_policy", currentLanguage),
            subtitle = "Data protection and Google Play policies",
            onClick = { showLegalDialog = "PRIVACY" }
          )
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
          SettingsItemRow(
            icon = Icons.Default.Description,
            title = Localization.get("terms_conditions", currentLanguage),
            subtitle = "Editorial and user terms",
            onClick = { showLegalDialog = "TERMS" }
          )
          HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
          SettingsItemRow(
            icon = Icons.Default.Email,
            title = Localization.get("contact_us", currentLanguage),
            subtitle = "Contact Gaming Buz newsroom & support",
            onClick = { showLegalDialog = "CONTACT" }
          )
        }
      }
    }

    item {
      Column(
        modifier = Modifier.fillMaxWidth().padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text("Gaming Buz Cricket App", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CricketRed)
        Text("Version 1.0.0 • Universal Android Architecture", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
      }
    }
  }

  // Legal Information Dialog
  if (showLegalDialog != null) {
    AlertDialog(
      onDismissRequest = { showLegalDialog = null },
      title = {
        Text(
          text = when (showLegalDialog) {
            "ABOUT" -> "About Gaming Buz"
            "PRIVACY" -> "Privacy Policy"
            "TERMS" -> "Terms & Conditions"
            else -> "Contact Us"
          },
          fontWeight = FontWeight.Bold
        )
      },
      text = {
        Text(
          text = when (showLegalDialog) {
            "ABOUT" -> "Gaming Buz is an independent digital cricket news platform providing accurate ball-by-ball match updates, breaking news, detailed player statistics, Ranji Trophy & domestic cricket reports, and IPL tournament coverage in Hindi, English, and Bangla."
            "PRIVACY" -> "Gaming Buz respects user privacy. We do not sell personal information or require sensitive permissions. Standard device identifiers and notification tokens are used solely to deliver cricket match alerts in compliance with Google Play Developer policies."
            "TERMS" -> "All cricket articles, match reports, and analysis published on Gaming Buz are for editorial and informational purposes. Match scorecards and stats are verified via official cricket APIs."
            else -> "Gaming Buz Sports Desk\nEmail: contact@gamingbuz.com / earnteck@gmail.com\nHeadquarters: Kolkata & Mumbai, India\nSupport: Available 24/7 for match queries & editorial corrections."
          },
          fontSize = 13.sp,
          lineHeight = 19.sp
        )
      },
      confirmButton = {
        TextButton(onClick = { showLegalDialog = null }) {
          Text("Close", color = CricketRed)
        }
      }
    )
  }
}

@Composable
fun SettingsItemRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(14.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(imageVector = icon, contentDescription = null, tint = CricketRed, modifier = Modifier.size(24.dp))
    Spacer(modifier = Modifier.width(14.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
      Text(text = subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
    }
    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
  }
}
