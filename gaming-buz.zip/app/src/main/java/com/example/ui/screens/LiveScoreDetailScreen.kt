package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.components.BottomNavigationBar
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LiveRed
import com.example.ui.theme.LocalExtraColors
import com.example.viewmodel.GamingBuzViewModel
import com.example.viewmodel.ScreenState

@Composable
fun LiveScoreDetailScreen(
    viewModel: GamingBuzViewModel,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current
    val liveMatch by viewModel.liveMatch.collectAsState()
    val currentLang by viewModel.currentLanguage.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val gradientBrush = Brush.verticalGradient(
        colors = listOf(
            extraColors.liveCardBrushStart,
            extraColors.liveCardBrushEnd
        )
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = extraColors.cardBackground,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(extraColors.cardBackground)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenState.Home) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = extraColors.textPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Match Scorecard",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = extraColors.textPrimary
                    )
                }

                // If admin, show quick manual score editor button
                if (currentUser?.role == "admin") {
                    Button(
                        onClick = { viewModel.showScoreEditorDialog() },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(34.dp).testTag("admin_live_edit_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Edit Score", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        bottomBar = {
            BottomNavigationBar(
                selectedTab = "live",
                onTabSelected = { viewModel.selectBottomNav(it) },
                currentLanguage = currentLang
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(extraColors.cardBackground)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Header Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp)),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(gradientBrush)
                            .padding(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(LiveRed, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "LIVE MATCH",
                                        color = LiveRed,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = liveMatch.venue,
                                    fontSize = 11.sp,
                                    color = extraColors.textSecondary
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "${liveMatch.team1Name} vs ${liveMatch.team2Name}",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = extraColors.textPrimary
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "${liveMatch.team1Name} ${liveMatch.team1Score} (${liveMatch.team1Overs} ov)",
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrandBlue
                            )

                            Text(
                                text = "${liveMatch.team2Name} ${liveMatch.team2Score} (${liveMatch.team2Overs} ov)",
                                fontSize = 14.sp,
                                color = extraColors.textSecondary
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.9f))
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "Target ${liveMatch.target} • Need ${liveMatch.needRuns} runs in ${liveMatch.needBalls} balls (Req RR: ${(liveMatch.needRuns.toFloat() / (liveMatch.needBalls.toFloat() / 6f)).let { "%.2f".format(it) }})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BrandBlue
                                )
                            }
                        }
                    }
                }
            }

            // Batting Scorecard Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground),
                    border = androidx.compose.foundation.BorderStroke(1.dp, extraColors.borderColor)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Batting - ${liveMatch.team1Name}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = extraColors.textPrimary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "BATSMAN", fontSize = 12.sp, color = extraColors.textSecondary, modifier = Modifier.weight(1f))
                            Text(text = "R", fontSize = 12.sp, color = extraColors.textSecondary, modifier = Modifier.width(32.dp))
                            Text(text = "B", fontSize = 12.sp, color = extraColors.textSecondary, modifier = Modifier.width(32.dp))
                            Text(text = "4s", fontSize = 12.sp, color = extraColors.textSecondary, modifier = Modifier.width(28.dp))
                            Text(text = "6s", fontSize = 12.sp, color = extraColors.textSecondary, modifier = Modifier.width(28.dp))
                            Text(text = "SR", fontSize = 12.sp, color = extraColors.textSecondary, modifier = Modifier.width(44.dp))
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = extraColors.borderColor)

                        // Batsman 1
                        val b1 = liveMatch.batsman1
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "🏏 ${b1.name}*", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = extraColors.textPrimary, modifier = Modifier.weight(1f))
                            Text(text = "${b1.runs}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = BrandBlue, modifier = Modifier.width(32.dp))
                            Text(text = "${b1.balls}", fontSize = 13.sp, color = extraColors.textPrimary, modifier = Modifier.width(32.dp))
                            Text(text = "${b1.fours}", fontSize = 13.sp, color = extraColors.textPrimary, modifier = Modifier.width(28.dp))
                            Text(text = "${b1.sixes}", fontSize = 13.sp, color = extraColors.textPrimary, modifier = Modifier.width(28.dp))
                            Text(text = "${"%.1f".format((b1.runs.toFloat() / b1.balls.toFloat()) * 100)}", fontSize = 13.sp, color = extraColors.textSecondary, modifier = Modifier.width(44.dp))
                        }

                        // Batsman 2
                        val b2 = liveMatch.batsman2
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "🏏 ${b2.name}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = extraColors.textPrimary, modifier = Modifier.weight(1f))
                            Text(text = "${b2.runs}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = BrandBlue, modifier = Modifier.width(32.dp))
                            Text(text = "${b2.balls}", fontSize = 13.sp, color = extraColors.textPrimary, modifier = Modifier.width(32.dp))
                            Text(text = "${b2.fours}", fontSize = 13.sp, color = extraColors.textPrimary, modifier = Modifier.width(28.dp))
                            Text(text = "${b2.sixes}", fontSize = 13.sp, color = extraColors.textPrimary, modifier = Modifier.width(28.dp))
                            Text(text = "${"%.1f".format((b2.runs.toFloat() / b2.balls.toFloat()) * 100)}", fontSize = 13.sp, color = extraColors.textSecondary, modifier = Modifier.width(44.dp))
                        }
                    }
                }
            }

            // Ball by Ball commentary snippet
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground),
                    border = androidx.compose.foundation.BorderStroke(1.dp, extraColors.borderColor)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Live Commentary",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = extraColors.textPrimary
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        listOf(
                            "48.2" to "Alzarri to Rohit, SIX! Dispatched over deep midwicket! Massive strike!",
                            "48.1" to "Alzarri to Rohit, 2 runs, driven powerfully down to long off.",
                            "47.6" to "Holder to Kohli, FOUR! Beautiful wristy flick past square leg to the fence!",
                            "47.5" to "Holder to Kohli, 1 run, tucked away neatly behind square."
                        ).forEach { (over, text) ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(BrandBlue.copy(alpha = 0.1f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(text = over, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BrandBlue)
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(text = text, fontSize = 13.sp, color = extraColors.textPrimary, lineHeight = 18.sp)
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
