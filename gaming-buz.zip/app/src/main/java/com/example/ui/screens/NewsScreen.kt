package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NewsArticle
import com.example.data.model.NewsCategory
import com.example.ui.components.CompactNewsItemRow
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

@Composable
fun NewsScreen(
  newsList: List<NewsArticle>,
  bookmarkedIds: Set<String>,
  currentLanguage: AppLanguage,
  onArticleClick: (NewsArticle) -> Unit,
  onBookmarkToggle: (String) -> Unit
) {
  var selectedCategoryFilter by remember { mutableStateOf<NewsCategory?>(null) }

  val filteredArticles = remember(newsList, selectedCategoryFilter) {
    if (selectedCategoryFilter == null) newsList
    else newsList.filter { it.category == selectedCategoryFilter }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // Title
    Text(
      text = Localization.get("nav_news", currentLanguage),
      fontSize = 22.sp,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onBackground,
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
    )

    // Category Filter Chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 14.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      FilterChip(
        selected = selectedCategoryFilter == null,
        onClick = { selectedCategoryFilter = null },
        label = { Text("All News") },
        colors = FilterChipDefaults.filterChipColors(
          selectedContainerColor = CricketRed,
          selectedLabelColor = MaterialTheme.colorScheme.onPrimary
        )
      )

      NewsCategory.entries.forEach { cat ->
        FilterChip(
          selected = selectedCategoryFilter == cat,
          onClick = { selectedCategoryFilter = cat },
          label = { Text(Localization.get(cat.translationKey, currentLanguage)) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = CricketRed,
            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
          )
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // List of Articles
    LazyColumn(modifier = Modifier.fillMaxSize()) {
      items(filteredArticles) { article ->
        CompactNewsItemRow(
          article = article,
          currentLanguage = currentLanguage,
          isBookmarked = bookmarkedIds.contains(article.id),
          onBookmarkToggle = { onBookmarkToggle(article.id) },
          onClick = { onArticleClick(article) }
        )
        HorizontalDivider(
          modifier = Modifier.padding(horizontal = 14.dp),
          color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
        )
      }
      item {
        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  }
}
