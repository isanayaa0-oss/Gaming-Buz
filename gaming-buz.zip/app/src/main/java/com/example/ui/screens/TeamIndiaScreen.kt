package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BottomNavigationBar
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LocalExtraColors
import com.example.viewmodel.GamingBuzViewModel
import com.example.viewmodel.ScreenState

@Composable
fun TeamIndiaScreen(
    viewModel: GamingBuzViewModel,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current
    val currentLang by viewModel.currentLanguage.collectAsState()

    val squad = listOf(
        "Rohit Sharma (C)" to "Top-order Batsman",
        "Virat Kohli" to "Top-order Batsman",
        "Shubman Gill (VC)" to "Opening Batsman",
        "Suryakumar Yadav" to "Middle-order Batsman",
        "Rishabh Pant (WK)" to "Wicket-keeper Batsman",
        "Hardik Pandya" to "All-rounder",
        "Ravindra Jadeja" to "All-rounder",
        "Jasprit Bumrah" to "Fast Bowler",
        "Mohammed Siraj" to "Fast Bowler",
        "Kuldeep Yadav" to "Spin Bowler",
        "Arshdeep Singh" to "Fast Bowler"
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = extraColors.cardBackground,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(extraColors.cardBackground)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenState.Home) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = extraColors.textPrimary
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "🇮🇳 Team India Hub",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = extraColors.textPrimary
                )
            }
        },
        bottomBar = {
            BottomNavigationBar(
                selectedTab = "home",
                onTabSelected = { viewModel.selectBottomNav(it) },
                currentLanguage = currentLang
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(extraColors.cardBackground)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = BrandBlue)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🇮🇳", fontSize = 28.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "BCCI • Team India",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Men in Blue • ICC Rank #1",
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Current Squad",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = extraColors.textPrimary
                )
            }

            items(squad) { (name, role) ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = extraColors.pillUnselected)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(BrandBlue.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🏏", fontSize = 16.sp)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(text = name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = extraColors.textPrimary)
                            Text(text = role, fontSize = 11.sp, color = extraColors.textSecondary)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
