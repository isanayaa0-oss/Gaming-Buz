package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CricketMatch
import com.example.data.model.NewsArticle
import com.example.data.model.NewsCategory
import com.example.ui.components.CompactNewsItemRow
import com.example.ui.components.LiveMatchCard
import com.example.ui.theme.CricketRed
import com.example.ui.theme.IndiaBlue
import com.example.util.AppLanguage
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamIndiaScreen(
  newsList: List<NewsArticle>,
  matchesList: List<CricketMatch>,
  bookmarkedIds: Set<String>,
  currentLanguage: AppLanguage,
  onArticleClick: (NewsArticle) -> Unit,
  onBookmarkToggle: (String) -> Unit,
  onMatchClick: (CricketMatch) -> Unit,
  onBackClick: () -> Unit
) {
  var selectedTab by remember { mutableStateOf(0) } // 0: Men, 1: Women, 2: Fixtures, 3: Squad

  val teamIndiaNews = newsList.filter {
    it.category == NewsCategory.TEAM_INDIA || (selectedTab == 1 && it.category == NewsCategory.WOMENS)
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "🇮🇳", fontSize = 22.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = Localization.get("tab_team_india", currentLanguage),
              fontWeight = FontWeight.Bold,
              fontSize = 18.sp
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onBackClick) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
    ) {
      // Sub-tabs: Men's, Women's, Fixtures, Squad / Playing XI
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = IndiaBlue
      ) {
        Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Men's", fontWeight = FontWeight.Bold) })
        Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Women's", fontWeight = FontWeight.Bold) })
        Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Fixtures", fontWeight = FontWeight.Bold) })
        Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Playing XI", fontWeight = FontWeight.Bold) })
      }

      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        when (selectedTab) {
          0, 1 -> {
            item {
              Text(
                text = if (selectedTab == 0) "Latest Team India (Men's) Updates" else "Indian Women's Cricket News",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
              )
            }
            items(teamIndiaNews) { article ->
              CompactNewsItemRow(
                article = article,
                currentLanguage = currentLanguage,
                isBookmarked = bookmarkedIds.contains(article.id),
                onBookmarkToggle = { onBookmarkToggle(article.id) },
                onClick = { onArticleClick(article) }
              )
            }
          }
          2 -> {
            item {
              Text(
                text = "Upcoming & Recent India Matches",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
              )
            }
            items(matchesList) { match ->
              LiveMatchCard(match = match, onClick = { onMatchClick(match) })
            }
          }
          3 -> {
            item {
              Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Groups, contentDescription = null, tint = IndiaBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = "India Playing XI (3rd T20I vs WI)",
                      fontWeight = FontWeight.Bold,
                      fontSize = 16.sp
                    )
                  }
                  Spacer(modifier = Modifier.height(12.dp))
                  val playingXI = listOf(
                    "1. Yashasvi Jaiswal", "2. Shubman Gill", "3. Suryakumar Yadav (C)",
                    "4. Tilak Varma", "5. Hardik Pandya", "6. Rinku Singh",
                    "7. Sanju Samson (WK)", "8. Axar Patel", "9. Kuldeep Yadav",
                    "10. Jasprit Bumrah", "11. Arshdeep Singh"
                  )
                  playingXI.forEach { player ->
                    Text(
                      text = player,
                      fontSize = 14.sp,
                      modifier = Modifier.padding(vertical = 4.dp),
                      color = MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
