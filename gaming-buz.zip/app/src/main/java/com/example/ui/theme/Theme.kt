package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

enum class AppThemeMode {
    BLACK_WHITE,  // Theme 1: White background #FFFFFF, Black text #000000, clean professional
    NAVY_DARK     // Theme 2: Navy Blue #0A1931 + Orange/Blue Accent #1E90FF & #FF8C00
}

data class ExtraColors(
    val brandBlue: Color,
    val cardBackground: Color,
    val liveCardBrushStart: Color,
    val liveCardBrushEnd: Color,
    val pillUnselected: Color,
    val pillTextUnselected: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val borderColor: Color,
    val orangeCapBg: Color,
    val orangeCapText: Color,
    val purpleCapBg: Color,
    val purpleCapText: Color,
)

val LocalExtraColors = staticCompositionLocalOf {
    ExtraColors(
        brandBlue = BrandBlue,
        cardBackground = LightCardBackground,
        liveCardBrushStart = LiveCardGradStart,
        liveCardBrushEnd = LiveCardGradEnd,
        pillUnselected = LightPillUnselected,
        pillTextUnselected = LightPillTextUnselected,
        textPrimary = LightTextPrimary,
        textSecondary = LightTextSecondary,
        borderColor = LightBorder,
        orangeCapBg = OrangeCapBg,
        orangeCapText = OrangeCapText,
        purpleCapBg = PurpleCapBg,
        purpleCapText = PurpleCapText
    )
}

private val LightColorScheme = lightColorScheme(
    primary = BrandBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4FF),
    onPrimaryContainer = BrandDarkNavy,
    secondary = BrandLightBlue,
    onSecondary = Color.White,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = LightTextSecondary,
    outline = LightBorder
)

private val NavyDarkColorScheme = darkColorScheme(
    primary = BrandLightBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1E3A6E),
    onPrimaryContainer = Color.White,
    secondary = BrandOrange,
    onSecondary = Color.Black,
    background = DarkNavyBackground,
    onBackground = DarkNavyTextPrimary,
    surface = DarkNavySurface,
    onSurface = DarkNavyTextPrimary,
    surfaceVariant = Color(0xFF1E3156),
    onSurfaceVariant = DarkNavyTextSecondary,
    outline = DarkNavyBorder
)

@Composable
fun GamingBuzTheme(
    themeMode: AppThemeMode = AppThemeMode.BLACK_WHITE,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        AppThemeMode.BLACK_WHITE -> LightColorScheme
        AppThemeMode.NAVY_DARK -> NavyDarkColorScheme
    }

    val extraColors = when (themeMode) {
        AppThemeMode.BLACK_WHITE -> ExtraColors(
            brandBlue = BrandBlue,
            cardBackground = LightCardBackground,
            liveCardBrushStart = LiveCardGradStart,
            liveCardBrushEnd = LiveCardGradEnd,
            pillUnselected = LightPillUnselected,
            pillTextUnselected = LightPillTextUnselected,
            textPrimary = LightTextPrimary,
            textSecondary = LightTextSecondary,
            borderColor = LightBorder,
            orangeCapBg = OrangeCapBg,
            orangeCapText = OrangeCapText,
            purpleCapBg = PurpleCapBg,
            purpleCapText = PurpleCapText
        )
        AppThemeMode.NAVY_DARK -> ExtraColors(
            brandBlue = BrandLightBlue,
            cardBackground = DarkNavyCardBackground,
            liveCardBrushStart = LiveCardDarkGradStart,
            liveCardBrushEnd = LiveCardDarkGradEnd,
            pillUnselected = DarkNavyPillUnselected,
            pillTextUnselected = DarkNavyPillTextUnselected,
            textPrimary = DarkNavyTextPrimary,
            textSecondary = DarkNavyTextSecondary,
            borderColor = DarkNavyBorder,
            orangeCapBg = Color(0xFF332015),
            orangeCapText = Color(0xFFFFA726),
            purpleCapBg = Color(0xFF2B1D42),
            purpleCapText = Color(0xFFCE93D8)
        )
    }

    CompositionLocalProvider(LocalExtraColors provides extraColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
