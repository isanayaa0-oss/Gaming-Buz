package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
  primary = CricketRed,
  onPrimary = Color.White,
  primaryContainer = CricketRedLight,
  onPrimaryContainer = CricketRedDark,
  secondary = IndiaBlue,
  onSecondary = Color.White,
  secondaryContainer = IndiaBlueLight,
  onSecondaryContainer = IndiaBlue,
  tertiary = LiveGreen,
  onTertiary = Color.White,
  tertiaryContainer = LiveGreenLight,
  onTertiaryContainer = LiveGreen,
  background = LightBackground,
  onBackground = LightOnBackground,
  surface = LightSurface,
  onSurface = LightOnSurface,
  surfaceVariant = LightSurfaceVariant,
  outline = LightOutline
)

private val DarkColorScheme = darkColorScheme(
  primary = CricketAccent,
  onPrimary = Color.Black,
  primaryContainer = CricketRedDark,
  onPrimaryContainer = Color.White,
  secondary = IndiaBlueLight,
  onSecondary = Color.Black,
  secondaryContainer = Color(0xFF0D47A1),
  onSecondaryContainer = Color.White,
  tertiary = Color(0xFF81C784),
  onTertiary = Color.Black,
  background = DarkBackground,
  onBackground = DarkOnBackground,
  surface = DarkSurface,
  onSurface = DarkOnSurface,
  surfaceVariant = DarkSurfaceVariant,
  outline = DarkOutline
)

@Composable
fun GamingBuzTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as? Activity)?.window
      if (window != null) {
        window.statusBarColor = colorScheme.background.toArgb()
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = !darkTheme
        controller.hide(androidx.core.view.WindowInsetsCompat.Type.statusBars())
      }
    }
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
