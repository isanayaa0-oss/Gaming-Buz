package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PointsTableRow
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LocalExtraColors

@Composable
fun PointsTableView(
    rows: List<PointsTableRow>,
    onSeeAllClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(20.dp))
            .testTag("ipl_points_table_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header: Points Table + See all >
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Points Table",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = extraColors.textPrimary
                )

                Text(
                    text = "See all >",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandBlue,
                    modifier = Modifier.clickable { onSeeAllClick() }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Column Headers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "POS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = extraColors.textSecondary,
                    modifier = Modifier.width(36.dp)
                )

                Text(
                    text = "TEAM",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = extraColors.textSecondary,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = "M",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = extraColors.textSecondary,
                    modifier = Modifier.width(30.dp)
                )

                Text(
                    text = "W",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = extraColors.textSecondary,
                    modifier = Modifier.width(30.dp)
                )

                Text(
                    text = "L",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = extraColors.textSecondary,
                    modifier = Modifier.width(28.dp)
                )

                Text(
                    text = "PTS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = extraColors.textSecondary,
                    modifier = Modifier.width(34.dp)
                )

                Text(
                    text = "NRR",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = extraColors.textSecondary,
                    modifier = Modifier.width(46.dp)
                )
            }

            HorizontalDivider(color = extraColors.borderColor.copy(alpha = 0.5f), thickness = 1.dp)

            // Rows
            rows.forEachIndexed { index, row ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${row.position}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = extraColors.textPrimary,
                        modifier = Modifier.width(36.dp)
                    )

                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TeamLogoBadge(
                            code = row.teamCode,
                            primaryColor = Color(row.primaryColorHex),
                            secondaryColor = Color(row.secondaryColorHex),
                            size = 30
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Column {
                            Text(
                                text = row.teamCode,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = extraColors.textPrimary
                            )
                            Text(
                                text = row.teamFullName,
                                fontSize = 10.sp,
                                color = extraColors.textSecondary,
                                maxLines = 1
                            )
                        }
                    }

                    Text(
                        text = "${row.matches}",
                        fontSize = 13.sp,
                        color = extraColors.textPrimary,
                        modifier = Modifier.width(30.dp)
                    )

                    Text(
                        text = "${row.won}",
                        fontSize = 13.sp,
                        color = extraColors.textPrimary,
                        modifier = Modifier.width(30.dp)
                    )

                    Text(
                        text = "${row.lost}",
                        fontSize = 13.sp,
                        color = extraColors.textPrimary,
                        modifier = Modifier.width(28.dp)
                    )

                    Text(
                        text = "${row.points}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = extraColors.textPrimary,
                        modifier = Modifier.width(34.dp)
                    )

                    Text(
                        text = row.nrr,
                        fontSize = 12.sp,
                        color = if (row.nrr.startsWith("+")) BrandBlue else extraColors.textSecondary,
                        modifier = Modifier.width(46.dp)
                    )
                }

                if (index < rows.size - 1) {
                    HorizontalDivider(color = extraColors.borderColor.copy(alpha = 0.3f), thickness = 0.5.dp)
                }
            }
        }
    }
}
