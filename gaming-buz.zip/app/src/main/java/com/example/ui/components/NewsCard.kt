package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.NewsArticle
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LocalExtraColors

@Composable
fun NewsThumbnail(
    type: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF1E293B)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            when (type) {
                "rohit" -> {
                    // Blue cricket jersey background
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF0D47A1), Color(0xFF1976D2), Color(0xFF42A5F5))
                        )
                    )
                    // Bat silhouette
                    drawLine(
                        color = Color(0xFFD7CCC8),
                        start = Offset(w * 0.7f, h * 0.2f),
                        end = Offset(w * 0.3f, h * 0.8f),
                        strokeWidth = w * 0.12f
                    )
                    // Helmet/player silhouette
                    drawCircle(
                        color = Color(0xFF0A1931),
                        radius = w * 0.16f,
                        center = Offset(w * 0.45f, h * 0.38f)
                    )
                }
                "kohli" -> {
                    // Indian blue jersey with gold banner
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF0B1953), Color(0xFF1565C0), Color(0xFF1E88E5))
                        )
                    )
                    // Raised bat gesture
                    drawLine(
                        color = Color(0xFFFFB300),
                        start = Offset(w * 0.35f, h * 0.18f),
                        end = Offset(w * 0.35f, h * 0.75f),
                        strokeWidth = w * 0.1f
                    )
                    drawCircle(
                        color = Color(0xFF002244),
                        radius = w * 0.17f,
                        center = Offset(w * 0.55f, h * 0.4f)
                    )
                }
                else -> {
                    // Stadium floodlights night scene
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF0A192F), Color(0xFF172A45), Color(0xFF2E7D32))
                        )
                    )
                    // Floodlight glow
                    drawCircle(Color(0xFFFFF9C4), radius = w * 0.12f, center = Offset(w * 0.25f, h * 0.25f))
                    drawCircle(Color(0xFFFFF9C4), radius = w * 0.12f, center = Offset(w * 0.75f, h * 0.25f))
                    // Ground turf line
                    drawLine(
                        color = Color(0xFF43A047),
                        start = Offset(0f, h * 0.7f),
                        end = Offset(w, h * 0.7f),
                        strokeWidth = h * 0.3f
                    )
                }
            }
        }
    }
}

@Composable
fun NewsCard(
    article: NewsArticle,
    currentLanguage: AppLanguage,
    onArticleClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onArticleClick() }
            .testTag("news_card_${article.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail
            NewsThumbnail(
                type = article.thumbnailType,
                modifier = Modifier
                    .size(width = 96.dp, height = 74.dp)
            )

            Spacer(modifier = Modifier.width(14.dp))

            // Text Info
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = article.localizedTitle(currentLanguage),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = extraColors.textPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "• ${article.localizedTimeAgo(currentLanguage)} • ${article.views}",
                    fontSize = 12.sp,
                    color = extraColors.textSecondary,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
