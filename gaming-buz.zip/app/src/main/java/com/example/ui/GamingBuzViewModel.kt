package com.example.ui

import androidx.lifecycle.ViewModel
import com.example.data.model.*
import com.example.data.repository.AuthRepository
import com.example.data.repository.CricketRepository
import com.example.util.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class NavDestination {
  HOME,
  NEWS,
  LIVE_SCORE,
  VIDEOS,
  MORE,
  ARTICLE_DETAIL,
  MATCH_DETAIL,
  SEARCH,
  BOOKMARKS,
  NOTIFICATIONS,
  ADMIN_DASHBOARD,
  AUTH_SCREEN,
  DOMESTIC_SECTION,
  TEAM_INDIA_SECTION,
  IPL_SECTION
}

class GamingBuzViewModel(
  private val cricketRepo: CricketRepository = CricketRepository(),
  private val authRepo: AuthRepository = AuthRepository()
) : ViewModel() {

  // Current Screen / Route
  private val _currentScreen = MutableStateFlow(NavDestination.HOME)
  val currentScreen: StateFlow<NavDestination> = _currentScreen.asStateFlow()

  // Language
  private val _currentLanguage = MutableStateFlow(AppLanguage.HINDI)
  val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

  // Theme
  private val _isDarkTheme = MutableStateFlow(false)
  val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

  // Home top category tab selection
  private val _selectedHomeTab = MutableStateFlow(NewsCategory.TOP_NEWS)
  val selectedHomeTab: StateFlow<NewsCategory> = _selectedHomeTab.asStateFlow()

  // Active Selected Article & Match
  private val _selectedArticle = MutableStateFlow<NewsArticle?>(null)
  val selectedArticle: StateFlow<NewsArticle?> = _selectedArticle.asStateFlow()

  private val _selectedMatch = MutableStateFlow<CricketMatch?>(null)
  val selectedMatch: StateFlow<CricketMatch?> = _selectedMatch.asStateFlow()

  private val _activeVideo = MutableStateFlow<CricketVideo?>(null)
  val activeVideo: StateFlow<CricketVideo?> = _activeVideo.asStateFlow()

  // Search
  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  // Feedback Snackbar / Notice
  private val _userFeedback = MutableStateFlow<String?>(null)
  val userFeedback: StateFlow<String?> = _userFeedback.asStateFlow()

  // Exposed Repository Flows
  val newsList = cricketRepo.newsList
  val bookmarkedIds = cricketRepo.bookmarkedIds
  val matchesList = cricketRepo.matchesList
  val videosList = cricketRepo.videosList
  val iplStandings = cricketRepo.iplStandings
  val currentUser = authRepo.currentUser
  val generatedOtp = authRepo.generatedOtp

  fun setLanguage(language: AppLanguage) {
    _currentLanguage.value = language
  }

  fun toggleTheme() {
    _isDarkTheme.value = !_isDarkTheme.value
  }

  fun navigateTo(destination: NavDestination) {
    _currentScreen.value = destination
  }

  fun setHomeTab(category: NewsCategory) {
    _selectedHomeTab.value = category
  }

  fun openArticle(article: NewsArticle) {
    _selectedArticle.value = article
    _currentScreen.value = NavDestination.ARTICLE_DETAIL
  }

  fun openMatch(match: CricketMatch) {
    _selectedMatch.value = match
    _currentScreen.value = NavDestination.MATCH_DETAIL
  }

  fun openVideo(video: CricketVideo) {
    _activeVideo.value = video
  }

  fun closeVideo() {
    _activeVideo.value = null
  }

  fun toggleBookmark(articleId: String) {
    cricketRepo.toggleBookmark(articleId)
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun clearFeedback() {
    _userFeedback.value = null
  }

  // Auth Operations
  fun loginGoogle(email: String, role: UserRole) {
    val res = authRepo.loginWithGoogle(email, role)
    if (res.isSuccess) {
      _userFeedback.value = "Welcome back, ${res.getOrNull()?.displayName}!"
      _currentScreen.value = if (role == UserRole.ADMIN) NavDestination.ADMIN_DASHBOARD else NavDestination.HOME
    } else {
      _userFeedback.value = res.exceptionOrNull()?.message
    }
  }

  fun sendOtp(phoneNumber: String) {
    val res = authRepo.sendOtp(phoneNumber)
    _userFeedback.value = res.getOrElse { it.message ?: "Failed to send OTP" }
  }

  fun verifyOtp(phoneNumber: String, otp: String, role: UserRole) {
    val res = authRepo.verifyOtp(phoneNumber, otp, role)
    if (res.isSuccess) {
      _userFeedback.value = "Phone login successful!"
      _currentScreen.value = if (role == UserRole.ADMIN) NavDestination.ADMIN_DASHBOARD else NavDestination.HOME
    } else {
      _userFeedback.value = res.exceptionOrNull()?.message
    }
  }

  fun loginEmail(email: String, pass: String, role: UserRole) {
    val res = authRepo.loginWithEmail(email, pass, role)
    if (res.isSuccess) {
      _userFeedback.value = "Signed in as ${res.getOrNull()?.displayName}!"
      _currentScreen.value = if (role == UserRole.ADMIN) NavDestination.ADMIN_DASHBOARD else NavDestination.HOME
    } else {
      _userFeedback.value = res.exceptionOrNull()?.message
    }
  }

  fun registerUser(name: String, email: String, pass: String) {
    val res = authRepo.register(name, email, pass)
    if (res.isSuccess) {
      _userFeedback.value = "Account created successfully!"
      _currentScreen.value = NavDestination.HOME
    } else {
      _userFeedback.value = res.exceptionOrNull()?.message
    }
  }

  fun forgotPassword(email: String) {
    val res = authRepo.resetPassword(email)
    _userFeedback.value = res.getOrElse { it.message ?: "Error sending reset email" }
  }

  fun logout() {
    authRepo.logout()
    _userFeedback.value = "Logged out successfully"
    _currentScreen.value = NavDestination.HOME
  }

  // Admin Publishing
  fun publishArticle(
    title: String,
    content: String,
    category: NewsCategory,
    imageUrl: String,
    isBreaking: Boolean,
    isDraft: Boolean
  ) {
    val created = cricketRepo.publishArticle(title, content, category, imageUrl, isBreaking, isDraft)
    _userFeedback.value = "Article \"${created.titleHi.take(25)}...\" published to Gaming Buz!"
  }

  fun deleteArticle(id: String) {
    cricketRepo.deleteArticle(id)
    _userFeedback.value = "Article removed successfully"
  }

  fun addVideo(title: String, duration: String, youtubeId: String, category: String) {
    cricketRepo.addVideo(title, duration, youtubeId, category)
    _userFeedback.value = "Video published to Highlights stream!"
  }
}
