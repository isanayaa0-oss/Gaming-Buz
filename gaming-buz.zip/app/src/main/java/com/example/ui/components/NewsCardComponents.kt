package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.NewsArticle
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

@Composable
fun HeroFeaturedNewsCard(
  article: NewsArticle,
  currentLanguage: AppLanguage,
  isBookmarked: Boolean,
  onBookmarkToggle: () -> Unit,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 14.dp, vertical = 6.dp)
      .clip(RoundedCornerShape(14.dp))
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column {
      // Big News Banner Image
      Box(modifier = Modifier.fillMaxWidth().height(190.dp)) {
        AsyncImage(
          model = article.imageUrl,
          contentDescription = article.getTitle(currentLanguage),
          modifier = Modifier.fillMaxSize(),
          contentScale = ContentScale.Crop
        )
        if (article.isBreaking) {
          Box(
            modifier = Modifier
              .padding(10.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(CricketRed)
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = Localization.get("breaking_news", currentLanguage),
              color = Color.White,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      // Details Block
      Column(modifier = Modifier.padding(14.dp)) {
        Text(
          text = article.getTitle(currentLanguage),
          fontSize = 17.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
          lineHeight = 23.sp,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "${article.dateFormatted}  •  ${article.timeAgo}",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            // Category Tag pill
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = CricketRed.copy(alpha = 0.08f)
            ) {
              Text(
                text = Localization.get(article.category.translationKey, currentLanguage),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = CricketRed,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          IconButton(
            onClick = onBookmarkToggle,
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
              contentDescription = "Bookmark",
              tint = if (isBookmarked) CricketRed else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
          }
        }
      }
    }
  }
}

@Composable
fun CompactNewsItemRow(
  article: NewsArticle,
  currentLanguage: AppLanguage,
  isBookmarked: Boolean,
  onBookmarkToggle: () -> Unit,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 14.dp, vertical = 8.dp)
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClick = onClick),
    verticalAlignment = Alignment.CenterVertically
  ) {
    // Thumbnail on left
    Box(
      modifier = Modifier
        .size(width = 110.dp, height = 80.dp)
        .clip(RoundedCornerShape(10.dp))
    ) {
      AsyncImage(
        model = article.imageUrl,
        contentDescription = article.getTitle(currentLanguage),
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Crop
      )
    }

    Spacer(modifier = Modifier.width(12.dp))

    // Content on right
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = article.getTitle(currentLanguage),
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        lineHeight = 19.sp
      )

      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(
            text = "${article.dateFormatted}  •  ${article.timeAgo}",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
          )
          Spacer(modifier = Modifier.height(2.dp))
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = CricketRed.copy(alpha = 0.08f)
          ) {
            Text(
              text = Localization.get(article.category.translationKey, currentLanguage),
              fontSize = 10.sp,
              fontWeight = FontWeight.SemiBold,
              color = CricketRed,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }

        IconButton(
          onClick = onBookmarkToggle,
          modifier = Modifier.size(32.dp)
        ) {
          Icon(
            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
            contentDescription = "Bookmark",
            tint = if (isBookmarked) CricketRed else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }
}
