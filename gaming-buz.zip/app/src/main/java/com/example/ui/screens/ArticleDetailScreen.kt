package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.NewsArticle
import com.example.ui.components.CompactNewsItemRow
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArticleDetailScreen(
  article: NewsArticle,
  relatedArticles: List<NewsArticle>,
  currentLanguage: AppLanguage,
  isBookmarked: Boolean,
  onBookmarkToggle: () -> Unit,
  onBackClick: () -> Unit,
  onRelatedArticleClick: (NewsArticle) -> Unit
) {
  val context = LocalContext.current
  var fontSizeOffset by remember { mutableStateOf(0) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Gaming Buz",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
          )
        },
        navigationIcon = {
          IconButton(onClick = onBackClick) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back"
            )
          }
        },
        actions = {
          // Font size adjust
          IconButton(onClick = {
            fontSizeOffset = if (fontSizeOffset >= 4) 0 else fontSizeOffset + 2
          }) {
            Icon(imageVector = Icons.Default.FormatSize, contentDescription = "Font size")
          }

          // Bookmark
          IconButton(onClick = onBookmarkToggle) {
            Icon(
              imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
              contentDescription = "Bookmark",
              tint = if (isBookmarked) CricketRed else MaterialTheme.colorScheme.onSurface
            )
          }

          // Share
          IconButton(onClick = {
            val sendIntent = Intent().apply {
              action = Intent.ACTION_SEND
              putExtra(Intent.EXTRA_TEXT, "${article.getTitle(currentLanguage)}\n\nRead more on Gaming Buz Cricket App!")
              type = "text/plain"
            }
            val shareIntent = Intent.createChooser(sendIntent, "Share cricket news via")
            context.startActivity(shareIntent)
          }) {
            Icon(imageVector = Icons.Default.Share, contentDescription = "Share")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
        .verticalScroll(rememberScrollState())
    ) {
      // Banner Image
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(230.dp)
      ) {
        AsyncImage(
          model = article.imageUrl,
          contentDescription = article.getTitle(currentLanguage),
          modifier = Modifier.fillMaxSize(),
          contentScale = ContentScale.Crop
        )
      }

      Column(modifier = Modifier.padding(16.dp)) {
        // Tag & Time
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth()
        ) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = CricketRed
          ) {
            Text(
              text = Localization.get(article.category.translationKey, currentLanguage),
              color = Color.White,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "${article.dateFormatted}  •  ${article.timeAgo}",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Headline
        Text(
          text = article.getTitle(currentLanguage),
          fontSize = (21 + fontSizeOffset).sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
          lineHeight = (28 + fontSizeOffset).sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Author
        Text(
          text = "By ${article.author}",
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
          color = CricketRed
        )

        Spacer(modifier = Modifier.height(16.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        Spacer(modifier = Modifier.height(16.dp))

        // Body Content
        Text(
          text = article.getContent(currentLanguage),
          fontSize = (15 + fontSizeOffset).sp,
          color = MaterialTheme.colorScheme.onSurface,
          lineHeight = (24 + fontSizeOffset).sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Share button banner
        Button(
          onClick = {
            val sendIntent = Intent().apply {
              action = Intent.ACTION_SEND
              putExtra(Intent.EXTRA_TEXT, "${article.getTitle(currentLanguage)}\n\nRead more on Gaming Buz Cricket News!")
              type = "text/plain"
            }
            context.startActivity(Intent.createChooser(sendIntent, "Share via"))
          },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(containerColor = CricketRed),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(imageVector = Icons.Default.Share, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = Localization.get("share_news", currentLanguage), fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(30.dp))

        // Related Articles
        Text(
          text = "Related News",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(10.dp))

        relatedArticles.take(3).forEach { related ->
          CompactNewsItemRow(
            article = related,
            currentLanguage = currentLanguage,
            isBookmarked = false,
            onBookmarkToggle = {},
            onClick = { onRelatedArticleClick(related) }
          )
        }
      }
    }
  }
}
