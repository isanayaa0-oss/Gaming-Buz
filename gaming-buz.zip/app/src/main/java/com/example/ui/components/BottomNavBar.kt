package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.NavDestination
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

data class NavItem(
  val destination: NavDestination,
  val labelKey: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val hasLiveBadge: Boolean = false
)

@Composable
fun BottomNavBar(
  currentScreen: NavDestination,
  currentLanguage: AppLanguage,
  onNavigate: (NavDestination) -> Unit
) {
  val items = listOf(
    NavItem(NavDestination.HOME, "nav_home", Icons.Filled.Home, Icons.Outlined.Home),
    NavItem(NavDestination.NEWS, "nav_news", Icons.Filled.Feed, Icons.Outlined.Feed),
    NavItem(NavDestination.LIVE_SCORE, "nav_live", Icons.Filled.SportsScore, Icons.Outlined.SportsScore, hasLiveBadge = true),
    NavItem(NavDestination.VIDEOS, "nav_videos", Icons.Filled.SmartDisplay, Icons.Outlined.SmartDisplay),
    NavItem(NavDestination.MORE, "nav_more", Icons.Filled.GridView, Icons.Outlined.GridView)
  )

  NavigationBar(
    containerColor = MaterialTheme.colorScheme.background,
    contentColor = MaterialTheme.colorScheme.onBackground,
    tonalElevation = 8.dp
  ) {
    items.forEach { item ->
      val selected = currentScreen == item.destination
      NavigationBarItem(
        selected = selected,
        onClick = { onNavigate(item.destination) },
        icon = {
          Box {
            Icon(
              imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
              contentDescription = Localization.get(item.labelKey, currentLanguage),
              tint = if (selected) CricketRed else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
              modifier = Modifier.size(24.dp)
            )
            if (item.hasLiveBadge) {
              Box(
                modifier = Modifier
                  .align(Alignment.TopEnd)
                  .size(8.dp)
                  .clip(androidx.compose.foundation.shape.CircleShape)
                  .background(Color(0xFF2E7D32))
              )
            }
          }
        },
        label = {
          Text(
            text = Localization.get(item.labelKey, currentLanguage),
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) CricketRed else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
          )
        },
        colors = NavigationBarItemDefaults.colors(
          indicatorColor = CricketRed.copy(alpha = 0.1f)
        )
      )
    }
  }
}
