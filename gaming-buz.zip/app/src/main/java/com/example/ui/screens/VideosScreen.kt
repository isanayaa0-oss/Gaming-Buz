package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BottomNavigationBar
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LiveRed
import com.example.ui.theme.LocalExtraColors
import com.example.viewmodel.GamingBuzViewModel
import com.example.viewmodel.ScreenState

data class CricketVideo(
    val title: String,
    val duration: String,
    val views: String,
    val category: String
)

@Composable
fun VideosScreen(
    viewModel: GamingBuzViewModel,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current
    val currentLang by viewModel.currentLanguage.collectAsState()

    val videos = listOf(
        CricketVideo("Rohit Sharma 91 Runs Full Highlights - IND vs WI", "12:45", "450k views", "Match Highlights"),
        CricketVideo("Virat Kohli Masterclass 72 Runs in Chase", "08:20", "890k views", "Player Spotlight"),
        CricketVideo("IPL Best Catches and Super Sixes All Time", "15:10", "1.5M views", "IPL Special"),
        CricketVideo("Wankhede Stadium Atmosphere & Fan Reactions", "05:30", "120k views", "Exclusive")
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = extraColors.cardBackground,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(extraColors.cardBackground)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenState.Home) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = extraColors.textPrimary
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Cricket Videos & Highlights",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = extraColors.textPrimary
                )
            }
        },
        bottomBar = {
            BottomNavigationBar(
                selectedTab = "videos",
                onTabSelected = { viewModel.selectBottomNav(it) },
                currentLanguage = currentLang
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(extraColors.cardBackground)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(videos) { vid ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground),
                    border = androidx.compose.foundation.BorderStroke(1.dp, extraColors.borderColor)
                ) {
                    Column {
                        // Video thumbnail mock
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .background(Color(0xFF0F172A)),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(LiveRed),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(10.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.Black.copy(alpha = 0.8f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(text = vid.duration, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = vid.title,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = extraColors.textPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${vid.category} • ${vid.views}",
                                fontSize = 12.sp,
                                color = extraColors.textSecondary
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
