package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.CricketVideo
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

@Composable
fun VideosScreen(
  videos: List<CricketVideo>,
  activeVideo: CricketVideo?,
  currentLanguage: AppLanguage,
  onVideoClick: (CricketVideo) -> Unit,
  onDismissVideo: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    Text(
      text = Localization.get("tab_videos", currentLanguage),
      fontSize = 22.sp,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onBackground,
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
    )

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(14.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      items(videos) { video ->
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onVideoClick(video) }
        ) {
          Column {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
            ) {
              AsyncImage(
                model = video.thumbnailUrl,
                contentDescription = video.getTitle(currentLanguage),
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
              )

              // Dark overlay
              Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.25f)))

              // Play Icon
              Box(
                modifier = Modifier
                  .size(52.dp)
                  .clip(CircleShape)
                  .background(Color.Black.copy(alpha = 0.65f))
                  .align(Alignment.Center),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.PlayArrow,
                  contentDescription = "Play",
                  tint = Color.White,
                  modifier = Modifier.size(32.dp)
                )
              }

              // Duration Badge
              Box(
                modifier = Modifier
                  .align(Alignment.BottomEnd)
                  .padding(10.dp)
                  .clip(RoundedCornerShape(4.dp))
                  .background(Color.Black.copy(alpha = 0.8f))
                  .padding(horizontal = 8.dp, vertical = 3.dp)
              ) {
                Text(
                  text = video.duration,
                  color = Color.White,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }

            Column(modifier = Modifier.padding(14.dp)) {
              Text(
                text = video.getTitle(currentLanguage),
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
              )
              Spacer(modifier = Modifier.height(6.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "${video.category} • ${video.timeAgo}",
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = CricketRed.copy(alpha = 0.1f)
                ) {
                  Text(
                    text = "YouTube HD",
                    color = CricketRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            }
          }
        }
      }
    }
  }

  // Active Video Player Dialog Modal
  if (activeVideo != null) {
    Dialog(onDismissRequest = onDismissVideo) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          // Mock Video Player Header
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(220.dp)
              .background(Color.Black)
          ) {
            AsyncImage(
              model = activeVideo.thumbnailUrl,
              contentDescription = null,
              modifier = Modifier.fillMaxSize(),
              contentScale = ContentScale.Crop
            )
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)))

            IconButton(
              onClick = onDismissVideo,
              modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
            ) {
              Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
            }

            Box(
              modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(CricketRed)
                .align(Alignment.Center),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(36.dp)
              )
            }

            Text(
              text = "Playing: ${activeVideo.duration}",
              color = Color.White,
              fontSize = 11.sp,
              modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp)
            )
          }

          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = activeVideo.getTitle(currentLanguage),
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "Published by Gaming Buz Video Network • ${activeVideo.timeAgo}",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
              onClick = onDismissVideo,
              colors = ButtonDefaults.buttonColors(containerColor = CricketRed),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text("Close Player")
            }
          }
        }
      }
    }
  }
}
