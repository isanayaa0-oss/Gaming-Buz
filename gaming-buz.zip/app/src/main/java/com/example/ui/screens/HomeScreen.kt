package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CricketMatch
import com.example.data.model.CricketVideo
import com.example.data.model.NewsArticle
import com.example.data.model.NewsCategory
import com.example.ui.NavDestination
import com.example.ui.components.*
import com.example.ui.theme.CricketRed
import com.example.util.AppLanguage
import com.example.util.Localization

@Composable
fun HomeScreen(
  newsList: List<NewsArticle>,
  matchesList: List<CricketMatch>,
  videosList: List<CricketVideo>,
  bookmarkedIds: Set<String>,
  selectedCategory: NewsCategory,
  currentLanguage: AppLanguage,
  onCategorySelected: (NewsCategory) -> Unit,
  onArticleClick: (NewsArticle) -> Unit,
  onBookmarkToggle: (String) -> Unit,
  onMatchClick: (CricketMatch) -> Unit,
  onVideoClick: (CricketVideo) -> Unit,
  onNavigate: (NavDestination) -> Unit
) {
  val liveMatch = matchesList.firstOrNull { it.status == com.example.data.model.MatchStatus.LIVE }
    ?: matchesList.firstOrNull()

  val featuredNews = newsList.firstOrNull { it.isFeatured } ?: newsList.firstOrNull()
  val regularNews = newsList.filter { it.id != featuredNews?.id }
  val breakingArticle = newsList.firstOrNull { it.isBreaking }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // 1. Top Category Tabs Row
    item {
      CategoryTabsRow(
        selectedCategory = selectedCategory,
        currentLanguage = currentLanguage,
        onCategorySelected = { cat ->
          onCategorySelected(cat)
          when (cat) {
            NewsCategory.TEAM_INDIA -> onNavigate(NavDestination.TEAM_INDIA_SECTION)
            NewsCategory.DOMESTIC -> onNavigate(NavDestination.DOMESTIC_SECTION)
            NewsCategory.IPL -> onNavigate(NavDestination.IPL_SECTION)
            NewsCategory.PREVIEWS -> onNavigate(NavDestination.LIVE_SCORE)
            NewsCategory.RECORDS -> onNavigate(NavDestination.VIDEOS)
            else -> {}
          }
        }
      )
    }

    // 2. Breaking News Alert Ticker
    if (breakingArticle != null) {
      item {
        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .clickable { onArticleClick(breakingArticle) },
          color = CricketRed.copy(alpha = 0.08f)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Campaign,
              contentDescription = "Breaking",
              tint = CricketRed,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "${Localization.get("breaking_news", currentLanguage)}: ${breakingArticle.getTitle(currentLanguage)}",
              color = CricketRed,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 1
            )
          }
        }
      }
    }

    // 3. Live Match Card (India vs West Indies, 3rd T20I)
    if (liveMatch != null) {
      item {
        LiveMatchCard(
          match = liveMatch,
          onClick = { onMatchClick(liveMatch) }
        )
      }
    }

    // 4. "Top News" Header with "View All >"
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = Localization.get("tab_top_news", currentLanguage),
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onBackground
        )
        Text(
          text = "${Localization.get("view_all", currentLanguage)} >",
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          color = CricketRed,
          modifier = Modifier.clickable { onNavigate(NavDestination.NEWS) }
        )
      }
    }

    // 5. Featured Big Hero News Card
    if (featuredNews != null) {
      item {
        HeroFeaturedNewsCard(
          article = featuredNews,
          currentLanguage = currentLanguage,
          isBookmarked = bookmarkedIds.contains(featuredNews.id),
          onBookmarkToggle = { onBookmarkToggle(featuredNews.id) },
          onClick = { onArticleClick(featuredNews) }
        )
      }
    }

    // 6. Regular News List Items
    items(regularNews.take(2)) { article ->
      CompactNewsItemRow(
        article = article,
        currentLanguage = currentLanguage,
        isBookmarked = bookmarkedIds.contains(article.id),
        onBookmarkToggle = { onBookmarkToggle(article.id) },
        onClick = { onArticleClick(article) }
      )
    }

    // 7. Match Center Quick 3 Cards
    item {
      MatchCenterQuickSection(
        currentLanguage = currentLanguage,
        onViewAllClick = { onNavigate(NavDestination.LIVE_SCORE) },
        onLiveScoreClick = { onNavigate(NavDestination.LIVE_SCORE) },
        onUpcomingClick = { onNavigate(NavDestination.LIVE_SCORE) },
        onResultsClick = { onNavigate(NavDestination.LIVE_SCORE) }
      )
    }

    // 8. Videos Section
    item {
      VideosHorizontalSection(
        videos = videosList,
        currentLanguage = currentLanguage,
        onViewAllClick = { onNavigate(NavDestination.VIDEOS) },
        onVideoClick = onVideoClick
      )
    }

    // 9. Additional News articles
    items(regularNews.drop(2)) { article ->
      CompactNewsItemRow(
        article = article,
        currentLanguage = currentLanguage,
        isBookmarked = bookmarkedIds.contains(article.id),
        onBookmarkToggle = { onBookmarkToggle(article.id) },
        onClick = { onArticleClick(article) }
      )
    }

    item {
      Spacer(modifier = Modifier.height(20.dp))
    }
  }
}
