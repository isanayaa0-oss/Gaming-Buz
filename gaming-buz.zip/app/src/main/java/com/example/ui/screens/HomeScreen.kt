package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.NewsArticle
import com.example.ui.components.BottomNavigationBar
import com.example.ui.components.CategoryPills
import com.example.ui.components.GamingBuzHeader
import com.example.ui.components.LiveMatchCard
import com.example.ui.components.NewsCard
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LiveRed
import com.example.ui.theme.LocalExtraColors
import com.example.viewmodel.GamingBuzViewModel
import com.example.viewmodel.ScreenState

@Composable
fun MatchCenterCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current

    Card(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag("match_center_${title.lowercase().replace(" ", "_")}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = extraColors.cardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconTint.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = extraColors.textPrimary
            )

            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = extraColors.textSecondary
            )
        }
    }
}

@Composable
fun HomeScreen(
    viewModel: GamingBuzViewModel,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current
    val currentLang by viewModel.currentLanguage.collectAsState()
    val sections by viewModel.sections.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val liveMatch by viewModel.liveMatch.collectAsState()
    val newsList by viewModel.news.collectAsState()
    val isSearchActive by viewModel.isSearchActive.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val notificationCount by viewModel.notificationCount.collectAsState()
    val selectedNav by viewModel.selectedBottomNav.collectAsState()

    val filteredNews = if (searchQuery.isBlank()) {
        newsList
    } else {
        newsList.filter {
            it.titleEn.contains(searchQuery, ignoreCase = true) ||
            it.titleHi.contains(searchQuery, ignoreCase = true) ||
            it.titleBn.contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = extraColors.cardBackground,
        topBar = {
            GamingBuzHeader(
                onMenuClick = { viewModel.openDrawer() },
                isSearchActive = isSearchActive,
                searchQuery = searchQuery,
                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                onSearchToggle = { viewModel.toggleSearch() },
                notificationCount = notificationCount
            )
        },
        bottomBar = {
            BottomNavigationBar(
                selectedTab = selectedNav,
                onTabSelected = { viewModel.selectBottomNav(it) },
                currentLanguage = currentLang
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(extraColors.cardBackground),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Horizontal Category Pills
            item {
                CategoryPills(
                    sections = sections,
                    selectedCategory = selectedCategory,
                    onCategorySelected = { viewModel.selectCategory(it) },
                    currentLanguage = currentLang
                )
            }

            // Live Match Card
            item {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    LiveMatchCard(
                        match = liveMatch,
                        currentLanguage = currentLang,
                        onCardClick = { viewModel.navigateTo(ScreenState.LiveDetail) }
                    )
                }
            }

            // Match Center: Live Score / Upcoming / Results (Requirement 4)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MatchCenterCard(
                        title = "Live Score",
                        subtitle = "1 Match",
                        icon = Icons.Filled.PlayArrow,
                        iconTint = LiveRed,
                        onClick = { viewModel.navigateTo(ScreenState.LiveDetail) },
                        modifier = Modifier.weight(1f)
                    )
                    MatchCenterCard(
                        title = "Upcoming",
                        subtitle = "4 Matches",
                        icon = Icons.Filled.CalendarMonth,
                        iconTint = BrandBlue,
                        onClick = { viewModel.navigateTo(ScreenState.TeamIndia) },
                        modifier = Modifier.weight(1f)
                    )
                    MatchCenterCard(
                        title = "Results",
                        subtitle = "Past 7 Days",
                        icon = Icons.Filled.EmojiEvents,
                        iconTint = Color(0xFFF59E0B),
                        onClick = { viewModel.navigateTo(ScreenState.IplLifetime) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Top News Header Row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Top News",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = extraColors.textPrimary
                    )

                    Text(
                        text = "See All →",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandBlue,
                        modifier = Modifier
                            .clickable { viewModel.selectCategory("Top News") }
                            .testTag("see_all_news_button")
                    )
                }
            }

            // News List Items
            items(filteredNews, key = { it.id }) { article ->
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    NewsCard(
                        article = article,
                        currentLanguage = currentLang,
                        onArticleClick = { viewModel.navigateTo(ScreenState.NewsDetail(article)) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
