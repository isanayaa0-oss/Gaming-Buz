package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CapHolder
import com.example.model.CricketTeam
import com.example.ui.theme.LocalExtraColors

@Composable
fun CricketCapIcon(
    capColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.size(36.dp, 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Cap dome
            val domePath = Path().apply {
                moveTo(w * 0.25f, h * 0.7f)
                cubicTo(w * 0.25f, h * 0.1f, w * 0.85f, h * 0.1f, w * 0.85f, h * 0.7f)
                close()
            }
            drawPath(domePath, color = capColor)

            // Cap visor
            val visorPath = Path().apply {
                moveTo(w * 0.1f, h * 0.7f)
                cubicTo(w * 0.15f, h * 0.65f, w * 0.85f, h * 0.65f, w * 0.95f, h * 0.7f)
                lineTo(w * 0.98f, h * 0.85f)
                cubicTo(w * 0.8f, h * 0.95f, w * 0.05f, h * 0.92f, w * 0.05f, h * 0.85f)
                close()
            }
            drawPath(visorPath, color = capColor)

            // Small button on top
            drawCircle(color = capColor.copy(alpha = 0.8f), radius = w * 0.05f, center = Offset(w * 0.55f, h * 0.15f))
        }
    }
}

@Composable
fun CapCardsRow(
    orangeCap: CapHolder,
    purpleCap: CapHolder,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Orange Cap Card
        Card(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(18.dp))
                .testTag("orange_cap_card"),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = extraColors.orangeCapBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CricketCapIcon(capColor = Color(0xFFFF6D00))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = orangeCap.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = extraColors.textPrimary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = orangeCap.playerName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = extraColors.textPrimary
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = orangeCap.metricValue,
                    fontSize = 13.sp,
                    color = extraColors.textSecondary,
                    fontWeight = FontWeight.Normal
                )
            }
        }

        // Purple Cap Card
        Card(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(18.dp))
                .testTag("purple_cap_card"),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = extraColors.purpleCapBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CricketCapIcon(capColor = Color(0xFF7C3AED))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = purpleCap.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = extraColors.textPrimary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = purpleCap.playerName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = extraColors.textPrimary
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = purpleCap.metricValue,
                    fontSize = 13.sp,
                    color = extraColors.textSecondary,
                    fontWeight = FontWeight.Normal
                )
            }
        }
    }
}

@Composable
fun TeamLogoBadge(
    code: String,
    primaryColor: Color,
    secondaryColor: Color,
    size: Int = 36,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(primaryColor)
            .border(1.5.dp, secondaryColor, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = code,
            fontSize = (size * 0.35).sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White
        )
    }
}
