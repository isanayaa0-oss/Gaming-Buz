package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.SectionItem
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.LocalExtraColors

@Composable
fun CategoryPills(
    sections: List<SectionItem>,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit,
    currentLanguage: AppLanguage,
    modifier: Modifier = Modifier
) {
    val extraColors = LocalExtraColors.current

    // Only display enabled sections in order
    val activeSections = sections
        .filter { it.isEnabled }
        .sortedBy { it.order }

    LazyRow(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .testTag("category_pills_row"),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 16.dp)
    ) {
        items(activeSections, key = { it.id }) { section ->
            val isSelected = selectedCategory.equals(section.nameEn, ignoreCase = true) ||
                             selectedCategory.equals(section.nameHi, ignoreCase = true) ||
                             selectedCategory.equals(section.nameBn, ignoreCase = true)

            val displayName = section.localizedName(currentLanguage)

            val pillBg = if (isSelected) BrandBlue else extraColors.pillUnselected
            val textColor = if (isSelected) Color.White else extraColors.pillTextUnselected
            val fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal

            Box(
                modifier = Modifier
                    .height(38.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(pillBg)
                    .clickable { onCategorySelected(section.nameEn) }
                    .padding(horizontal = 18.dp)
                    .testTag("category_pill_${section.nameEn.lowercase().replace(" ", "_")}"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = displayName,
                    color = textColor,
                    fontSize = 14.sp,
                    fontWeight = fontWeight
                )
            }
        }
    }
}
