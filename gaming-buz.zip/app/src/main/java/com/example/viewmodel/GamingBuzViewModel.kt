package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CricketRepository
import com.example.model.AdMobStats
import com.example.model.AppLanguage
import com.example.model.AppUser
import com.example.model.CricketTeam
import com.example.model.MatchScore
import com.example.model.NewsArticle
import com.example.model.PointsTableRow
import com.example.model.SectionItem
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class ScreenState {
    object Home : ScreenState()
    object IplLifetime : ScreenState()
    object LiveDetail : ScreenState()
    object TeamIndia : ScreenState()
    object Videos : ScreenState()
    object AdminDashboard : ScreenState()
    data class NewsDetail(val article: NewsArticle) : ScreenState()
    object OnboardingLanguage : ScreenState()
}

class GamingBuzViewModel(
    val repository: CricketRepository = CricketRepository()
) : ViewModel() {

    // Language state
    private val _currentLanguage = MutableStateFlow(AppLanguage.HINDI)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    // Theme state
    private val _currentTheme = MutableStateFlow(AppThemeMode.BLACK_WHITE)
    val currentTheme: StateFlow<AppThemeMode> = _currentTheme.asStateFlow()

    // Navigation and active tabs
    private val _currentScreen = MutableStateFlow<ScreenState>(ScreenState.Home)
    val currentScreen: StateFlow<ScreenState> = _currentScreen.asStateFlow()

    private val _selectedBottomNav = MutableStateFlow("home")
    val selectedBottomNav: StateFlow<String> = _selectedBottomNav.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Top News")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _isDrawerOpen = MutableStateFlow(false)
    val isDrawerOpen: StateFlow<Boolean> = _isDrawerOpen.asStateFlow()

    // Dialogs
    private val _isUserLoginDialogOpen = MutableStateFlow(false)
    val isUserLoginDialogOpen: StateFlow<Boolean> = _isUserLoginDialogOpen.asStateFlow()

    private val _isAdminLoginDialogOpen = MutableStateFlow(false)
    val isAdminLoginDialogOpen: StateFlow<Boolean> = _isAdminLoginDialogOpen.asStateFlow()

    private val _isAddNewSectionDialogOpen = MutableStateFlow(false)
    val isAddNewSectionDialogOpen: StateFlow<Boolean> = _isAddNewSectionDialogOpen.asStateFlow()

    private val _isAddArticleDialogOpen = MutableStateFlow(false)
    val isAddArticleDialogOpen: StateFlow<Boolean> = _isAddArticleDialogOpen.asStateFlow()

    private val _isScoreEditorDialogOpen = MutableStateFlow(false)
    val isScoreEditorDialogOpen: StateFlow<Boolean> = _isScoreEditorDialogOpen.asStateFlow()

    private val _adminAccessDeniedMessage = MutableStateFlow<String?>(null)
    val adminAccessDeniedMessage: StateFlow<String?> = _adminAccessDeniedMessage.asStateFlow()

    // IPL Tab
    private val _activeIplSeason = MutableStateFlow("Lifetime")
    val activeIplSeason: StateFlow<String> = _activeIplSeason.asStateFlow()

    // Search and Notifications
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearchActive = MutableStateFlow(false)
    val isSearchActive: StateFlow<Boolean> = _isSearchActive.asStateFlow()

    private val _notificationCount = MutableStateFlow(3)
    val notificationCount: StateFlow<Int> = _notificationCount.asStateFlow()

    // Repositories delegates
    val sections: StateFlow<List<SectionItem>> = repository.sections
    val news: StateFlow<List<NewsArticle>> = repository.news
    val liveMatch: StateFlow<MatchScore> = repository.liveMatch
    val currentUser: StateFlow<AppUser?> = repository.currentUser
    val admobStats: StateFlow<AdMobStats> = repository.admobStats

    val orangeCapLifetime = repository.orangeCapLifetime
    val purpleCapLifetime = repository.purpleCapLifetime
    val all10Teams: List<CricketTeam> = repository.all10Teams

    fun getPointsTable(): List<PointsTableRow> {
        return repository.getPointsTableForSeason(_activeIplSeason.value)
    }

    // Actions
    fun setLanguage(lang: AppLanguage) {
        _currentLanguage.value = lang
    }

    fun setTheme(theme: AppThemeMode) {
        _currentTheme.value = theme
    }

    fun toggleTheme() {
        _currentTheme.value = if (_currentTheme.value == AppThemeMode.BLACK_WHITE) {
            AppThemeMode.NAVY_DARK
        } else {
            AppThemeMode.BLACK_WHITE
        }
    }

    fun openDrawer() {
        _isDrawerOpen.value = true
    }

    fun closeDrawer() {
        _isDrawerOpen.value = false
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
        when (category) {
            "Top News" -> navigateTo(ScreenState.Home)
            "Live Score" -> navigateTo(ScreenState.LiveDetail)
            "Team India" -> navigateTo(ScreenState.TeamIndia)
            "IPL" -> {
                _selectedBottomNav.value = "ipl"
                navigateTo(ScreenState.IplLifetime)
            }
            "Videos" -> navigateTo(ScreenState.Videos)
            else -> navigateTo(ScreenState.Home)
        }
    }

    fun selectBottomNav(tab: String) {
        _selectedBottomNav.value = tab
        when (tab) {
            "home" -> {
                _selectedCategory.value = "Top News"
                navigateTo(ScreenState.Home)
            }
            "news" -> {
                _selectedCategory.value = "Top News"
                navigateTo(ScreenState.Home)
            }
            "live" -> navigateTo(ScreenState.LiveDetail)
            "videos" -> navigateTo(ScreenState.Videos)
            "ipl" -> {
                _selectedCategory.value = "IPL"
                navigateTo(ScreenState.IplLifetime)
            }
            "more" -> openDrawer()
            "profile" -> openDrawer()
            else -> navigateTo(ScreenState.Home)
        }
    }

    fun navigateTo(screen: ScreenState) {
        _currentScreen.value = screen
        _isDrawerOpen.value = false
    }

    fun navigateBack() {
        if (_currentScreen.value !is ScreenState.Home) {
            _currentScreen.value = ScreenState.Home
            _selectedBottomNav.value = "home"
        }
    }

    fun setIplSeason(season: String) {
        _activeIplSeason.value = season
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleSearch() {
        _isSearchActive.value = !_isSearchActive.value
        if (!_isSearchActive.value) {
            _searchQuery.value = ""
        }
    }

    fun showUserLoginDialog() {
        _isUserLoginDialogOpen.value = true
        _isDrawerOpen.value = false
    }

    fun hideUserLoginDialog() {
        _isUserLoginDialogOpen.value = false
    }

    fun showAdminLoginDialog() {
        _isAdminLoginDialogOpen.value = true
        _isDrawerOpen.value = false
    }

    fun hideAdminLoginDialog() {
        _isAdminLoginDialogOpen.value = false
    }

    fun showAddNewSectionDialog() {
        _isAddNewSectionDialogOpen.value = true
    }

    fun hideAddNewSectionDialog() {
        _isAddNewSectionDialogOpen.value = false
    }

    fun showAddArticleDialog() {
        _isAddArticleDialogOpen.value = true
    }

    fun hideAddArticleDialog() {
        _isAddArticleDialogOpen.value = false
    }

    fun showScoreEditorDialog() {
        _isScoreEditorDialogOpen.value = true
    }

    fun hideScoreEditorDialog() {
        _isScoreEditorDialogOpen.value = false
    }

    fun clearAdminAccessDenied() {
        _adminAccessDeniedMessage.value = null
    }

    fun tryAccessAdminPanel() {
        val user = repository.currentUser.value
        if (user != null && user.role == "admin") {
            navigateTo(ScreenState.AdminDashboard)
        } else {
            // Security check: Normal user cannot access Admin Dashboard
            _adminAccessDeniedMessage.value = "Access Denied: Admin role credentials required to access the Admin Dashboard."
            showAdminLoginDialog()
        }
    }

    fun performUserLogin(name: String, email: String, phone: String) {
        repository.loginUser(name, email, phone)
        hideUserLoginDialog()
    }

    fun performAdminLogin(email: String, pinOrPass: String): Boolean {
        if (email.contains("admin", ignoreCase = true) || pinOrPass == "admin123" || pinOrPass == "1234") {
            repository.loginAdmin("Admin User", email)
            hideAdminLoginDialog()
            navigateTo(ScreenState.AdminDashboard)
            return true
        }
        return false
    }

    fun logout() {
        repository.logout()
        _currentScreen.value = ScreenState.Home
        _selectedBottomNav.value = "home"
    }

    // Dynamic Section Management
    fun toggleSection(id: String) = repository.toggleSection(id)
    fun deleteSection(id: String) = repository.deleteSection(id)
    fun moveSection(from: Int, to: Int) = repository.moveSection(from, to)
    fun addSection(
        nameEn: String,
        nameHi: String,
        nameBn: String,
        icon: String,
        color: String,
        slug: String,
        enabled: Boolean
    ) {
        repository.addSection(nameEn, nameHi, nameBn, icon, color, slug, enabled)
        hideAddNewSectionDialog()
    }

    fun addArticle(
        titleEn: String,
        titleHi: String,
        titleBn: String,
        contentEn: String,
        contentHi: String,
        contentBn: String,
        category: String,
        isBreaking: Boolean
    ) {
        repository.addNewsArticle(titleEn, titleHi, titleBn, contentEn, contentHi, contentBn, category, isBreaking)
        hideAddArticleDialog()
    }

    fun deleteArticle(id: String) = repository.deleteNewsArticle(id)

    fun updateScore(
        team1Score: String,
        team1Overs: String,
        needRuns: Int,
        needBalls: Int,
        kohliruns: Int,
        rohitruns: Int
    ) {
        repository.updateLiveScore(team1Score, team1Overs, needRuns, needBalls, kohliruns, rohitruns)
        hideScoreEditorDialog()
    }
}
