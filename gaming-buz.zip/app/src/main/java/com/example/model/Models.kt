package com.example.model

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    HINDI("hi", "Hindi", "हिन्दी"),
    BANGLA("bn", "Bangla", "বাংলা")
}

data class NewsArticle(
    val id: String,
    val titleEn: String,
    val titleHi: String,
    val titleBn: String,
    val contentEn: String,
    val contentHi: String,
    val contentBn: String,
    val timeAgoEn: String,
    val timeAgoHi: String,
    val timeAgoBn: String,
    val views: String,
    val category: String,
    val isBreaking: Boolean = false,
    val author: String = "Gaming Buz Editorial",
    val thumbnailType: String = "rohit"
) {
    fun localizedTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> titleEn
        AppLanguage.HINDI -> titleHi
        AppLanguage.BANGLA -> titleBn
    }

    fun localizedContent(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> contentEn
        AppLanguage.HINDI -> contentHi
        AppLanguage.BANGLA -> contentBn
    }

    fun localizedTimeAgo(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> timeAgoEn
        AppLanguage.HINDI -> timeAgoHi
        AppLanguage.BANGLA -> timeAgoBn
    }
}

data class BatsmanScore(
    val name: String,
    val runs: Int,
    val balls: Int,
    val fours: Int = 4,
    val sixes: Int = 2,
    val isNotOut: Boolean = true
)

data class BowlerScore(
    val name: String,
    val overs: Float,
    val maidens: Int,
    val runs: Int,
    val wickets: Int,
    val economy: Float
)

data class MatchScore(
    val id: String,
    val team1Name: String,
    val team1Code: String,
    val team1FlagEmoji: String,
    val team1Score: String,
    val team1Overs: String,
    val team2Name: String,
    val team2Code: String,
    val team2FlagEmoji: String,
    val team2Score: String,
    val team2Overs: String,
    val target: Int,
    val needRuns: Int,
    val needBalls: Int,
    val batsman1: BatsmanScore,
    val batsman2: BatsmanScore,
    val status: String = "LIVE",
    val venue: String = "Wankhede Stadium, Mumbai",
    val matchType: String = "2nd ODI (D/N)"
)

data class PointsTableRow(
    val position: Int,
    val teamCode: String,
    val teamFullName: String,
    val matches: Int,
    val won: Int,
    val lost: Int,
    val points: Int,
    val nrr: String,
    val primaryColorHex: Long,
    val secondaryColorHex: Long
)

data class CapHolder(
    val title: String,
    val playerName: String,
    val metricValue: String,
    val teamCode: String
)

data class CricketTeam(
    val code: String,
    val name: String,
    val primaryColorHex: Long,
    val secondaryColorHex: Long,
    val titles: Int = 5
)

data class SectionItem(
    val id: String,
    val nameEn: String,
    val nameHi: String,
    val nameBn: String,
    val tagEn: String,
    val tagHi: String,
    val tagBn: String,
    val iconName: String,
    val colorHex: String,
    val slug: String,
    val isEnabled: Boolean,
    val order: Int
) {
    fun localizedName(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> nameEn
        AppLanguage.HINDI -> nameHi
        AppLanguage.BANGLA -> nameBn
    }
}

data class AppUser(
    val name: String,
    val phone: String,
    val email: String,
    val role: String = "user", // "user" or "admin"
    val isOtpVerified: Boolean = true
)

data class AdMobStats(
    val todayEarning: String = "$328.50",
    val todayGrowth: String = "+12.5% vs yesterday ↑",
    val totalEarning: String = "$12,450.00",
    val totalGrowth: String = "+8.2% this month ↑",
    val impressions: String = "1.2M",
    val impressionsGrowth: String = "+5.1% vs yesterday ↑",
    val trendData: List<Pair<String, Float>> = listOf(
        "Mon" to 110f,
        "Tue" to 170f,
        "Wed" to 195f,
        "Thu" to 140f,
        "Fri" to 180f,
        "Sun" to 280f
    )
)
