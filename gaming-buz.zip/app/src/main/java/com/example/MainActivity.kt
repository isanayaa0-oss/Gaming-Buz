package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AdminLoginDialog
import com.example.ui.components.ScoreEditorDialog
import com.example.ui.components.UserLoginDialog
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.IplLifetimeScreen
import com.example.ui.screens.LiveScoreDetailScreen
import com.example.ui.screens.NewsDetailScreen
import com.example.ui.screens.ProfileDrawerContent
import com.example.ui.screens.TeamIndiaScreen
import com.example.ui.screens.VideosScreen
import com.example.ui.theme.GamingBuzTheme
import com.example.viewmodel.GamingBuzViewModel
import com.example.viewmodel.ScreenState
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val mainViewModel: GamingBuzViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val currentTheme by mainViewModel.currentTheme.collectAsState()

            GamingBuzTheme(themeMode = currentTheme) {
                GamingBuzApp(viewModel = mainViewModel)
            }
        }
    }
}

@Composable
fun GamingBuzApp(
    viewModel: GamingBuzViewModel = viewModel()
) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsState()
    val isDrawerOpen by viewModel.isDrawerOpen.collectAsState()
    val isUserLoginOpen by viewModel.isUserLoginDialogOpen.collectAsState()
    val isAdminLoginOpen by viewModel.isAdminLoginDialogOpen.collectAsState()
    val isScoreEditorOpen by viewModel.isScoreEditorDialogOpen.collectAsState()
    val adminDeniedMessage by viewModel.adminAccessDeniedMessage.collectAsState()

    val drawerState = rememberDrawerState(
        initialValue = if (isDrawerOpen) DrawerValue.Open else DrawerValue.Closed
    )
    val coroutineScope = rememberCoroutineScope()

    // Sync drawer open state with ViewModel
    LaunchedEffect(isDrawerOpen) {
        if (isDrawerOpen) {
            drawerState.open()
        } else {
            drawerState.close()
        }
    }

    LaunchedEffect(drawerState.isOpen) {
        if (!drawerState.isOpen && isDrawerOpen) {
            viewModel.closeDrawer()
        }
    }

    // Admin access warning toast
    LaunchedEffect(adminDeniedMessage) {
        adminDeniedMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            viewModel.clearAdminAccessDenied()
        }
    }

    // Back handling
    BackHandler(enabled = drawerState.isOpen || currentScreen !is ScreenState.Home) {
        if (drawerState.isOpen) {
            coroutineScope.launch {
                drawerState.close()
                viewModel.closeDrawer()
            }
        } else if (currentScreen !is ScreenState.Home) {
            viewModel.navigateBack()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = currentScreen is ScreenState.Home || currentScreen is ScreenState.IplLifetime,
        drawerContent = {
            ModalDrawerSheet {
                ProfileDrawerContent(
                    viewModel = viewModel,
                    onClose = {
                        coroutineScope.launch {
                            drawerState.close()
                            viewModel.closeDrawer()
                        }
                    }
                )
            }
        }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Crossfade(targetState = currentScreen, label = "screen_transition") { screen ->
                when (screen) {
                    is ScreenState.Home -> HomeScreen(viewModel = viewModel)
                    is ScreenState.IplLifetime -> IplLifetimeScreen(viewModel = viewModel)
                    is ScreenState.LiveDetail -> LiveScoreDetailScreen(viewModel = viewModel)
                    is ScreenState.TeamIndia -> TeamIndiaScreen(viewModel = viewModel)
                    is ScreenState.Videos -> VideosScreen(viewModel = viewModel)
                    is ScreenState.AdminDashboard -> AdminDashboardScreen(viewModel = viewModel)
                    is ScreenState.NewsDetail -> NewsDetailScreen(article = screen.article, viewModel = viewModel)
                    else -> HomeScreen(viewModel = viewModel)
                }
            }

            // Dialogs
            if (isUserLoginOpen) {
                UserLoginDialog(
                    viewModel = viewModel,
                    onDismiss = { viewModel.hideUserLoginDialog() }
                )
            }

            if (isAdminLoginOpen) {
                AdminLoginDialog(
                    viewModel = viewModel,
                    onDismiss = { viewModel.hideAdminLoginDialog() }
                )
            }

            if (isScoreEditorOpen) {
                ScoreEditorDialog(
                    viewModel = viewModel,
                    onDismiss = { viewModel.hideScoreEditorDialog() }
                )
            }
        }
    }
}
