package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.UserRole
import com.example.ui.GamingBuzViewModel
import com.example.ui.NavDestination
import com.example.ui.components.BottomNavBar
import com.example.ui.components.TopBar
import com.example.ui.screens.*
import com.example.ui.theme.CricketRed
import com.example.ui.theme.GamingBuzTheme
import com.example.ui.theme.IndiaBlue
import com.example.util.Localization
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

  private val viewModel: GamingBuzViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Completely hide system status bar (network, wifi, battery, and time)
    WindowCompat.setDecorFitsSystemWindows(window, false)
    val insetsController = WindowCompat.getInsetsController(window, window.decorView)
    insetsController.hide(WindowInsetsCompat.Type.statusBars())
    insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

    setContent {
      val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
      val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
      val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
      val selectedHomeTab by viewModel.selectedHomeTab.collectAsStateWithLifecycle()

      val newsList by viewModel.newsList.collectAsStateWithLifecycle()
      val bookmarkedIds by viewModel.bookmarkedIds.collectAsStateWithLifecycle()
      val matchesList by viewModel.matchesList.collectAsStateWithLifecycle()
      val videosList by viewModel.videosList.collectAsStateWithLifecycle()
      val iplStandings by viewModel.iplStandings.collectAsStateWithLifecycle()
      val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
      val generatedOtp by viewModel.generatedOtp.collectAsStateWithLifecycle()
      val activeVideo by viewModel.activeVideo.collectAsStateWithLifecycle()
      val userFeedback by viewModel.userFeedback.collectAsStateWithLifecycle()

      val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
      val scope = rememberCoroutineScope()
      val snackbarHostState = remember { SnackbarHostState() }

      // Handle user feedback notifications
      LaunchedEffect(userFeedback) {
        userFeedback?.let { msg ->
          snackbarHostState.showSnackbar(msg)
          viewModel.clearFeedback()
        }
      }

      // Back navigation handler
      if (currentScreen != NavDestination.HOME) {
        BackHandler {
          viewModel.navigateTo(NavDestination.HOME)
        }
      }

      GamingBuzTheme(darkTheme = isDarkTheme) {
        ModalNavigationDrawer(
          drawerState = drawerState,
          drawerContent = {
            ModalDrawerSheet(
              modifier = Modifier.width(300.dp),
              drawerContainerColor = MaterialTheme.colorScheme.background
            ) {
              // Drawer Header
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(CricketRed)
                  .padding(20.dp)
              ) {
                Column {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Default.SportsCricket,
                      contentDescription = null,
                      tint = Color.White,
                      modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = "GAMING BUZ",
                      color = Color.White,
                      fontSize = 20.sp,
                      fontWeight = FontWeight.Black
                    )
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = Localization.get("tagline", currentLanguage),
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 11.sp
                  )
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              // Drawer Navigation Items
              listOf(
                Triple("nav_home", Icons.Default.Home, NavDestination.HOME),
                Triple("tab_team_india", Icons.Default.SportsCricket, NavDestination.TEAM_INDIA_SECTION),
                Triple("tab_domestic", Icons.Default.SportsBaseball, NavDestination.DOMESTIC_SECTION),
                Triple("tab_ipl", Icons.Default.EmojiEvents, NavDestination.IPL_SECTION),
                Triple("nav_live", Icons.Default.SportsScore, NavDestination.LIVE_SCORE),
                Triple("tab_videos", Icons.Default.SmartDisplay, NavDestination.VIDEOS),
                Triple("bookmarks", Icons.Default.Bookmark, NavDestination.BOOKMARKS),
                Triple("nav_more", Icons.Default.GridView, NavDestination.MORE)
              ).forEach { (labelKey, icon, destination) ->
                NavigationDrawerItem(
                  icon = { Icon(imageVector = icon, contentDescription = null, tint = CricketRed) },
                  label = { Text(Localization.get(labelKey, currentLanguage), fontWeight = FontWeight.SemiBold) },
                  selected = currentScreen == destination,
                  onClick = {
                    viewModel.navigateTo(destination)
                    scope.launch { drawerState.close() }
                  },
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                  colors = NavigationDrawerItemDefaults.colors(
                    selectedContainerColor = CricketRed.copy(alpha = 0.12f)
                  )
                )
              }

              HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp, horizontal = 12.dp))

              // Admin Panel Link in Drawer
              if (currentUser?.role == UserRole.ADMIN) {
                NavigationDrawerItem(
                  icon = { Icon(imageVector = Icons.Default.Dashboard, contentDescription = null, tint = IndiaBlue) },
                  label = { Text("Admin Dashboard", fontWeight = FontWeight.Bold, color = IndiaBlue) },
                  selected = currentScreen == NavDestination.ADMIN_DASHBOARD,
                  onClick = {
                    viewModel.navigateTo(NavDestination.ADMIN_DASHBOARD)
                    scope.launch { drawerState.close() }
                  },
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )
              } else {
                NavigationDrawerItem(
                  icon = { Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null, tint = IndiaBlue) },
                  label = { Text("Admin Login", fontWeight = FontWeight.SemiBold, color = IndiaBlue) },
                  selected = false,
                  onClick = {
                    viewModel.navigateTo(NavDestination.AUTH_SCREEN)
                    scope.launch { drawerState.close() }
                  },
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )
              }
            }
          }
        ) {
          Scaffold(
            topBar = {
              // Show Main Top Bar only on top-level tabs
              if (currentScreen in listOf(NavDestination.HOME, NavDestination.NEWS, NavDestination.LIVE_SCORE, NavDestination.VIDEOS, NavDestination.MORE)) {
                TopBar(
                  onSearchClick = { viewModel.navigateTo(NavDestination.SEARCH) },
                  onNotificationsClick = { viewModel.navigateTo(NavDestination.NOTIFICATIONS) },
                  onMenuClick = { scope.launch { drawerState.open() } }
                )
              }
            },
            bottomBar = {
              // Bottom Nav on top-level destinations
              if (currentScreen in listOf(NavDestination.HOME, NavDestination.NEWS, NavDestination.LIVE_SCORE, NavDestination.VIDEOS, NavDestination.MORE)) {
                BottomNavBar(
                  currentScreen = currentScreen,
                  currentLanguage = currentLanguage,
                  onNavigate = { viewModel.navigateTo(it) }
                )
              }
            },
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = WindowInsets(0, 0, 0, 0)
          ) { innerPadding ->
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
            ) {
              when (currentScreen) {
                NavDestination.HOME -> {
                  HomeScreen(
                    newsList = newsList,
                    matchesList = matchesList,
                    videosList = videosList,
                    bookmarkedIds = bookmarkedIds,
                    selectedCategory = selectedHomeTab,
                    currentLanguage = currentLanguage,
                    onCategorySelected = { viewModel.setHomeTab(it) },
                    onArticleClick = { viewModel.openArticle(it) },
                    onBookmarkToggle = { viewModel.toggleBookmark(it) },
                    onMatchClick = { viewModel.openMatch(it) },
                    onVideoClick = { viewModel.openVideo(it) },
                    onNavigate = { viewModel.navigateTo(it) }
                  )
                }

                NavDestination.NEWS -> {
                  NewsScreen(
                    newsList = newsList,
                    bookmarkedIds = bookmarkedIds,
                    currentLanguage = currentLanguage,
                    onArticleClick = { viewModel.openArticle(it) },
                    onBookmarkToggle = { viewModel.toggleBookmark(it) }
                  )
                }

                NavDestination.LIVE_SCORE -> {
                  LiveScoreScreen(
                    matches = matchesList,
                    currentLanguage = currentLanguage,
                    onMatchClick = { viewModel.openMatch(it) }
                  )
                }

                NavDestination.VIDEOS -> {
                  VideosScreen(
                    videos = videosList,
                    activeVideo = activeVideo,
                    currentLanguage = currentLanguage,
                    onVideoClick = { viewModel.openVideo(it) },
                    onDismissVideo = { viewModel.closeVideo() }
                  )
                }

                NavDestination.MORE -> {
                  SettingsAndLegalScreen(
                    currentUser = currentUser,
                    currentLanguage = currentLanguage,
                    isDarkTheme = isDarkTheme,
                    onLanguageChange = { viewModel.setLanguage(it) },
                    onToggleTheme = { viewModel.toggleTheme() },
                    onNavigate = { viewModel.navigateTo(it) },
                    onLogout = { viewModel.logout() }
                  )
                }

                NavDestination.ARTICLE_DETAIL -> {
                  val selected = viewModel.selectedArticle.collectAsStateWithLifecycle().value
                  if (selected != null) {
                    ArticleDetailScreen(
                      article = selected,
                      relatedArticles = newsList.filter { it.id != selected.id },
                      currentLanguage = currentLanguage,
                      isBookmarked = bookmarkedIds.contains(selected.id),
                      onBookmarkToggle = { viewModel.toggleBookmark(selected.id) },
                      onBackClick = { viewModel.navigateTo(NavDestination.HOME) },
                      onRelatedArticleClick = { viewModel.openArticle(it) }
                    )
                  } else {
                    viewModel.navigateTo(NavDestination.HOME)
                  }
                }

                NavDestination.MATCH_DETAIL -> {
                  val selected = viewModel.selectedMatch.collectAsStateWithLifecycle().value
                  if (selected != null) {
                    MatchDetailScreen(
                      match = selected,
                      currentLanguage = currentLanguage,
                      onBackClick = { viewModel.navigateTo(NavDestination.HOME) }
                    )
                  } else {
                    viewModel.navigateTo(NavDestination.LIVE_SCORE)
                  }
                }

                NavDestination.TEAM_INDIA_SECTION -> {
                  TeamIndiaScreen(
                    newsList = newsList,
                    matchesList = matchesList,
                    bookmarkedIds = bookmarkedIds,
                    currentLanguage = currentLanguage,
                    onArticleClick = { viewModel.openArticle(it) },
                    onBookmarkToggle = { viewModel.toggleBookmark(it) },
                    onMatchClick = { viewModel.openMatch(it) },
                    onBackClick = { viewModel.navigateTo(NavDestination.HOME) }
                  )
                }

                NavDestination.DOMESTIC_SECTION -> {
                  DomesticCricketScreen(
                    newsList = newsList,
                    bookmarkedIds = bookmarkedIds,
                    currentLanguage = currentLanguage,
                    onArticleClick = { viewModel.openArticle(it) },
                    onBookmarkToggle = { viewModel.toggleBookmark(it) },
                    onBackClick = { viewModel.navigateTo(NavDestination.HOME) }
                  )
                }

                NavDestination.IPL_SECTION -> {
                  IplScreen(
                    standings = iplStandings,
                    newsList = newsList,
                    bookmarkedIds = bookmarkedIds,
                    currentLanguage = currentLanguage,
                    onArticleClick = { viewModel.openArticle(it) },
                    onBookmarkToggle = { viewModel.toggleBookmark(it) },
                    onBackClick = { viewModel.navigateTo(NavDestination.HOME) }
                  )
                }

                NavDestination.SEARCH -> {
                  SearchScreen(
                    newsList = newsList,
                    bookmarkedIds = bookmarkedIds,
                    currentLanguage = currentLanguage,
                    onArticleClick = { viewModel.openArticle(it) },
                    onBookmarkToggle = { viewModel.toggleBookmark(it) },
                    onBackClick = { viewModel.navigateTo(NavDestination.HOME) }
                  )
                }

                NavDestination.BOOKMARKS -> {
                  BookmarksScreen(
                    newsList = newsList,
                    bookmarkedIds = bookmarkedIds,
                    currentLanguage = currentLanguage,
                    onArticleClick = { viewModel.openArticle(it) },
                    onBookmarkToggle = { viewModel.toggleBookmark(it) },
                    onBackClick = { viewModel.navigateTo(NavDestination.HOME) }
                  )
                }

                NavDestination.NOTIFICATIONS -> {
                  NotificationsScreen(
                    currentLanguage = currentLanguage,
                    onBackClick = { viewModel.navigateTo(NavDestination.HOME) }
                  )
                }

                NavDestination.AUTH_SCREEN -> {
                  AuthScreen(
                    currentLanguage = currentLanguage,
                    generatedOtp = generatedOtp,
                    onLoginGoogle = { email, role -> viewModel.loginGoogle(email, role) },
                    onSendOtp = { phone -> viewModel.sendOtp(phone) },
                    onVerifyOtp = { phone, otp, role -> viewModel.verifyOtp(phone, otp, role) },
                    onLoginEmail = { email, pass, role -> viewModel.loginEmail(email, pass, role) },
                    onRegister = { name, email, pass -> viewModel.registerUser(name, email, pass) },
                    onForgotPassword = { email -> viewModel.forgotPassword(email) },
                    onBackClick = { viewModel.navigateTo(NavDestination.HOME) }
                  )
                }

                NavDestination.ADMIN_DASHBOARD -> {
                  AdminDashboardScreen(
                    currentUser = currentUser,
                    articlesList = newsList,
                    currentLanguage = currentLanguage,
                    onPublishNews = { title, content, cat, img, breaking, draft ->
                      viewModel.publishArticle(title, content, cat, img, breaking, draft)
                    },
                    onDeleteNews = { viewModel.deleteArticle(it) },
                    onAddVideo = { title, duration, ytid, cat ->
                      viewModel.addVideo(title, duration, ytid, cat)
                    },
                    onBackClick = { viewModel.navigateTo(NavDestination.HOME) }
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
