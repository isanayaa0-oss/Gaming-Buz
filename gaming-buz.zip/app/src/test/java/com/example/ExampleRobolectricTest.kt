package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CricketRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Gaming Buz", appName)
  }

  @Test
  fun `verify repository sections and dynamic builder`() {
    val repo = CricketRepository()
    assertTrue(repo.sections.value.isNotEmpty())
    val initialCount = repo.sections.value.size
    
    // Add custom section
    repo.addSection(
      nameEn = "Fantasy Tips",
      nameHi = "फैंटेसी टिप्स",
      nameBn = "ফ্যান্টাসি টিপস",
      iconName = "star",
      colorHex = "#7C3AED",
      slug = "/fantasy",
      isEnabled = true
    )
    assertEquals(initialCount + 1, repo.sections.value.size)
  }

  @Test
  fun `verify live score and points table`() {
    val repo = CricketRepository()
    val match = repo.liveMatch.value
    assertEquals("INDIA", match.team1Name)
    assertEquals("WEST INDIES", match.team2Name)
    assertEquals(326, match.target)
    
    val table = repo.getPointsTableForSeason("Lifetime")
    assertEquals(5, table.size)
    assertEquals("CSK", table.first().teamCode)
  }
}
