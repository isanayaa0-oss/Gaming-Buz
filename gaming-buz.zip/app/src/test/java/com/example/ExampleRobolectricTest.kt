package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.NewsCategory
import com.example.data.model.UserRole
import com.example.data.repository.AuthRepository
import com.example.data.repository.CricketRepository
import com.example.util.AppLanguage
import com.example.util.Localization
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun testAppNameResource() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Gaming Buz", appName)
  }

  @Test
  fun testTriLingualLocalization() {
    assertEquals("गेमिंग बज", Localization.get("app_name", AppLanguage.HINDI))
    assertEquals("Gaming Buz", Localization.get("app_name", AppLanguage.ENGLISH))
    assertEquals("গেমিং বাজ", Localization.get("app_name", AppLanguage.BANGLA))

    assertEquals("टीम इंडिया", Localization.get("tab_team_india", AppLanguage.HINDI))
    assertEquals("Team India", Localization.get("tab_team_india", AppLanguage.ENGLISH))
    assertEquals("টিম ইন্ডিয়া", Localization.get("tab_team_india", AppLanguage.BANGLA))
  }

  @Test
  fun testAdminSecurityRoleEnforcement() {
    val authRepo = AuthRepository()

    // Unauthorized email attempting Admin login must fail
    val unauthorizedResult = authRepo.loginWithGoogle("hacker@random.com", UserRole.ADMIN)
    assertTrue(unauthorizedResult.isFailure)

    // Authorized admin email succeeds with ADMIN role
    val authorizedResult = authRepo.loginWithGoogle("admin@gamingbuz.com", UserRole.ADMIN)
    assertTrue(authorizedResult.isSuccess)
    assertEquals(UserRole.ADMIN, authorizedResult.getOrNull()?.role)

    // Normal user login succeeds with NORMAL_USER role
    val userResult = authRepo.loginWithGoogle("fan@gmail.com", UserRole.NORMAL_USER)
    assertTrue(userResult.isSuccess)
    assertEquals(UserRole.NORMAL_USER, userResult.getOrNull()?.role)
  }

  @Test
  fun testNewsPublishingAndBookmarking() {
    val repo = CricketRepository()
    val initialCount = repo.newsList.value.size

    val published = repo.publishArticle(
      title = "भारत की शानदार जीत",
      content = "तीसरे टी20 मैच में भारत ने शानदार प्रदर्शन किया।",
      category = NewsCategory.TEAM_INDIA,
      imageUrl = "",
      isBreaking = true,
      isDraft = false
    )

    assertEquals(initialCount + 1, repo.newsList.value.size)
    assertEquals("भारत की शानदार जीत", published.titleHi)

    // Test bookmark toggle
    assertFalse(repo.bookmarkedIds.value.contains(published.id))
    repo.toggleBookmark(published.id)
    assertTrue(repo.bookmarkedIds.value.contains(published.id))
    repo.toggleBookmark(published.id)
    assertFalse(repo.bookmarkedIds.value.contains(published.id))
  }
}
