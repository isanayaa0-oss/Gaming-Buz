import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Data file path
const DATA_DIR = path.join(__dirname, 'server_data');
const NEWS_FILE = path.join(DATA_DIR, 'news.json');

// Ensure directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Helper to read data
function getNewsData() {
  if (fs.existsSync(NEWS_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(NEWS_FILE, 'utf-8'));
    } catch {
      return null;
    }
  }
  return null;
}

function saveNewsData(data: any) {
  fs.writeFileSync(NEWS_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

// REST API Endpoints
app.get('/api/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', app: 'GAMING BUZ API', timestamp: new Date().toISOString() });
});

// GET /api/news
app.get('/api/news', (req: Request, res: Response) => {
  const data = getNewsData();
  if (data) {
    return res.json(data);
  }
  // If not yet persisted on server, return empty to let client use seeded data
  res.json([]);
});

// POST /api/news (Admin authenticated)
app.post('/api/news', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  // Verify token or admin presence
  const item = req.body;
  if (!item || !item.titleHi) {
    return res.status(400).json({ error: 'Headline is required' });
  }

  const existing = getNewsData() || [];
  const updated = [item, ...existing];
  saveNewsData(updated);

  res.status(201).json(item);
});

// PUT /api/news/:id
app.put('/api/news/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const updates = req.body;
  const existing = getNewsData() || [];
  const index = existing.findIndex((n: any) => n.id === id);

  if (index !== -1) {
    existing[index] = { ...existing[index], ...updates };
    saveNewsData(existing);
    return res.json(existing[index]);
  }

  res.status(404).json({ error: 'Article not found' });
});

// DELETE /api/news/:id
app.delete('/api/news/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const existing = getNewsData() || [];
  const filtered = existing.filter((n: any) => n.id !== id);
  saveNewsData(filtered);
  res.json({ success: true });
});

// Start server with Vite middleware in dev or static files in prod
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[GAMING BUZ] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
