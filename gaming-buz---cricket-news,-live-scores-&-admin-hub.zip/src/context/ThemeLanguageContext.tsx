import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, DeviceModel } from '../types';

interface ThemeLanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  isDarkMode: boolean;
  setIsDarkMode: (dark: boolean) => void;
  toggleDarkMode: () => void;
  deviceModel: DeviceModel;
  setDeviceModel: (model: DeviceModel) => void;
  t: (hiText: string, enText: string) => string;
}

const ThemeLanguageContext = createContext<ThemeLanguageContextType | undefined>(undefined);

export const ThemeLanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('hi'); // Default Hindi as requested
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false); // Default White Theme as requested
  const [deviceModel, setDeviceModel] = useState<DeviceModel>('responsive');

  useEffect(() => {
    const savedLang = localStorage.getItem('gamingbuz_lang');
    if (savedLang === 'hi' || savedLang === 'en') {
      setLanguage(savedLang);
    }
    const savedTheme = localStorage.getItem('gamingbuz_theme');
    if (savedTheme) {
      setIsDarkMode(savedTheme === 'dark');
    }
  }, []);

  const toggleLanguage = () => {
    const next = language === 'hi' ? 'en' : 'hi';
    setLanguage(next);
    localStorage.setItem('gamingbuz_lang', next);
  };

  const toggleDarkMode = () => {
    setIsDarkMode(prev => {
      const next = !prev;
      localStorage.setItem('gamingbuz_theme', next ? 'dark' : 'light');
      return next;
    });
  };

  const setLanguageHandler = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('gamingbuz_lang', lang);
  };

  const t = (hiText: string, enText: string): string => {
    return language === 'hi' ? hiText : enText;
  };

  return (
    <ThemeLanguageContext.Provider
      value={{
        language,
        setLanguage: setLanguageHandler,
        toggleLanguage,
        isDarkMode,
        setIsDarkMode,
        toggleDarkMode,
        deviceModel,
        setDeviceModel,
        t
      }}
    >
      {children}
    </ThemeLanguageContext.Provider>
  );
};

export const useThemeLanguage = () => {
  const context = useContext(ThemeLanguageContext);
  if (!context) {
    throw new Error('useThemeLanguage must be used within a ThemeLanguageProvider');
  }
  return context;
};
