import { NewsItem, CricketMatch, VideoItem, PushNotification, UserProfile } from '../types';
import { INITIAL_NEWS, INITIAL_MATCHES, INITIAL_VIDEOS, INITIAL_NOTIFICATIONS } from '../data/initialData';

const NEWS_CACHE_KEY = 'gamingbuz_news_cache_v1';
const MATCHES_CACHE_KEY = 'gamingbuz_matches_cache_v1';
const VIDEOS_CACHE_KEY = 'gamingbuz_videos_cache_v1';
const NOTIFICATIONS_CACHE_KEY = 'gamingbuz_notifs_cache_v1';
const BOOKMARKS_KEY = 'gamingbuz_bookmarks_v1';

// Seed local storage if empty
export const initializeLocalStorage = () => {
  if (!localStorage.getItem(NEWS_CACHE_KEY)) {
    localStorage.setItem(NEWS_CACHE_KEY, JSON.stringify(INITIAL_NEWS));
  }
  if (!localStorage.getItem(MATCHES_CACHE_KEY)) {
    localStorage.setItem(MATCHES_CACHE_KEY, JSON.stringify(INITIAL_MATCHES));
  }
  if (!localStorage.getItem(VIDEOS_CACHE_KEY)) {
    localStorage.setItem(VIDEOS_CACHE_KEY, JSON.stringify(INITIAL_VIDEOS));
  }
  if (!localStorage.getItem(NOTIFICATIONS_CACHE_KEY)) {
    localStorage.setItem(NOTIFICATIONS_CACHE_KEY, JSON.stringify(INITIAL_NOTIFICATIONS));
  }
};

export const api = {
  // Fetch News
  async getNews(): Promise<NewsItem[]> {
    try {
      const res = await fetch('/api/news');
      if (res.ok) {
        const data = await res.json();
        localStorage.setItem(NEWS_CACHE_KEY, JSON.stringify(data));
        return data;
      }
    } catch {
      // Backend not reached, fall back to offline cache
    }
    const cached = localStorage.getItem(NEWS_CACHE_KEY);
    return cached ? JSON.parse(cached) : INITIAL_NEWS;
  },

  // Save News (Create) - Admin only
  async createNews(newsItem: Omit<NewsItem, 'id' | 'publishedAt' | 'views' | 'likes'>, token?: string): Promise<NewsItem> {
    const newItem: NewsItem = {
      ...newsItem,
      id: 'news-' + Date.now(),
      publishedAt: new Date().toISOString(),
      views: 1,
      likes: 0
    };

    try {
      const res = await fetch('/api/news', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token || ''}`
        },
        body: JSON.stringify(newItem)
      });
      if (res.ok) {
        const created = await res.json();
        return created;
      }
    } catch {
      // offline fallback
    }

    // Local fallback update
    const cached = localStorage.getItem(NEWS_CACHE_KEY);
    const list: NewsItem[] = cached ? JSON.parse(cached) : INITIAL_NEWS;
    const updated = [newItem, ...list];
    localStorage.setItem(NEWS_CACHE_KEY, JSON.stringify(updated));
    return newItem;
  },

  // Update News - Admin only
  async updateNews(id: string, updates: Partial<NewsItem>, token?: string): Promise<NewsItem> {
    try {
      const res = await fetch(`/api/news/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token || ''}`
        },
        body: JSON.stringify(updates)
      });
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // fallback
    }

    const cached = localStorage.getItem(NEWS_CACHE_KEY);
    const list: NewsItem[] = cached ? JSON.parse(cached) : INITIAL_NEWS;
    const index = list.findIndex(n => n.id === id);
    if (index !== -1) {
      list[index] = { ...list[index], ...updates };
      localStorage.setItem(NEWS_CACHE_KEY, JSON.stringify(list));
      return list[index];
    }
    throw new Error('News article not found');
  },

  // Delete News - Admin only
  async deleteNews(id: string, token?: string): Promise<boolean> {
    try {
      const res = await fetch(`/api/news/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token || ''}` }
      });
      if (res.ok) {
        // delete successful
      }
    } catch {
      // fallback
    }

    const cached = localStorage.getItem(NEWS_CACHE_KEY);
    const list: NewsItem[] = cached ? JSON.parse(cached) : INITIAL_NEWS;
    const filtered = list.filter(n => n.id !== id);
    localStorage.setItem(NEWS_CACHE_KEY, JSON.stringify(filtered));
    return true;
  },

  // Fetch Matches
  async getMatches(): Promise<CricketMatch[]> {
    try {
      const res = await fetch('/api/matches');
      if (res.ok) {
        const data = await res.json();
        localStorage.setItem(MATCHES_CACHE_KEY, JSON.stringify(data));
        return data;
      }
    } catch {
      // fallback
    }
    const cached = localStorage.getItem(MATCHES_CACHE_KEY);
    return cached ? JSON.parse(cached) : INITIAL_MATCHES;
  },

  // Fetch Videos
  async getVideos(): Promise<VideoItem[]> {
    try {
      const res = await fetch('/api/videos');
      if (res.ok) {
        const data = await res.json();
        localStorage.setItem(VIDEOS_CACHE_KEY, JSON.stringify(data));
        return data;
      }
    } catch {
      // fallback
    }
    const cached = localStorage.getItem(VIDEOS_CACHE_KEY);
    return cached ? JSON.parse(cached) : INITIAL_VIDEOS;
  },

  // Add Video - Admin only
  async createVideo(video: Omit<VideoItem, 'id' | 'views'>, token?: string): Promise<VideoItem> {
    const newVid: VideoItem = {
      ...video,
      id: 'vid-' + Date.now(),
      views: '100 views'
    };

    try {
      const res = await fetch('/api/videos', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token || ''}`
        },
        body: JSON.stringify(newVid)
      });
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // fallback
    }

    const cached = localStorage.getItem(VIDEOS_CACHE_KEY);
    const list: VideoItem[] = cached ? JSON.parse(cached) : INITIAL_VIDEOS;
    const updated = [newVid, ...list];
    localStorage.setItem(VIDEOS_CACHE_KEY, JSON.stringify(updated));
    return newVid;
  },

  // Notifications
  async getNotifications(): Promise<PushNotification[]> {
    const cached = localStorage.getItem(NOTIFICATIONS_CACHE_KEY);
    return cached ? JSON.parse(cached) : INITIAL_NOTIFICATIONS;
  },

  async broadcastNotification(notification: { title: string; body: string; type: 'breaking' | 'match' | 'system'; articleId?: string }, token?: string): Promise<PushNotification> {
    const newNotif: PushNotification = {
      id: 'notif-' + Date.now(),
      title: notification.title,
      body: notification.body,
      time: 'अभी-अभी (Just now)',
      isRead: false,
      type: notification.type,
      articleId: notification.articleId
    };

    const cached = localStorage.getItem(NOTIFICATIONS_CACHE_KEY);
    const list: PushNotification[] = cached ? JSON.parse(cached) : INITIAL_NOTIFICATIONS;
    const updated = [newNotif, ...list];
    localStorage.setItem(NOTIFICATIONS_CACHE_KEY, JSON.stringify(updated));
    return newNotif;
  },

  // Bookmarks
  getBookmarks(): string[] {
    const saved = localStorage.getItem(BOOKMARKS_KEY);
    return saved ? JSON.parse(saved) : [];
  },

  toggleBookmark(newsId: string): boolean {
    const saved = this.getBookmarks();
    let updated: string[];
    let isBookmarked = false;
    if (saved.includes(newsId)) {
      updated = saved.filter(id => id !== newsId);
      isBookmarked = false;
    } else {
      updated = [...saved, newsId];
      isBookmarked = true;
    }
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(updated));
    return isBookmarked;
  }
};
