export type Language = 'hi' | 'en';

export type Category = 
  | 'all'
  | 'team_india'
  | 'ipl'
  | 'domestic'
  | 'international'
  | 'live_matches'
  | 'videos';

export interface NewsItem {
  id: string;
  titleHi: string;
  titleEn: string;
  summaryHi: string;
  summaryEn: string;
  contentHi: string;
  contentEn: string;
  category: 'team_india' | 'ipl' | 'domestic' | 'international';
  subCategory?: string; // e.g. 'Ranji Trophy', 'Test', 'T20', 'CSK'
  imageUrl: string;
  additionalImages?: string[];
  isBreaking?: boolean;
  isFeatured?: boolean;
  publishedAt: string;
  author: string;
  views: number;
  likes: number;
  status: 'published' | 'draft';
  tags: string[];
  matchId?: string;
  youtubeId?: string;
}

export interface BatsmanScore {
  name: string;
  runs: number;
  balls: number;
  fours: number;
  sixes: number;
  strikeRate: number;
  dismissal: string;
  isOut: boolean;
}

export interface BowlerFigure {
  name: string;
  overs: string;
  maidens: number;
  runs: number;
  wickets: number;
  economy: number;
}

export interface Innings {
  teamName: string;
  teamShort: string;
  score: string; // e.g. "188/3"
  overs: string; // e.g. "18.2"
  batting: BatsmanScore[];
  bowling: BowlerFigure[];
}

export interface CricketMatch {
  id: string;
  series: string;
  matchType: 'T20' | 'ODI' | 'TEST' | 'IPL' | 'DOMESTIC';
  team1: {
    id: string;
    nameHi: string;
    nameEn: string;
    shortName: string;
    flag: string;
    score?: string;
    overs?: string;
  };
  team2: {
    id: string;
    nameHi: string;
    nameEn: string;
    shortName: string;
    flag: string;
    score?: string;
    overs?: string;
  };
  status: 'live' | 'upcoming' | 'completed';
  statusTextHi: string;
  statusTextEn: string;
  venueHi: string;
  venueEn: string;
  startTime: string;
  tossHi?: string;
  tossEn?: string;
  currentInnings?: number;
  currentBatsmen?: { name: string; runs: number; balls: number }[];
  currentBowler?: { name: string; figures: string };
  innings?: Innings[];
  recentBalls?: string[];
  target?: number;
  requiredRate?: string;
}

export interface DomesticTournament {
  id: string;
  nameHi: string;
  nameEn: string;
  descriptionHi: string;
  descriptionEn: string;
  trophyType: 'FirstClass' | 'ListA' | 'T20';
  currentChampion: string;
  table: {
    team: string;
    played: number;
    won: number;
    lost: number;
    draw?: number;
    points: number;
    nrr?: string;
  }[];
  topPerformers: {
    player: string;
    team: string;
    stat: string;
    role: string;
  }[];
}

export interface IPLTeamStanding {
  position: number;
  team: string;
  shortName: string;
  played: number;
  won: number;
  lost: number;
  nrr: string;
  points: number;
  logo: string;
}

export interface VideoItem {
  id: string;
  titleHi: string;
  titleEn: string;
  thumbnail: string;
  youtubeId: string;
  duration: string;
  category: string;
  publishedAt: string;
  views: string;
  relatedNewsId?: string;
}

export type UserRole = 'USER' | 'ADMIN';

export interface UserProfile {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  role: UserRole;
  avatar?: string;
  authProvider: 'google' | 'phone' | 'email' | 'admin';
  createdAt: string;
  isAdminVerified?: boolean;
}

export interface PushNotification {
  id: string;
  title: string;
  body: string;
  time: string;
  isRead: boolean;
  type: 'breaking' | 'match' | 'system';
  articleId?: string;
}

export type DeviceModel = 
  | 'responsive'
  | 'oneplus'
  | 'samsung'
  | 'pixel'
  | 'redmi'
  | 'tablet';
