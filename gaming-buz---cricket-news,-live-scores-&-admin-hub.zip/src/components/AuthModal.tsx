import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  User, 
  Mail, 
  Phone, 
  Lock, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle,
  KeyRound,
  LogOut,
  RefreshCw,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useThemeLanguage } from '../context/ThemeLanguageContext';

export const AuthModal: React.FC = () => {
  const { 
    user, 
    isAdmin, 
    isAuthModalOpen, 
    closeAuthModal, 
    authModalRole,
    loginAsAdmin,
    loginWithGoogle,
    sendPhoneOtp,
    loginWithPhone,
    loginWithEmail,
    registerWithEmail,
    resetPassword,
    logout
  } = useAuth();
  const { isDarkMode, t } = useThemeLanguage();

  // Selected flow mode: 'role_picker' | 'admin_auth' | 'user_google' | 'user_phone' | 'user_email_login' | 'user_email_reg' | 'forgot_pass'
  const [authStep, setAuthStep] = useState<'role_picker' | 'admin_auth' | 'user_phone' | 'user_email_login' | 'user_email_reg' | 'forgot_pass'>(
    authModalRole === 'admin' ? 'admin_auth' : 'role_picker'
  );

  // Form states
  const [adminPass, setAdminPass] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpPreviewText, setOtpPreviewText] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  
  // Status feedback
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isAuthModalOpen) return null;

  // Handle Admin Verification
  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsSubmitting(true);

    const res = await loginAsAdmin(adminPass);
    setIsSubmitting(false);
    if (res.success) {
      setSuccessMsg(res.message);
      setTimeout(() => {
        closeAuthModal();
      }, 1000);
    } else {
      setErrorMsg(res.message);
    }
  };

  // Handle Google Login
  const handleGoogleClick = async () => {
    setErrorMsg('');
    setIsSubmitting(true);
    const res = await loginWithGoogle();
    setIsSubmitting(false);
    if (res.success) {
      setSuccessMsg(res.message);
      setTimeout(() => closeAuthModal(), 800);
    }
  };

  // Handle Phone OTP Send
  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsSubmitting(true);

    const fullPhone = phoneNumber.startsWith('+91') ? phoneNumber : `+91 ${phoneNumber}`;
    const res = await sendPhoneOtp(fullPhone);
    setIsSubmitting(false);

    if (res.success) {
      setOtpSent(true);
      setSuccessMsg(res.message);
      if (res.otpPreview) {
        setOtpPreviewText(res.otpPreview);
      }
    } else {
      setErrorMsg(res.message);
    }
  };

  // Handle Phone OTP Verify
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsSubmitting(true);

    const fullPhone = phoneNumber.startsWith('+91') ? phoneNumber : `+91 ${phoneNumber}`;
    const res = await loginWithPhone(fullPhone, otpCode);
    setIsSubmitting(false);

    if (res.success) {
      setSuccessMsg(res.message);
      setTimeout(() => closeAuthModal(), 800);
    } else {
      setErrorMsg(res.message);
    }
  };

  // Handle Email Login
  const handleEmailLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsSubmitting(true);

    const res = await loginWithEmail(email, password);
    setIsSubmitting(false);
    if (res.success) {
      setSuccessMsg(res.message);
      setTimeout(() => closeAuthModal(), 800);
    } else {
      setErrorMsg(res.message);
    }
  };

  // Handle Email Register
  const handleEmailRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsSubmitting(true);

    const res = await registerWithEmail(fullName, email, password);
    setIsSubmitting(false);
    if (res.success) {
      setSuccessMsg(res.message);
      setTimeout(() => closeAuthModal(), 800);
    } else {
      setErrorMsg(res.message);
    }
  };

  // Handle Forgot Password
  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsSubmitting(true);

    const res = await resetPassword(email);
    setIsSubmitting(false);
    if (res.success) {
      setSuccessMsg(res.message);
    } else {
      setErrorMsg(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className={`w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border flex flex-col transition-colors ${
        isDarkMode ? 'bg-gray-900 border-gray-800 text-gray-100' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        {/* Header Bar */}
        <div className="p-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xl">🏏</span>
            <h3 className="font-extrabold text-base">
              GAMING BUZ {t('अकाउंट सिस्टम', 'Account System')}
            </h3>
          </div>
          <button
            onClick={closeAuthModal}
            className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto">
          {/* If already logged in, show profile card and logout option */}
          {user ? (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 rounded-full mx-auto overflow-hidden ring-4 ring-emerald-500/30">
                <img src={user.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80'} alt="" className="w-full h-full object-cover" />
              </div>
              <div>
                <h4 className="font-extrabold text-lg">{user.name}</h4>
                <p className="text-xs text-gray-400">{user.email || user.phone}</p>
                <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                  {isAdmin ? <ShieldCheck className="w-3.5 h-3.5 text-amber-500" /> : <User className="w-3.5 h-3.5" />}
                  <span>{isAdmin ? t('अधिकृत मुख्य संपादक (ADMIN)', 'Chief Editor & Admin') : t('प्रमाणित पाठक (USER)', 'Standard User')}</span>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-100 dark:border-gray-800 flex flex-col gap-2">
                <button
                  onClick={() => {
                    logout();
                    setAuthStep('role_picker');
                  }}
                  className="w-full py-2.5 rounded-xl font-bold text-xs bg-red-600 hover:bg-red-700 text-white transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>{t('लॉगआउट करें (Logout)', 'Logout')}</span>
                </button>
              </div>
            </div>
          ) : (
            <div>
              {/* Error & Success Toasts */}
              {errorMsg && (
                <div className="mb-4 p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-300 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}
              {successMsg && (
                <div className="mb-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-600 dark:text-emerald-300 text-xs flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{successMsg}</span>
                </div>
              )}

              {/* STEP: ROLE PICKER (Developer/Admin vs Normal User) */}
              {authStep === 'role_picker' && (
                <div className="space-y-4">
                  <div className="text-center mb-5">
                    <h3 className="font-extrabold text-lg">
                      {t('लॉगिन विकल्प चुनें', 'Select Account Role')}
                    </h3>
                    <p className="text-xs text-gray-500 mt-1">
                      {t('कृपया अपनी भूमिका के अनुसार उपयुक्त विकल्प का चयन करें', 'Select your access level to continue')}
                    </p>
                  </div>

                  {/* Option A: Developer / Admin Login */}
                  <button
                    onClick={() => setAuthStep('admin_auth')}
                    className={`w-full p-4 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between group hover:border-amber-500 ${
                      isDarkMode ? 'bg-gray-800/60 border-gray-700' : 'bg-amber-50/50 border-amber-200 hover:bg-amber-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold">
                        <ShieldCheck className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-sm flex items-center gap-1.5">
                          <span>{t('डेवलपर / एडमिन लॉगिन', 'Developer / Admin Login')}</span>
                          <span className="text-[10px] bg-amber-500 text-white px-1.5 py-0.2 rounded font-mono">
                            SECURE
                          </span>
                        </h4>
                        <p className="text-xs text-gray-500 mt-0.5">
                          {t('समाचार प्रकाशन, संपादन, वीडियो व पुश नोटिफिकेशन प्रबंधन', 'Full news publishing, live updates & video controls')}
                        </p>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-gray-400 group-hover:translate-x-1 transition-transform" />
                  </button>

                  {/* Option B: Normal User Login */}
                  <div className="pt-2">
                    <h4 className="text-xs font-black uppercase tracking-wider text-gray-400 mb-2">
                      {t('सामान्य पाठक लॉगिन (Normal User)', 'Normal User Login')}
                    </h4>

                    {/* Google Login */}
                    <button
                      onClick={handleGoogleClick}
                      disabled={isSubmitting}
                      className={`w-full mb-2.5 p-3 rounded-2xl border text-xs font-bold transition-all flex items-center justify-center gap-2.5 cursor-pointer shadow-xs ${
                        isDarkMode 
                          ? 'bg-gray-800 border-gray-700 hover:bg-gray-700' 
                          : 'bg-white border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.87c2.27-2.09 3.675-5.17 3.675-9.15z"/>
                        <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.87-3.05c-1.08.72-2.45 1.16-4.06 1.16-3.13 0-5.78-2.11-6.73-4.96H1.28v3.15C3.26 21.36 7.34 24 12 24z"/>
                        <path fill="#FBBC05" d="M5.27 14.24c-.25-.72-.39-1.49-.39-2.24s.14-1.52.39-2.24V6.61H1.28C.46 8.23 0 10.06 0 12s.46 3.77 1.28 5.39l3.99-3.15z"/>
                        <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.26 2.64 1.28 6.61l3.99 3.15c.95-2.85 3.6-4.96 6.73-4.96z"/>
                      </svg>
                      <span>{t('Google के साथ जारी रखें (Continue with Google)', 'Continue with Google')}</span>
                    </button>

                    {/* Phone Number OTP Login */}
                    <button
                      onClick={() => setAuthStep('user_phone')}
                      className={`w-full mb-2.5 p-3 rounded-2xl border text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs ${
                        isDarkMode 
                          ? 'bg-gray-800 border-gray-700 hover:bg-gray-700' 
                          : 'bg-white border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      <Phone className="w-4 h-4 text-emerald-500" />
                      <span>{t('मोबाइल नंबर व OTP से लॉगिन करें', 'Login with Phone Number (OTP)')}</span>
                    </button>

                    {/* Email / Password Login */}
                    <button
                      onClick={() => setAuthStep('user_email_login')}
                      className={`w-full p-3 rounded-2xl border text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs ${
                        isDarkMode 
                          ? 'bg-gray-800 border-gray-700 hover:bg-gray-700' 
                          : 'bg-white border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      <Mail className="w-4 h-4 text-blue-500" />
                      <span>{t('ईमेल और पासवर्ड से लॉगिन करें', 'Login with Email & Password')}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* STEP: DEVELOPER / ADMIN AUTH */}
              {authStep === 'admin_auth' && (
                <form onSubmit={handleAdminSubmit} className="space-y-4">
                  <div className="flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => setAuthStep('role_picker')}
                      className="text-xs text-emerald-600 hover:underline cursor-pointer font-bold"
                    >
                      ← {t('वापस (Back)', 'Back')}
                    </button>
                    <span className="text-[10px] bg-amber-500 text-white px-2 py-0.5 rounded font-mono font-bold">
                      ADMIN PORTAL
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs">
                    <p className="font-bold text-amber-900 dark:text-amber-200">
                      🔐 {t('सर्वर प्रमाणीकरण आवश्यक', 'Server Verification Required')}
                    </p>
                    <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-1">
                      {t('केवल अधिकृत व्यवस्थापक को ही समाचार प्रकाशित करने का अधिकार है।', 'Only authorized administrators with valid key can access the CMS dashboard.')}
                    </p>
                  </div>

                  <div>
                    <label className="text-xs font-bold block mb-1">
                      {t('एडमिन सुरक्षा कुंजी / पासवर्ड', 'Admin Master Key / Password')}
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                      <input
                        type="password"
                        required
                        value={adminPass}
                        onChange={(e) => setAdminPass(e.target.value)}
                        placeholder="Master Admin Key दर्ज करें"
                        className={`w-full pl-9 pr-3 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                          isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                        }`}
                      />
                    </div>
                    <p className="text-[10px] text-gray-400 mt-1">
                      💡 <b>Test Key:</b> <code className="bg-gray-100 dark:bg-gray-800 px-1 py-0.5 rounded">Admin@Buz2026!</code> अथवा <code className="bg-gray-100 dark:bg-gray-800 px-1 py-0.5 rounded">admin123</code>
                    </p>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-2.5 rounded-xl font-bold text-xs bg-amber-600 hover:bg-amber-700 text-white transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-sm"
                  >
                    <KeyRound className="w-4 h-4" />
                    <span>{isSubmitting ? t('सत्यापित हो रहा है...', 'Verifying...') : t('प्रवेश करें (Verify & Login)', 'Verify & Login')}</span>
                  </button>
                </form>
              )}

              {/* STEP: PHONE NUMBER OTP */}
              {authStep === 'user_phone' && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <button
                      type="button"
                      onClick={() => setAuthStep('role_picker')}
                      className="text-xs text-emerald-600 hover:underline cursor-pointer font-bold"
                    >
                      ← {t('वापस (Back)', 'Back')}
                    </button>
                    <span className="text-xs font-bold text-gray-400">
                      {t('फोन सत्यापन', 'Phone OTP')}
                    </span>
                  </div>

                  {!otpSent ? (
                    <form onSubmit={handleSendOtp} className="space-y-4">
                      <div>
                        <label className="text-xs font-bold block mb-1">
                          {t('मोबाइल नंबर दर्ज करें', 'Enter Mobile Number')}
                        </label>
                        <div className="flex items-center gap-2">
                          <span className="px-3 py-2.5 rounded-xl border text-xs font-bold bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300">
                            +91 (India)
                          </span>
                          <input
                            type="tel"
                            required
                            value={phoneNumber}
                            onChange={(e) => setPhoneNumber(e.target.value)}
                            placeholder="9876543210"
                            maxLength={10}
                            className={`flex-1 px-3 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono ${
                              isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                            }`}
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full py-2.5 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-700 text-white transition-colors cursor-pointer"
                      >
                        {isSubmitting ? t('भेजा जा रहा है...', 'Sending...') : t('ओटीपी प्राप्त करें (Send OTP)', 'Send OTP')}
                      </button>
                    </form>
                  ) : (
                    <form onSubmit={handleVerifyOtp} className="space-y-4">
                      {otpPreviewText && (
                        <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 text-xs border border-emerald-200">
                          📱 टेस्ट ओटीपी कोड: <b>{otpPreviewText}</b>
                        </div>
                      )}

                      <div>
                        <label className="text-xs font-bold block mb-1">
                          {t('6 अंकों का OTP दर्ज करें', 'Enter 6-digit OTP')}
                        </label>
                        <input
                          type="text"
                          required
                          value={otpCode}
                          onChange={(e) => setOtpCode(e.target.value)}
                          placeholder="582914"
                          maxLength={6}
                          className={`w-full px-3 py-2.5 rounded-xl text-center text-lg font-mono font-bold tracking-widest border focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                            isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                          }`}
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full py-2.5 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-700 text-white transition-colors cursor-pointer"
                      >
                        {isSubmitting ? t('सत्यापित हो रहा है...', 'Verifying...') : t('ओटीपी सत्यापित करें (Verify OTP)', 'Verify OTP')}
                      </button>

                      <div className="text-center">
                        <button
                          type="button"
                          onClick={() => setOtpSent(false)}
                          className="text-xs text-gray-400 hover:underline cursor-pointer"
                        >
                          {t('नंबर बदलें / पुनः भेजें', 'Change number / Resend')}
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {/* STEP: EMAIL LOGIN */}
              {authStep === 'user_email_login' && (
                <form onSubmit={handleEmailLoginSubmit} className="space-y-3.5">
                  <div className="flex items-center justify-between mb-2">
                    <button
                      type="button"
                      onClick={() => setAuthStep('role_picker')}
                      className="text-xs text-emerald-600 hover:underline cursor-pointer font-bold"
                    >
                      ← {t('वापस (Back)', 'Back')}
                    </button>
                    <span className="text-xs font-bold text-gray-400">
                      {t('ईमेल लॉगिन', 'Email Login')}
                    </span>
                  </div>

                  <div>
                    <label className="text-xs font-bold block mb-1">ईमेल (Email)</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                        isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                      }`}
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold">पासवर्ड (Password)</label>
                      <button
                        type="button"
                        onClick={() => setAuthStep('forgot_pass')}
                        className="text-[11px] text-emerald-600 hover:underline cursor-pointer"
                      >
                        {t('पासवर्ड भूल गए?', 'Forgot?')}
                      </button>
                    </div>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                        isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                      }`}
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-2.5 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-700 text-white transition-colors cursor-pointer"
                  >
                    {isSubmitting ? t('लॉगिन हो रहा है...', 'Logging in...') : t('लॉगिन करें (Sign In)', 'Sign In')}
                  </button>

                  <div className="text-center pt-2">
                    <span className="text-xs text-gray-400">
                      {t('नया खाता चाहिए? ', "Don't have an account? ")}
                    </span>
                    <button
                      type="button"
                      onClick={() => setAuthStep('user_email_reg')}
                      className="text-xs font-bold text-emerald-600 hover:underline cursor-pointer"
                    >
                      {t('पंजीकरण करें (Register)', 'Register')}
                    </button>
                  </div>
                </form>
              )}

              {/* STEP: EMAIL REGISTER */}
              {authStep === 'user_email_reg' && (
                <form onSubmit={handleEmailRegisterSubmit} className="space-y-3.5">
                  <div className="flex items-center justify-between mb-2">
                    <button
                      type="button"
                      onClick={() => setAuthStep('user_email_login')}
                      className="text-xs text-emerald-600 hover:underline cursor-pointer font-bold"
                    >
                      ← {t('लॉगिन पर लौटें', 'Back to Login')}
                    </button>
                    <span className="text-xs font-bold text-gray-400">
                      {t('नया उपयोगकर्ता खाता', 'New User Account')}
                    </span>
                  </div>

                  <div>
                    <label className="text-xs font-bold block mb-1">पूरा नाम (Full Name)</label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="राहुल शर्मा"
                      className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                        isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                      }`}
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold block mb-1">ईमेल पता (Email)</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="rahul@example.com"
                      className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                        isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                      }`}
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold block mb-1">पासवर्ड (कम से कम 6 अक्षर)</label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                        isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                      }`}
                    />
                  </div>

                  <p className="text-[10.5px] text-gray-400">
                    * {t('नया पंजीकरण सामान्य पाठक (USER) भूमिका में होगा। एडमिन केवल अधिकृत व्यवस्थापकों द्वारा लॉगिन हो सकते हैं।', 'New registration assigns normal USER role. Admin access is restricted.')}
                  </p>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-2.5 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-700 text-white transition-colors cursor-pointer"
                  >
                    {isSubmitting ? t('खाता बन रहा है...', 'Creating...') : t('खाता बनाएं (Register)', 'Register')}
                  </button>
                </form>
              )}

              {/* STEP: FORGOT PASSWORD */}
              {authStep === 'forgot_pass' && (
                <form onSubmit={handleForgotPassword} className="space-y-4">
                  <div className="flex items-center justify-between mb-2">
                    <button
                      type="button"
                      onClick={() => setAuthStep('user_email_login')}
                      className="text-xs text-emerald-600 hover:underline cursor-pointer font-bold"
                    >
                      ← {t('वापस', 'Back')}
                    </button>
                    <span className="text-xs font-bold text-gray-400">
                      {t('पासवर्ड रीसेट', 'Password Reset')}
                    </span>
                  </div>

                  <div>
                    <label className="text-xs font-bold block mb-1">पंजीकृत ईमेल पता</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                        isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                      }`}
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-2.5 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-700 text-white transition-colors cursor-pointer"
                  >
                    {isSubmitting ? t('भेजा जा रहा है...', 'Sending...') : t('रीसेट लिंक भेजें', 'Send Reset Link')}
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
