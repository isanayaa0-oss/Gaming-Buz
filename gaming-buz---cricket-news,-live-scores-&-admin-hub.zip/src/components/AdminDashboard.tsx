import React, { useState } from 'react';
import { 
  PlusCircle, 
  Edit3, 
  Trash2, 
  Eye, 
  Send, 
  FileText, 
  Image as ImageIcon, 
  Video, 
  Bell, 
  CheckCircle2, 
  AlertCircle, 
  Lock, 
  Sparkles,
  ExternalLink,
  Flame,
  ArrowLeft,
  Upload,
  RefreshCw
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { NewsItem, VideoItem, PushNotification } from '../types';

interface AdminDashboardProps {
  newsList: NewsItem[];
  onAddNews: (item: Omit<NewsItem, 'id' | 'publishedAt' | 'views' | 'likes'>) => Promise<NewsItem>;
  onUpdateNews: (id: string, updates: Partial<NewsItem>) => Promise<NewsItem>;
  onDeleteNews: (id: string) => Promise<boolean>;
  onAddVideo: (video: Omit<VideoItem, 'id' | 'views'>) => Promise<VideoItem>;
  onBroadcastNotif: (notif: { title: string; body: string; type: 'breaking' | 'match' | 'system'; articleId?: string }) => Promise<PushNotification>;
  onBackToApp: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  newsList,
  onAddNews,
  onUpdateNews,
  onDeleteNews,
  onAddVideo,
  onBroadcastNotif,
  onBackToApp
}) => {
  const { user, isAdmin, token, openAuthModal } = useAuth();
  const { isDarkMode, t } = useThemeLanguage();

  const [activeTab, setActiveTab] = useState<'news_list' | 'add_news' | 'videos' | 'broadcast'>('news_list');
  const [editingNewsId, setEditingNewsId] = useState<string | null>(null);

  // Form states for Add/Edit News
  const [headlineHi, setHeadlineHi] = useState('');
  const [headlineEn, setHeadlineEn] = useState('');
  const [summaryHi, setSummaryHi] = useState('');
  const [summaryEn, setSummaryEn] = useState('');
  const [contentHi, setContentHi] = useState('');
  const [contentEn, setContentEn] = useState('');
  const [category, setCategory] = useState<'team_india' | 'ipl' | 'domestic' | 'international'>('team_india');
  const [subCategory, setSubCategory] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [additionalImagesText, setAdditionalImagesText] = useState('');
  const [isBreaking, setIsBreaking] = useState(false);
  const [isFeatured, setIsFeatured] = useState(false);
  const [status, setStatus] = useState<'published' | 'draft'>('published');
  const [authorName, setAuthorName] = useState('संपादकीय टीम (Editorial Team)');
  const [tagsInput, setTagsInput] = useState('Cricket, Team India');

  // Video Form
  const [videoTitleHi, setVideoTitleHi] = useState('');
  const [videoTitleEn, setVideoTitleEn] = useState('');
  const [youtubeId, setYoutubeId] = useState('');
  const [videoCategory, setVideoCategory] = useState('Match Highlights');
  const [videoDuration, setVideoDuration] = useState('08:45');

  // Notification Form
  const [notifTitle, setNotifTitle] = useState('');
  const [notifBody, setNotifBody] = useState('');
  const [notifType, setNotifType] = useState<'breaking' | 'match' | 'system'>('breaking');

  // Feedback status
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Show Toast
  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // Quick preset cricket images
  const sampleImages = [
    { title: 'Trophy / Stadium', url: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=1200&q=80' },
    { title: 'Cricket Action', url: 'https://images.unsplash.com/photo-1531415074868-036b107e775a?auto=format&fit=crop&w=1200&q=80' },
    { title: 'Ranji / First Class', url: 'https://images.unsplash.com/photo-1589487391730-58f20eb2c308?auto=format&fit=crop&w=1200&q=80' },
    { title: 'Pitch & Ball', url: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=1200&q=80' }
  ];

  // If user is not authorized admin, show access restricted shield
  if (!isAdmin) {
    return (
      <div className={`p-8 rounded-3xl border text-center max-w-xl mx-auto my-12 ${
        isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xl'
      }`}>
        <div className="w-16 h-16 rounded-3xl bg-amber-500/10 text-amber-600 flex items-center justify-center mx-auto mb-4 ring-8 ring-amber-500/5">
          <Lock className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black mb-2">
          {t('एडमिन प्रमाणीकरण आवश्यक', 'Admin Authorization Required')}
        </h2>
        <p className="text-xs sm:text-sm text-gray-500 mb-6 leading-relaxed">
          {t(
            'यह Professional News Admin Dashboard केवल अधिकृत संपादकों व व्यवस्थापकों के लिए है। कृपया अधिकृत मास्टर क्रेडेंशियल से लॉगिन करें।',
            'This Professional News Publishing Dashboard is restricted to authorized editors. Please authenticate with Admin Key.'
          )}
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button
            onClick={() => openAuthModal('admin')}
            className="px-6 py-3 rounded-2xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs cursor-pointer shadow-md"
          >
            {t('एडमिन लॉगिन करें (Admin Login)', 'Open Admin Login')}
          </button>
          <button
            onClick={onBackToApp}
            className="px-6 py-3 rounded-2xl border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 font-bold text-xs hover:bg-gray-100 cursor-pointer"
          >
            {t('ऐप पर वापस जाएं', 'Back to App')}
          </button>
        </div>
      </div>
    );
  }

  // Populate Edit form
  const handleStartEdit = (news: NewsItem) => {
    setEditingNewsId(news.id);
    setHeadlineHi(news.titleHi);
    setHeadlineEn(news.titleEn);
    setSummaryHi(news.summaryHi);
    setSummaryEn(news.summaryEn);
    setContentHi(news.contentHi);
    setContentEn(news.contentEn);
    setCategory(news.category);
    setSubCategory(news.subCategory || '');
    setImageUrl(news.imageUrl);
    setAdditionalImagesText((news.additionalImages || []).join('\n'));
    setIsBreaking(news.isBreaking || false);
    setIsFeatured(news.isFeatured || false);
    setStatus(news.status);
    setAuthorName(news.author);
    setTagsInput(news.tags.join(', '));
    setActiveTab('add_news');
  };

  const resetNewsForm = () => {
    setEditingNewsId(null);
    setHeadlineHi('');
    setHeadlineEn('');
    setSummaryHi('');
    setSummaryEn('');
    setContentHi('');
    setContentEn('');
    setCategory('team_india');
    setSubCategory('');
    setImageUrl('');
    setAdditionalImagesText('');
    setIsBreaking(false);
    setIsFeatured(false);
    setStatus('published');
    setAuthorName('संपादकीय टीम (Editorial Team)');
    setTagsInput('Cricket, Team India');
  };

  // Submit News (Add or Edit)
  const handleSubmitNews = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!headlineHi.trim()) {
      showToast('कृपया हिंदी में मुख्य हेडलाइन लिखें!', 'error');
      return;
    }

    setIsSubmitting(true);
    const tags = tagsInput.split(',').map(t => t.trim()).filter(Boolean);
    const addImages = additionalImagesText.split('\n').map(s => s.trim()).filter(Boolean);

    try {
      if (editingNewsId) {
        // Update
        await onUpdateNews(editingNewsId, {
          titleHi: headlineHi,
          titleEn: headlineEn || headlineHi,
          summaryHi: summaryHi || headlineHi.slice(0, 100),
          summaryEn: summaryEn || headlineEn.slice(0, 100),
          contentHi: contentHi || summaryHi,
          contentEn: contentEn || summaryEn,
          category,
          subCategory,
          imageUrl: imageUrl || sampleImages[0].url,
          additionalImages: addImages,
          isBreaking,
          isFeatured,
          status,
          author: authorName,
          tags
        });
        showToast('खबर सफलतापूर्वक अपडेट कर दी गई! (Updated Live)');
      } else {
        // Create new
        await onAddNews({
          titleHi: headlineHi,
          titleEn: headlineEn || headlineHi,
          summaryHi: summaryHi || headlineHi.slice(0, 100),
          summaryEn: summaryEn || headlineEn.slice(0, 100),
          contentHi: contentHi || summaryHi,
          contentEn: contentEn || summaryEn,
          category,
          subCategory,
          imageUrl: imageUrl || sampleImages[0].url,
          additionalImages: addImages,
          isBreaking,
          isFeatured,
          status,
          author: authorName,
          tags
        });
        showToast('नई खबर सफलतापूर्वक प्रकाशित हो गई! (Published Live without rebuilding)');
      }
      resetNewsForm();
      setActiveTab('news_list');
    } catch {
      showToast('खबर सेव करने में त्रुटि!', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Delete News
  const handleDeleteNews = async (id: string, title: string) => {
    if (window.confirm(`क्या आप वाकई इस खबर को हटाना चाहते हैं?\n"${title}"`)) {
      await onDeleteNews(id);
      showToast('खबर हटा दी गई।');
    }
  };

  // Add Video
  const handleAddVideoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoTitleHi || !youtubeId) {
      showToast('कृपया वीडियो का शीर्षक और YouTube ID दर्ज करें', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      await onAddVideo({
        titleHi: videoTitleHi,
        titleEn: videoTitleEn || videoTitleHi,
        youtubeId: youtubeId.trim(),
        thumbnail: sampleImages[1].url,
        duration: videoDuration,
        category: videoCategory,
        publishedAt: 'अभी-अभी'
      });
      showToast('क्रिकेट वीडियो सफलतापूर्वक जोड़ा गया!');
      setVideoTitleHi('');
      setVideoTitleEn('');
      setYoutubeId('');
      setActiveTab('news_list');
    } catch {
      showToast('वीडियो जोड़ने में त्रुटि!', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Broadcast Notification
  const handleBroadcastNotifSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle || !notifBody) {
      showToast('कृपया टाइटल और संदेश लिखें', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      await onBroadcastNotif({
        title: notifTitle,
        body: notifBody,
        type: notifType
      });
      showToast('पुश नोटिफिकेशन सभी उपयोगकर्ताओं को भेजा गया! (Broadcasted)');
      setNotifTitle('');
      setNotifBody('');
    } catch {
      showToast('नोटिफिकेशन भेजने में त्रुटि', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 p-4 rounded-2xl shadow-xl flex items-center gap-3 text-xs font-bold animate-bounce ${
          toast.type === 'success' ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'
        }`}>
          {toast.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Admin Header Banner */}
      <div className={`p-6 sm:p-8 rounded-3xl border flex items-center justify-between flex-wrap gap-4 ${
        isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-linear-to-r from-amber-500 via-orange-600 to-amber-700 text-white shadow-lg'
      }`}>
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10.5px] font-black uppercase tracking-wider bg-white/20 backdrop-blur-md">
              OPTION C • PRO NEWS CMS
            </span>
            <span className="text-xs font-semibold text-amber-200">
              {t('लाइव डेटाबेस सिंक सक्रिय', 'Live Database Sync Active')}
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black">
            {t('GAMING BUZ एडमिन पब्लिशिंग डैशबोर्ड', 'Gaming Buz News Publishing Hub')}
          </h2>
          <p className="text-xs sm:text-sm text-amber-100/90 mt-1 max-w-xl">
            {t(
              'यहाँ से नई खबरें प्रकाशित करें, फोटो अपलोड करें, वीडियो जोड़ें और पुश नोटिफिकेशन भेजें - बिना नया APK बनाए!',
              'Publish breaking cricket news, manage thumbnails, upload video highlights, and push alerts instantly.'
            )}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onBackToApp}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-white/20 hover:bg-white/30 text-white backdrop-blur-md transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{t('ऐप व्यू पर लौटें', 'View Live App')}</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-gray-200 dark:border-gray-800 text-xs sm:text-sm font-bold gap-1 sm:gap-2 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('news_list')}
          className={`px-4 py-3 border-b-2 whitespace-nowrap transition-colors cursor-pointer flex items-center gap-2 ${
            activeTab === 'news_list' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-500'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>{t('प्रकाशित खबरें (News List)', 'News Articles')} ({newsList.length})</span>
        </button>

        <button
          onClick={() => {
            resetNewsForm();
            setActiveTab('add_news');
          }}
          className={`px-4 py-3 border-b-2 whitespace-nowrap transition-colors cursor-pointer flex items-center gap-2 ${
            activeTab === 'add_news' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-500'
          }`}
        >
          <PlusCircle className="w-4 h-4" />
          <span>{editingNewsId ? t('खबर संपादित करें (Edit News)', 'Edit News') : t('➕ नई खबर लिखें (Add News)', 'Add News')}</span>
        </button>

        <button
          onClick={() => setActiveTab('videos')}
          className={`px-4 py-3 border-b-2 whitespace-nowrap transition-colors cursor-pointer flex items-center gap-2 ${
            activeTab === 'videos' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-500'
          }`}
        >
          <Video className="w-4 h-4" />
          <span>{t('यूट्यूब वीडियो जोड़ें (Add Video)', 'Add YouTube Video')}</span>
        </button>

        <button
          onClick={() => setActiveTab('broadcast')}
          className={`px-4 py-3 border-b-2 whitespace-nowrap transition-colors cursor-pointer flex items-center gap-2 ${
            activeTab === 'broadcast' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-500'
          }`}
        >
          <Bell className="w-4 h-4" />
          <span>{t('पुश नोटिफिकेशन भेजें (Push Alert)', 'Broadcast Alert')}</span>
        </button>
      </div>

      {/* TAB 1: NEWS LIST (Manage & Edit) */}
      {activeTab === 'news_list' && (
        <div className={`p-5 rounded-3xl border ${
          isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-extrabold text-base">
              {t('लाइव प्रकाशित व ड्राफ्ट खबरें', 'Published Articles & Drafts')}
            </h3>
            <button
              onClick={() => {
                resetNewsForm();
                setActiveTab('add_news');
              }}
              className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>{t('नया आर्टिकल लिखें', 'Write New Article')}</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-gray-200 dark:border-gray-800 text-gray-400">
                  <th className="py-2.5">{t('थंबनेल', 'Thumb')}</th>
                  <th className="py-2.5">{t('हेडलाइन (Headline)', 'Headline')}</th>
                  <th className="py-2.5">{t('कैटेगरी', 'Category')}</th>
                  <th className="py-2.5 text-center">{t('स्थिति', 'Status')}</th>
                  <th className="py-2.5 text-right">{t('कार्रवाई (Actions)', 'Actions')}</th>
                </tr>
              </thead>
              <tbody>
                {newsList.map(item => (
                  <tr key={item.id} className="border-b border-gray-100 dark:border-gray-800/60 hover:bg-gray-50/50 dark:hover:bg-gray-800/40">
                    <td className="py-2.5">
                      <img src={item.imageUrl} alt="" className="w-12 h-10 object-cover rounded-lg" />
                    </td>
                    <td className="py-2.5 max-w-[280px]">
                      <p className="font-bold line-clamp-1">{item.titleHi}</p>
                      <p className="text-[10.5px] text-gray-400 line-clamp-1">{item.titleEn}</p>
                      {item.isBreaking && (
                        <span className="text-[9px] font-black px-1.5 py-0.2 bg-red-100 text-red-700 rounded-sm uppercase">
                          BREAKING
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 font-semibold text-emerald-600">
                      {item.subCategory || item.category.toUpperCase()}
                    </td>
                    <td className="py-2.5 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        item.status === 'published' 
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' 
                          : 'bg-gray-100 text-gray-600 dark:bg-gray-800'
                      }`}>
                        {item.status === 'published' ? t('प्रकाशित (Live)', 'Live') : t('ड्राफ्ट', 'Draft')}
                      </span>
                    </td>
                    <td className="py-2.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleStartEdit(item)}
                          className="p-1.5 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-950 text-amber-600 cursor-pointer"
                          title="Edit"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteNews(item.id, item.titleHi)}
                          className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950 text-red-600 cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: ADD / EDIT NEWS FORM */}
      {activeTab === 'add_news' && (
        <form onSubmit={handleSubmitNews} className={`p-6 rounded-3xl border space-y-5 ${
          isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
        }`}>
          <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800">
            <div>
              <h3 className="font-black text-lg">
                {editingNewsId ? t('आर्टिकल संपादित करें', 'Edit News Article') : t('➕ नई क्रिकेट खबर प्रकाशित करें', 'Publish New Cricket Story')}
              </h3>
              <p className="text-xs text-gray-500">
                {t('हिंदी और अंग्रेजी में शीर्षक, फोटो और विस्तृत विवरण भरें', 'Enter Hindi & English headlines, body copy and photos')}
              </p>
            </div>
            {editingNewsId && (
              <button
                type="button"
                onClick={resetNewsForm}
                className="text-xs text-red-500 hover:underline cursor-pointer font-bold"
              >
                {t('संपादन रद्द करें', 'Cancel Edit')}
              </button>
            )}
          </div>

          {/* Hindi Headline (Crucial Requirement) */}
          <div>
            <label className="text-xs font-black block mb-1 text-emerald-600">
              * {t('खबर की मुख्य हेडलाइन (हिंदी भाषा में)', 'Headline in Hindi (Required)')}
            </label>
            <input
              type="text"
              required
              value={headlineHi}
              onChange={(e) => setHeadlineHi(e.target.value)}
              placeholder="उदा: भारत ने रोमांचक मुकाबले में वेस्टइंडीज को 5 विकेट से हराया"
              className={`w-full px-4 py-2.5 rounded-xl text-sm border font-medium focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
              }`}
            />
          </div>

          {/* English Headline */}
          <div>
            <label className="text-xs font-bold block mb-1">
              {t('खबर की हेडलाइन (अंग्रेजी में)', 'Headline in English')}
            </label>
            <input
              type="text"
              value={headlineEn}
              onChange={(e) => setHeadlineEn(e.target.value)}
              placeholder="e.g. India Defeats West Indies in Thriller by 5 Wickets"
              className={`w-full px-4 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
              }`}
            />
          </div>

          {/* Category & SubCategory */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold block mb-1">
                * {t('कैटेगरी चुनें (Category)', 'Category')}
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className={`w-full px-3 py-2.5 rounded-xl text-xs border font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                  isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                }`}
              >
                <option value="team_india">🇮🇳 Team India (टीम इंडिया)</option>
                <option value="domestic">🏏 Domestic Cricket (घरेलू क्रिकेट - रणजी/हजारे)</option>
                <option value="ipl">🏆 IPL 2026</option>
                <option value="international">🌍 International (अंतरराष्ट्रीय क्रिकेट)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold block mb-1">
                {t('सब-कैटेगरी / टूर्नामेंट (जैसे रणजी ट्रॉफी, T20I, CSK)', 'Sub-category (e.g. Ranji Trophy, CSK)')}
              </label>
              <input
                type="text"
                value={subCategory}
                onChange={(e) => setSubCategory(e.target.value)}
                placeholder="Ranji Trophy / WTC / CSK vs MI"
                className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                  isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                }`}
              />
            </div>
          </div>

          {/* Main Photo URL / Gallery picker */}
          <div>
            <label className="text-xs font-bold block mb-1">
              * {t('मुख्य फोटो URL (Featured Photo)', 'Featured Photo URL')}
            </label>
            <div className="flex gap-2">
              <input
                type="url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://images.unsplash.com/photo-..."
                className={`flex-1 px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                  isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                }`}
              />
            </div>

            {/* Quick Presets */}
            <div className="mt-2 flex items-center gap-2 flex-wrap">
              <span className="text-[11px] text-gray-400">{t('त्वरित फोटो चुनें:', 'Quick presets:')}</span>
              {sampleImages.map((s, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setImageUrl(s.url)}
                  className="px-2 py-0.5 rounded text-[10px] font-semibold border hover:border-amber-500 cursor-pointer text-gray-500"
                >
                  {s.title}
                </button>
              ))}
            </div>

            {imageUrl && (
              <div className="mt-2 w-32 h-20 rounded-xl overflow-hidden border">
                <img src={imageUrl} alt="Preview" className="w-full h-full object-cover" />
              </div>
            )}
          </div>

          {/* Short Summary (Hindi) */}
          <div>
            <label className="text-xs font-bold block mb-1">
              {t('संक्षिप्त सारांश (Short Summary in Hindi)', 'Summary in Hindi')}
            </label>
            <textarea
              rows={2}
              value={summaryHi}
              onChange={(e) => setSummaryHi(e.target.value)}
              placeholder="मैच का मुख्य आकर्षण और परिणाम का 2 पंक्तियों का संक्षिप्त सार..."
              className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
              }`}
            />
          </div>

          {/* Full Content (Hindi) */}
          <div>
            <label className="text-xs font-black block mb-1 text-emerald-600">
              * {t('पूरी खबर का विस्तृत विवरण (Full Content in Hindi)', 'Full Article Body in Hindi')}
            </label>
            <textarea
              rows={6}
              required
              value={contentHi}
              onChange={(e) => setContentHi(e.target.value)}
              placeholder="खबर का विस्तृत विवरण, खिलाड़ियों के स्कोर, ओवर-बाय-ओवर विश्लेषण और कप्तानों के बयान यहाँ लिखें..."
              className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 font-normal leading-relaxed ${
                isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
              }`}
            />
          </div>

          {/* Additional Photos (one per line) */}
          <div>
            <label className="text-xs font-bold block mb-1">
              {t('अतिरिक्त तस्वीरें (Additional Photo URLs - प्रति पंक्ति एक URL)', 'Additional Gallery Photos')}
            </label>
            <textarea
              rows={2}
              value={additionalImagesText}
              onChange={(e) => setAdditionalImagesText(e.target.value)}
              placeholder="https://images.unsplash.com/photo-1...&#10;https://images.unsplash.com/photo-2..."
              className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
              }`}
            />
          </div>

          {/* Flags: Breaking News & Featured */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <label className="flex items-center gap-2 p-3 rounded-xl border cursor-pointer">
              <input
                type="checkbox"
                checked={isBreaking}
                onChange={(e) => setIsBreaking(e.target.checked)}
                className="w-4 h-4 text-red-600 rounded"
              />
              <span className="text-xs font-bold text-red-600 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5" />
                {t('ब्रेकिंग न्यूज़ (Breaking News)', 'Breaking News')}
              </span>
            </label>

            <label className="flex items-center gap-2 p-3 rounded-xl border cursor-pointer">
              <input
                type="checkbox"
                checked={isFeatured}
                onChange={(e) => setIsFeatured(e.target.checked)}
                className="w-4 h-4 text-amber-600 rounded"
              />
              <span className="text-xs font-bold text-amber-600 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                {t('होमपेज फीचर्ड बैनर', 'Homepage Featured')}
              </span>
            </label>

            <div>
              <label className="text-xs font-bold block mb-1">{t('पब्लिश स्थिति', 'Status')}</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className={`w-full px-3 py-2 rounded-xl text-xs border font-bold ${
                  isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                }`}
              >
                <option value="published">🟢 प्रकाशित करें (Publish Live)</option>
                <option value="draft">🟡 ड्राफ्ट में रखें (Save as Draft)</option>
              </select>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-gray-100 dark:border-gray-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={resetNewsForm}
              className="px-5 py-2.5 rounded-xl border text-xs font-bold hover:bg-gray-100 cursor-pointer"
            >
              {t('रीसेट (Reset)', 'Reset')}
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs cursor-pointer shadow-md flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>{isSubmitting ? t('प्रक्रिया जारी है...', 'Saving...') : editingNewsId ? t('अपडेट करें (Save Updates)', 'Save Updates') : t('अभी प्रकाशित करें (Publish Now)', 'Publish Now')}</span>
            </button>
          </div>
        </form>
      )}

      {/* TAB 3: ADD YOUTUBE VIDEO */}
      {activeTab === 'videos' && (
        <form onSubmit={handleAddVideoSubmit} className={`p-6 rounded-3xl border space-y-4 max-w-2xl ${
          isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
        }`}>
          <div>
            <h3 className="font-black text-lg">
              {t('यूट्यूब क्रिकेट वीडियो जोड़ें', 'Embed YouTube Cricket Video')}
            </h3>
            <p className="text-xs text-gray-500">
              {t('मैच हाइलाइट्स या प्रेस कॉन्फ्रेंस का YouTube ID जोड़ें', 'Add YouTube highlights, analysis or interviews')}
            </p>
          </div>

          <div>
            <label className="text-xs font-bold block mb-1">
              * {t('वीडियो का शीर्षक (हिंदी)', 'Video Title (Hindi)')}
            </label>
            <input
              type="text"
              required
              value={videoTitleHi}
              onChange={(e) => setVideoTitleHi(e.target.value)}
              placeholder="उदा: IND vs AUS: हार्दिक पांड्या और सूर्यकुमार के खास शॉट्स"
              className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
              }`}
            />
          </div>

          <div>
            <label className="text-xs font-bold block mb-1">
              * {t('YouTube Video ID (जैसे: dQw4w9WgXcQ)', 'YouTube Video ID')}
            </label>
            <input
              type="text"
              required
              value={youtubeId}
              onChange={(e) => setYoutubeId(e.target.value)}
              placeholder="kJQP7kiw5Fk"
              className={`w-full px-3 py-2 rounded-xl text-xs border font-mono focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
              }`}
            />
            <p className="text-[10px] text-gray-400 mt-1">
              यूट्यूब लिंक https://youtube.com/watch?v=<b>kJQP7kiw5Fk</b> से केवल बोल्ड किया गया भाग दर्ज करें।
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold block mb-1">अवधि (Duration)</label>
              <input
                type="text"
                value={videoDuration}
                onChange={(e) => setVideoDuration(e.target.value)}
                placeholder="09:15"
                className={`w-full px-3 py-2 rounded-xl text-xs border ${
                  isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                }`}
              />
            </div>
            <div>
              <label className="text-xs font-bold block mb-1">श्रेणी (Category)</label>
              <input
                type="text"
                value={videoCategory}
                onChange={(e) => setVideoCategory(e.target.value)}
                placeholder="Match Highlights"
                className={`w-full px-3 py-2 rounded-xl text-xs border ${
                  isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                }`}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs cursor-pointer shadow-md"
          >
            {t('वीडियो जोड़ें (Add Video)', 'Add Video')}
          </button>
        </form>
      )}

      {/* TAB 4: BROADCAST PUSH NOTIFICATION */}
      {activeTab === 'broadcast' && (
        <form onSubmit={handleBroadcastNotifSubmit} className={`p-6 rounded-3xl border space-y-4 max-w-2xl ${
          isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
        }`}>
          <div>
            <h3 className="font-black text-lg">
              {t('पुश नोटिफिकेशन ब्रॉडकास्ट करें', 'Broadcast Push Alert')}
            </h3>
            <p className="text-xs text-gray-500">
              {t('सभी ऐप उपयोगकर्ताओं को ब्रेकिंग न्यूज़ या मैच का तात्कालिक अलर्ट भेजें', 'Send instant breaking alerts to all users')}
            </p>
          </div>

          <div>
            <label className="text-xs font-bold block mb-1">
              * {t('अलर्ट शीर्षक (Notification Title)', 'Notification Title')}
            </label>
            <input
              type="text"
              required
              value={notifTitle}
              onChange={(e) => setNotifTitle(e.target.value)}
              placeholder="🚨 ब्रेकिंग: भारत ने ऑस्ट्रेलिया के खिलाफ जीता तीसरा T20"
              className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
              }`}
            />
          </div>

          <div>
            <label className="text-xs font-bold block mb-1">
              * {t('अलर्ट संदेश (Message Body)', 'Notification Body')}
            </label>
            <textarea
              rows={3}
              required
              value={notifBody}
              onChange={(e) => setNotifBody(e.target.value)}
              placeholder="सूर्यकुमार यादव की तूफानी फिफ्टी की बदौलत भारत ने सीरीज पर 2-1 से कब्जा किया।"
              className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
              }`}
            />
          </div>

          <div>
            <label className="text-xs font-bold block mb-1">अलर्ट का प्रकार</label>
            <select
              value={notifType}
              onChange={(e) => setNotifType(e.target.value as any)}
              className={`w-full px-3 py-2 rounded-xl text-xs border font-bold ${
                isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
              }`}
            >
              <option value="breaking">🔴 ब्रेकिंग न्यूज़ (Breaking)</option>
              <option value="match">🏏 लाइव मैच स्कोर (Match Alert)</option>
              <option value="system">📢 सामान्य घोषणा (Announcement)</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs cursor-pointer shadow-md flex items-center gap-2"
          >
            <Bell className="w-4 h-4" />
            <span>{t('ब्रॉडकास्ट भेजें (Send Broadcast)', 'Send Broadcast')}</span>
          </button>
        </form>
      )}
    </div>
  );
};
