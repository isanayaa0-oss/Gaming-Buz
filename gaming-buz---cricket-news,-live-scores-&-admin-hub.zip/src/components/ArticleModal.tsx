import React, { useState } from 'react';
import { 
  X, 
  Share2, 
  Bookmark, 
  ThumbsUp, 
  Clock, 
  Eye, 
  MessageSquare, 
  ZoomIn, 
  ZoomOut, 
  Check, 
  Copy, 
  Send,
  Sparkles,
  Volume2
} from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { useAuth } from '../context/AuthContext';
import { NewsItem } from '../types';

interface ArticleModalProps {
  news: NewsItem | null;
  onClose: () => void;
  isBookmarked: boolean;
  onToggleBookmark: (id: string, e: React.MouseEvent) => void;
  onSelectRelated: (news: NewsItem) => void;
  allNews: NewsItem[];
}

export const ArticleModal: React.FC<ArticleModalProps> = ({
  news,
  onClose,
  isBookmarked,
  onToggleBookmark,
  onSelectRelated,
  allNews
}) => {
  const { isDarkMode, t, language } = useThemeLanguage();
  const { user, openAuthModal } = useAuth();
  const [fontSizeOffset, setFontSizeOffset] = useState<number>(0);
  const [likes, setLikes] = useState<number>(news?.likes || 0);
  const [hasLiked, setHasLiked] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [commentInput, setCommentInput] = useState<string>('');
  const [comments, setComments] = useState<{ id: string; user: string; text: string; time: string }[]>([
    { id: 'c1', user: 'सुरेश रैना फैन', text: 'बहुत ही सटीक और शानदार विश्लेषण! टीम इंडिया को युवाओं को मौका देना ही चाहिए।', time: '10 मिनट पहले' },
    { id: 'c2', user: 'क्रिकेट लवर 2026', text: 'रणजी ट्रॉफी के प्रदर्शन को महत्व देना बीसीसीआई का सर्वश्रेष्ठ फैसला है।', time: '25 मिनट पहले' }
  ]);

  if (!news) return null;

  const handleLike = () => {
    if (!hasLiked) {
      setLikes(prev => prev + 1);
      setHasLiked(true);
    } else {
      setLikes(prev => prev - 1);
      setHasLiked(false);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareWhatsapp = () => {
    const text = encodeURIComponent(`*${t(news.titleHi, news.titleEn)}*\n\nGAMING BUZ पर पूरी खबर पढ़ें:\n${window.location.href}`);
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim()) return;
    if (!user) {
      openAuthModal('user');
      return;
    }
    const newComment = {
      id: 'c-' + Date.now(),
      user: user.name,
      text: commentInput.trim(),
      time: 'अभी-अभी'
    };
    setComments([newComment, ...comments]);
    setCommentInput('');
  };

  // Related articles (same category or general)
  const related = allNews
    .filter(n => n.id !== news.id && (n.category === news.category || n.isFeatured))
    .slice(0, 3);

  const getFontSizeClass = () => {
    if (fontSizeOffset === -1) return 'text-sm leading-relaxed';
    if (fontSizeOffset === 1) return 'text-lg leading-loose';
    if (fontSizeOffset === 2) return 'text-xl leading-loose';
    return 'text-base leading-relaxed';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div 
        className={`w-full max-w-3xl max-h-[92vh] flex flex-col rounded-3xl overflow-hidden shadow-2xl transition-colors border ${
          isDarkMode ? 'bg-gray-900 border-gray-800 text-gray-100' : 'bg-white border-gray-200 text-gray-900'
        }`}
      >
        {/* Sticky Modal Bar */}
        <div className={`p-4 border-b flex items-center justify-between sticky top-0 z-20 backdrop-blur-md ${
          isDarkMode ? 'bg-gray-900/90 border-gray-800' : 'bg-white/90 border-gray-100'
        }`}>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
              {news.subCategory || news.category.toUpperCase()}
            </span>
            {news.isBreaking && (
              <span className="text-xs font-black px-2.5 py-1 rounded-full bg-red-600 text-white animate-pulse">
                BREAKING
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Font resize buttons */}
            <div className="flex items-center border rounded-lg overflow-hidden text-xs">
              <button
                onClick={() => setFontSizeOffset(prev => Math.max(-1, prev - 1))}
                className="px-2 py-1 hover:bg-gray-100 dark:hover:bg-gray-800 border-r cursor-pointer"
                title="Decrease font size"
              >
                A-
              </button>
              <button
                onClick={() => setFontSizeOffset(prev => Math.min(2, prev + 1))}
                className="px-2 py-1 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer font-bold"
                title="Increase font size"
              >
                A+
              </button>
            </div>

            {/* Bookmark */}
            <button
              onClick={(e) => onToggleBookmark(news.id, e)}
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                isBookmarked 
                  ? 'bg-emerald-50 text-emerald-600 border-emerald-300 dark:bg-emerald-950/50' 
                  : 'hover:bg-gray-100 dark:hover:bg-gray-800 border-gray-200 dark:border-gray-700'
              }`}
              title="Bookmark article"
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-emerald-600' : ''}`} />
            </button>

            {/* Close button */}
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer border border-transparent hover:border-gray-200"
              aria-label="Close article"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Article Body */}
        <div className="overflow-y-auto p-4 sm:p-8 flex-1">
          {/* Article Title */}
          <h1 className="text-2xl sm:text-3xl font-extrabold leading-tight text-balance">
            {t(news.titleHi, news.titleEn)}
          </h1>

          {/* Metadata bar */}
          <div className="mt-4 pb-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between flex-wrap gap-2 text-xs text-gray-500 dark:text-gray-400">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-emerald-600 dark:text-emerald-400">{news.author}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                <span>{new Date(news.publishedAt).toLocaleDateString('hi-IN', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
              </span>
            </div>

            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1">
                <Eye className="w-3.5 h-3.5" />
                <span>{news.views.toLocaleString()} {t('व्यूज', 'views')}</span>
              </span>
            </div>
          </div>

          {/* Main Featured Photo */}
          <div className="my-5 rounded-2xl overflow-hidden shadow-md bg-gray-100 dark:bg-gray-800">
            <img
              src={news.imageUrl}
              alt={t(news.titleHi, news.titleEn)}
              className="w-full max-h-[420px] object-cover"
            />
            <p className="p-2.5 text-xs text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-900/60 italic border-t border-gray-100 dark:border-gray-800">
              📸 {t('फोटो: GAMING BUZ विशेष कवरेज / मैच मोमेंट्स', 'Photo: GAMING BUZ Special Coverage')}
            </p>
          </div>

          {/* Summary Callout */}
          <div className={`p-4 rounded-xl border-l-4 border-emerald-500 mb-6 font-medium text-sm sm:text-base leading-relaxed ${
            isDarkMode ? 'bg-gray-800/60 text-emerald-300' : 'bg-emerald-50/80 text-emerald-950'
          }`}>
            {t(news.summaryHi, news.summaryEn)}
          </div>

          {/* Full Article Content */}
          <div className={`space-y-4 whitespace-pre-line ${getFontSizeClass()} ${
            isDarkMode ? 'text-gray-200' : 'text-gray-800'
          }`}>
            {t(news.contentHi, news.contentEn)}
          </div>

          {/* Additional Photos Section if provided */}
          {news.additionalImages && news.additionalImages.length > 0 && (
            <div className="my-8">
              <h4 className="text-sm font-bold uppercase tracking-wider mb-3 text-gray-500">
                {t('मैच से जुड़ी अतिरिक्त तस्वीरें (Photo Gallery)', 'Additional Photos')}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {news.additionalImages.map((img, idx) => (
                  <div key={idx} className="rounded-xl overflow-hidden shadow-xs border border-gray-200 dark:border-gray-800">
                    <img src={img} alt={`Gallery ${idx + 1}`} className="w-full h-48 object-cover hover:scale-105 transition-transform" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Social Share & Like Bar */}
          <div className={`my-6 p-4 rounded-2xl border flex items-center justify-between flex-wrap gap-3 ${
            isDarkMode ? 'bg-gray-800/50 border-gray-700' : 'bg-gray-50 border-gray-200'
          }`}>
            <div className="flex items-center gap-2">
              <button
                onClick={handleLike}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  hasLiked 
                    ? 'bg-emerald-600 text-white' 
                    : 'bg-white dark:bg-gray-800 border text-gray-700 dark:text-gray-300 hover:border-emerald-500'
                }`}
              >
                <ThumbsUp className={`w-4 h-4 ${hasLiked ? 'fill-white' : ''}`} />
                <span>{likes} {t('पसंद (Likes)', 'Likes')}</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleShareWhatsapp}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-green-600 hover:bg-green-700 text-white transition-colors cursor-pointer"
              >
                <span>WhatsApp</span>
              </button>
              <button
                onClick={handleCopyLink}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? t('कॉपी हुआ!', 'Copied!') : t('लिंक कॉपी करें', 'Copy Link')}</span>
              </button>
            </div>
          </div>

          {/* Comments Section */}
          <div className="my-8 pt-6 border-t border-gray-200 dark:border-gray-800">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-extrabold text-lg flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-emerald-500" />
                <span>{t('प्रतिक्रिया व कमेंट्स', 'Discussion & Comments')} ({comments.length})</span>
              </h3>
            </div>

            {/* Comment Box */}
            <form onSubmit={handleAddComment} className="flex gap-2 mb-6">
              <input
                type="text"
                value={commentInput}
                onChange={(e) => setCommentInput(e.target.value)}
                placeholder={user ? t('अपनी राय यहाँ लिखें...', 'Write your comment...') : t('कमेंट करने के लिए लॉगिन करें...', 'Login to write comment...')}
                className={`flex-1 px-4 py-2.5 rounded-xl text-sm border focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                  isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                }`}
              />
              <button
                type="submit"
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline">{t('भेजें', 'Post')}</span>
              </button>
            </form>

            {/* Comment List */}
            <div className="space-y-3">
              {comments.map((comment) => (
                <div 
                  key={comment.id}
                  className={`p-3 rounded-xl border text-sm ${
                    isDarkMode ? 'bg-gray-800/40 border-gray-800' : 'bg-gray-50 border-gray-100'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-bold text-emerald-600 mb-1">
                    <span>{comment.user}</span>
                    <span className="text-gray-400 font-normal">{comment.time}</span>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300">{comment.text}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Related Stories */}
          {related.length > 0 && (
            <div className="my-8 pt-6 border-t border-gray-200 dark:border-gray-800">
              <h3 className="font-extrabold text-lg mb-4">
                {t('संबंधित अन्य खबरें (Related News)', 'Related News')}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {related.map(item => (
                  <div
                    key={item.id}
                    onClick={() => onSelectRelated(item)}
                    className={`p-2.5 rounded-xl border cursor-pointer hover:border-emerald-500 transition-all ${
                      isDarkMode ? 'bg-gray-800/40 border-gray-800' : 'bg-gray-50 border-gray-200'
                    }`}
                  >
                    <img src={item.imageUrl} alt="" className="w-full h-24 object-cover rounded-lg mb-2" />
                    <p className="text-xs font-bold line-clamp-2">{t(item.titleHi, item.titleEn)}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
