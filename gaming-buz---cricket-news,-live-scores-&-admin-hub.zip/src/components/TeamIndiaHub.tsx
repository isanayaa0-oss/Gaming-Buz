import React, { useState } from 'react';
import { Shield, Calendar, Trophy, Users, CheckCircle2, ChevronRight } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { NewsItem, CricketMatch } from '../types';
import { NewsCard } from './NewsCard';

interface TeamIndiaHubProps {
  newsList: NewsItem[];
  matchesList: CricketMatch[];
  onSelectNews: (news: NewsItem) => void;
  bookmarks: string[];
  onToggleBookmark: (id: string, e: React.MouseEvent) => void;
  onShare: (news: NewsItem, e: React.MouseEvent) => void;
}

export const TeamIndiaHub: React.FC<TeamIndiaHubProps> = ({
  newsList,
  matchesList,
  onSelectNews,
  bookmarks,
  onToggleBookmark,
  onShare
}) => {
  const { isDarkMode, t } = useThemeLanguage();
  const [teamType, setTeamType] = useState<'men' | 'women'>('men');
  const [formatFilter, setFormatFilter] = useState<'all' | 't20' | 'odi' | 'test'>('all');

  const indiaNews = newsList.filter(n => n.category === 'team_india');

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className={`p-6 sm:p-8 rounded-3xl border relative overflow-hidden ${
        isDarkMode 
          ? 'bg-gradient-to-r from-blue-950/90 via-slate-900 to-indigo-950/80 border-blue-900/50' 
          : 'bg-gradient-to-r from-blue-700 via-indigo-600 to-blue-900 text-white shadow-lg'
      }`}>
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-2xl">🇮🇳</span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-white/20 backdrop-blur-md">
              <Shield className="w-3.5 h-3.5" />
              {t('भारतीय क्रिकेट टीम (Men in Blue & Women in Blue)', 'Team India Official Hub')}
            </span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-black leading-tight">
            {t('टीम इंडिया: आगामी सीरीज, प्लेइंग 11 और नतीजे', 'Team India: Fixtures, Playing 11 & Insights')}
          </h2>

          <div className="mt-4 flex items-center gap-2">
            <button
              onClick={() => setTeamType('men')}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                teamType === 'men' ? 'bg-white text-blue-900 shadow-md font-black' : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              🇮🇳 {t('पुरुष क्रिकेट टीम (Men)', "Men's Team")}
            </button>
            <button
              onClick={() => setTeamType('women')}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                teamType === 'women' ? 'bg-white text-blue-900 shadow-md font-black' : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              🇮🇳 {t('महिला क्रिकेट टीम (Women)', "Women's Team")}
            </button>
          </div>
        </div>
      </div>

      {/* Fixtures & Squad Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Upcoming Fixtures */}
        <div className={`p-5 rounded-3xl border ${
          isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
        }`}>
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-5 h-5 text-blue-500" />
            <h3 className="font-black text-base">{t('आगामी मैच शेड्यूल', 'Upcoming Fixtures')}</h3>
          </div>

          <div className="space-y-3">
            <div className={`p-3.5 rounded-2xl border ${
              isDarkMode ? 'bg-gray-800/40 border-gray-800' : 'bg-blue-50/50 border-blue-100'
            }`}>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-bold text-blue-600">IND vs ENG (1st ODI)</span>
                <span className="text-[11px] text-gray-400">कल दोपहर 1:30 PM</span>
              </div>
              <p className="text-xs text-gray-500">लॉर्ड्स, लंदन • लाइव ऑन स्टार स्पोर्ट्स / हॉटस्टार</p>
            </div>

            <div className={`p-3.5 rounded-2xl border ${
              isDarkMode ? 'bg-gray-800/40 border-gray-800' : 'bg-slate-50 border-gray-100'
            }`}>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-bold text-gray-800 dark:text-gray-200">IND vs ENG (2nd ODI)</span>
                <span className="text-[11px] text-gray-400">18 अक्टूबर, 1:30 PM</span>
              </div>
              <p className="text-xs text-gray-500">एजबेस्टन, बर्मिंघम</p>
            </div>
          </div>
        </div>

        {/* Probable Playing XI / Squad Status */}
        <div className={`p-5 rounded-3xl border ${
          isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
        }`}>
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-emerald-500" />
            <h3 className="font-black text-base">{t('संभावित प्लेइंग 11 (Probable XI)', 'Probable Playing XI')}</h3>
          </div>

          <div className="text-xs space-y-2">
            <div className="flex items-center justify-between p-2 rounded-lg bg-gray-50 dark:bg-gray-800/50">
              <span className="font-bold">1. रोहित शर्मा (कप्तान)</span>
              <span className="text-gray-400">सलामी बल्लेबाज</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-gray-50 dark:bg-gray-800/50">
              <span className="font-bold">2. शुभमन गिल (उपकप्तान)</span>
              <span className="text-gray-400">सलामी बल्लेबाज</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-gray-50 dark:bg-gray-800/50">
              <span className="font-bold">3. विराट कोहली</span>
              <span className="text-gray-400">शीर्ष क्रम</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-gray-50 dark:bg-gray-800/50">
              <span className="font-bold">4. श्रेयस अय्यर / केएल राहुल</span>
              <span className="text-gray-400">मध्यक्रम</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-gray-50 dark:bg-gray-800/50">
              <span className="font-bold">5. हार्दिक पांड्या</span>
              <span className="text-emerald-600 font-semibold">ऑलराउंडर</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-gray-50 dark:bg-gray-800/50">
              <span className="font-bold">6. जसप्रीत बुमराह / अर्शदीप सिंह</span>
              <span className="text-blue-600 font-semibold">तेज गेंदबाज</span>
            </div>
          </div>
        </div>
      </div>

      {/* Team India News Articles */}
      <div>
        <h3 className="text-xl font-extrabold mb-4 flex items-center gap-2">
          <span>🇮🇳</span>
          <span>{t('टीम इंडिया की ताजा खबरें और रिपोर्ट्स', 'Team India News & Selection Updates')}</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {indiaNews.map(item => (
            <NewsCard
              key={item.id}
              news={item}
              onSelect={onSelectNews}
              isBookmarked={bookmarks.includes(item.id)}
              onToggleBookmark={onToggleBookmark}
              onShare={onShare}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
