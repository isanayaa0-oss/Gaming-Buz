import React from 'react';
import { Radio, RefreshCw, ChevronRight, Activity } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { CricketMatch } from '../types';

interface LiveScoreTickerProps {
  matches: CricketMatch[];
  onSelectMatch: (match: CricketMatch) => void;
  onRefresh: () => void;
  isRefreshing: boolean;
}

export const LiveScoreTicker: React.FC<LiveScoreTickerProps> = ({
  matches,
  onSelectMatch,
  onRefresh,
  isRefreshing
}) => {
  const { isDarkMode, t } = useThemeLanguage();

  return (
    <div className={`border-b transition-colors ${
      isDarkMode ? 'bg-gray-950/80 border-gray-800' : 'bg-slate-50 border-gray-200'
    }`}>
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-600"></span>
            </span>
            <span className="text-xs font-black uppercase tracking-wider text-red-600 flex items-center gap-1">
              <Radio className="w-3.5 h-3.5" />
              {t('लाइव मैच सेंटर', 'LIVE MATCH CENTER')}
            </span>
            <span className="text-xs text-gray-400">•</span>
            <span className="text-xs font-medium text-gray-500">
              {t('रीयल-टाइम स्कोरकार्ड', 'Real-time Scorecards')}
            </span>
          </div>

          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className={`flex items-center gap-1 text-[11px] font-semibold px-2 py-1 rounded transition-colors cursor-pointer ${
              isDarkMode 
                ? 'text-gray-400 hover:text-white hover:bg-gray-800' 
                : 'text-gray-500 hover:text-gray-900 hover:bg-gray-200'
            }`}
            title="Refresh match scores"
          >
            <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin text-emerald-500' : ''}`} />
            <span>{t('अपडेट करें', 'Refresh')}</span>
          </button>
        </div>

        {/* Horizontal Match Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {matches.map((match) => {
            const isLive = match.status === 'live';
            return (
              <div
                key={match.id}
                onClick={() => onSelectMatch(match)}
                className={`p-3 rounded-xl border transition-all duration-200 cursor-pointer hover:shadow-md relative overflow-hidden group ${
                  isDarkMode
                    ? 'bg-gray-900 border-gray-800 hover:border-emerald-500/50'
                    : 'bg-white border-gray-200 hover:border-emerald-500/50 shadow-xs'
                }`}
              >
                {/* Header: Series & Status */}
                <div className="flex items-center justify-between text-[11px] text-gray-500 mb-2">
                  <span className="font-semibold truncate max-w-[170px]" title={match.series}>
                    {match.series}
                  </span>
                  {isLive ? (
                    <span className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-red-100 text-red-700 font-bold text-[10px]">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
                      LIVE
                    </span>
                  ) : match.status === 'completed' ? (
                    <span className="px-1.5 py-0.5 rounded bg-gray-100 text-gray-700 text-[10px] font-semibold">
                      {t('समाप्त', 'RESULT')}
                    </span>
                  ) : (
                    <span className="px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 text-[10px] font-semibold">
                      {t('आगामी', 'UPCOMING')}
                    </span>
                  )}
                </div>

                {/* Team 1 Score */}
                <div className="flex items-center justify-between my-1">
                  <div className="flex items-center gap-2">
                    <span className="text-base">{match.team1.flag}</span>
                    <span className="text-xs font-bold">
                      {t(match.team1.nameHi, match.team1.nameEn)}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-extrabold tracking-tight">
                      {match.team1.score || '-'}
                    </span>
                    {match.team1.overs && (
                      <span className="text-[10px] text-gray-400 ml-1">
                        ({match.team1.overs} ov)
                      </span>
                    )}
                  </div>
                </div>

                {/* Team 2 Score */}
                <div className="flex items-center justify-between my-1">
                  <div className="flex items-center gap-2">
                    <span className="text-base">{match.team2.flag}</span>
                    <span className="text-xs font-bold">
                      {t(match.team2.nameHi, match.team2.nameEn)}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-extrabold tracking-tight">
                      {match.team2.score || '-'}
                    </span>
                    {match.team2.overs && (
                      <span className="text-[10px] text-gray-400 ml-1">
                        ({match.team2.overs} ov)
                      </span>
                    )}
                  </div>
                </div>

                {/* Live Match State summary */}
                <div className="mt-2.5 pt-2 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between text-[11px]">
                  <span className={`font-semibold truncate max-w-[200px] ${
                    isLive ? 'text-emerald-600 dark:text-emerald-400' : 'text-gray-500'
                  }`}>
                    {t(match.statusTextHi, match.statusTextEn)}
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 text-gray-400 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
