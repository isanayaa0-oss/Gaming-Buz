import React from 'react';
import { Wifi, Battery, Signal, Smartphone } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';

export const AndroidDeviceFrame: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { deviceModel, isDarkMode } = useThemeLanguage();

  if (deviceModel === 'responsive') {
    return <div className="min-h-screen">{children}</div>;
  }

  // Device specs
  const getDeviceSpecs = () => {
    switch (deviceModel) {
      case 'oneplus':
        return {
          title: 'OnePlus 7 / 11 (OxygenOS 14/15)',
          width: 'max-w-[412px]',
          height: 'min-h-[892px]',
          notch: 'camera-punch-left',
          density: '412 x 892 dp (XXHDPI)',
          os: 'OxygenOS'
        };
      case 'samsung':
        return {
          title: 'Samsung Galaxy S24 (One UI 6.1)',
          width: 'max-w-[393px]',
          height: 'min-h-[852px]',
          notch: 'camera-punch-center',
          density: '393 x 852 dp (XXXHDPI)',
          os: 'One UI'
        };
      case 'pixel':
        return {
          title: 'Google Pixel 8 (Stock Android 15)',
          width: 'max-w-[412px]',
          height: 'min-h-[915px]',
          notch: 'camera-punch-center',
          density: '412 x 915 dp (XXHDPI)',
          os: 'Pixel UI'
        };
      case 'redmi':
        return {
          title: 'Xiaomi Redmi Note 13 (HyperOS / MIUI)',
          width: 'max-w-[393px]',
          height: 'min-h-[873px]',
          notch: 'camera-punch-center',
          density: '393 x 873 dp (XHDPI)',
          os: 'HyperOS'
        };
      case 'tablet':
        return {
          title: 'Samsung Galaxy Tab / Lenovo 10" Tablet',
          width: 'max-w-[960px]',
          height: 'min-h-[700px]',
          notch: 'none',
          density: '960 x 600 dp (MDPI)',
          os: 'Android Tablet'
        };
      default:
        return {
          title: 'Responsive Android Device',
          width: 'max-w-[420px]',
          height: 'min-h-[880px]',
          notch: 'camera-punch-center',
          density: '420 x 880 dp',
          os: 'Android'
        };
    }
  };

  const specs = getDeviceSpecs();

  return (
    <div className="py-6 px-2 sm:px-4 bg-slate-900/90 min-h-screen flex flex-col items-center justify-start">
      {/* Device Info Badge */}
      <div className="mb-4 text-center">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-gray-800 text-emerald-400 border border-gray-700 shadow-md">
          <Smartphone className="w-3.5 h-3.5" />
          <span>{specs.title} • {specs.density}</span>
        </span>
      </div>

      {/* Hardware Shell Frame */}
      <div className={`w-full ${specs.width} rounded-[42px] p-3 shadow-2xl bg-black border-4 border-gray-700 ring-4 ring-gray-900/60 relative flex flex-col`}>
        {/* Notch / Camera Hole */}
        {specs.notch === 'camera-punch-center' && (
          <div className="absolute top-5 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-neutral-900 border-2 border-neutral-800 z-50"></div>
        )}
        {specs.notch === 'camera-punch-left' && (
          <div className="absolute top-5 left-7 w-4 h-4 rounded-full bg-neutral-900 border-2 border-neutral-800 z-50"></div>
        )}

        {/* Screen Bezel Area */}
        <div className={`w-full rounded-[34px] overflow-hidden flex flex-col relative border ${
          isDarkMode ? 'bg-gray-950 border-gray-900' : 'bg-white border-gray-100'
        }`}>
          {/* Android Status Bar */}
          <div className={`px-6 py-2 text-[11px] font-semibold flex items-center justify-between z-40 select-none ${
            isDarkMode ? 'text-gray-200 bg-gray-900/80' : 'text-gray-800 bg-white/80'
          }`}>
            <span className="font-mono">18:45</span>
            <div className="flex items-center gap-2">
              <Signal className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Actual Scrollable App Canvas */}
          <div className="overflow-y-auto max-h-[82vh] no-scrollbar">
            {children}
          </div>

          {/* Android 3-Button Navigation Bar / Gesture Bar */}
          <div className={`py-2 px-8 flex items-center justify-center border-t select-none ${
            isDarkMode ? 'bg-gray-950 border-gray-900' : 'bg-white border-gray-100'
          }`}>
            <div className="w-32 h-1 bg-gray-400 rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
