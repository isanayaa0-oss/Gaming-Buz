import React from 'react';
import { 
  Home, 
  Radio, 
  Trophy, 
  Globe, 
  Video, 
  LayoutDashboard,
  ShieldAlert
} from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { useAuth } from '../context/AuthContext';
import { Category } from '../types';

interface CategoryNavProps {
  activeCategory: Category;
  onSelectCategory: (cat: Category) => void;
  showAdminTab: boolean;
  onSelectAdmin: () => void;
  isAdminActive: boolean;
}

export const CategoryNav: React.FC<CategoryNavProps> = ({
  activeCategory,
  onSelectCategory,
  showAdminTab,
  onSelectAdmin,
  isAdminActive
}) => {
  const { isDarkMode, t } = useThemeLanguage();
  const { isAdmin } = useAuth();

  const categories = [
    {
      id: 'all' as Category,
      labelHi: '🏠 होम',
      labelEn: 'Home',
      icon: <Home className="w-4 h-4" />
    },
    {
      id: 'live_matches' as Category,
      labelHi: '🔴 लाइव मैच',
      labelEn: 'Live Scores',
      badge: 'LIVE',
      icon: <Radio className="w-4 h-4 text-red-500 animate-pulse" />
    },
    {
      id: 'team_india' as Category,
      labelHi: '🇮🇳 टीम इंडिया',
      labelEn: 'Team India',
      icon: <span className="text-sm">🇮🇳</span>
    },
    {
      id: 'ipl' as Category,
      labelHi: '🏆 IPL 2026',
      labelEn: 'IPL 2026',
      icon: <Trophy className="w-4 h-4 text-amber-500" />
    },
    {
      id: 'domestic' as Category,
      labelHi: '🏏 घरेलू क्रिकेट (Domestic)',
      labelEn: 'Domestic Cricket',
      badge: 'रणजी/हजारे',
      icon: <span className="text-sm">🏏</span>
    },
    {
      id: 'international' as Category,
      labelHi: '🌍 इंटरनेशनल',
      labelEn: 'International',
      icon: <Globe className="w-4 h-4 text-blue-500" />
    },
    {
      id: 'videos' as Category,
      labelHi: '🎥 वीडियो',
      labelEn: 'Videos',
      icon: <Video className="w-4 h-4 text-purple-500" />
    }
  ];

  return (
    <nav className={`border-b sticky top-[95px] z-30 transition-colors ${
      isDarkMode ? 'bg-gray-900/95 border-gray-800 backdrop-blur-md' : 'bg-white/95 border-gray-200 backdrop-blur-md'
    }`}>
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center space-x-1 sm:space-x-2 overflow-x-auto py-2.5 no-scrollbar scroll-smooth">
          {categories.map((cat) => {
            const isActive = !isAdminActive && activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-150 cursor-pointer ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/25 ring-2 ring-emerald-600/30 font-bold scale-[1.02]'
                    : isDarkMode
                      ? 'text-gray-300 hover:bg-gray-800 hover:text-white'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                {cat.icon}
                <span>{t(cat.labelHi, cat.labelEn)}</span>
                {cat.badge && (
                  <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-full ml-0.5 ${
                    isActive 
                      ? 'bg-white/20 text-white' 
                      : 'bg-red-100 text-red-700 dark:bg-red-950/60 dark:text-red-300'
                  }`}>
                    {cat.badge}
                  </span>
                )}
              </button>
            );
          })}

          {/* Admin Dashboard Tab (Option C) */}
          <button
            onClick={onSelectAdmin}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-150 cursor-pointer border ${
              isAdminActive
                ? 'bg-amber-600 border-amber-500 text-white shadow-md shadow-amber-600/25 scale-[1.02]'
                : isAdmin
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-600 dark:text-amber-400 hover:bg-amber-500/20'
                  : 'bg-gray-50 dark:bg-gray-800/80 border-dashed border-gray-300 dark:border-gray-700 text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
            }`}
            title="Professional News Publishing Dashboard"
          >
            <LayoutDashboard className="w-4 h-4 text-amber-500" />
            <span>{t('🖥️ एडमिन डैशबोर्ड', 'Admin Dashboard')}</span>
            {isAdmin ? (
              <span className="text-[10px] px-1 py-0.2 bg-amber-500 text-white rounded font-mono font-bold">
                PRO
              </span>
            ) : (
              <span className="text-[10px] text-gray-400 font-normal">
                (Login)
              </span>
            )}
          </button>
        </div>
      </div>
    </nav>
  );
};
