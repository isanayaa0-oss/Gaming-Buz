import React from 'react';
import { Flame, Clock, Share2, Bookmark, ChevronRight } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { NewsItem } from '../types';

interface FeaturedHeroProps {
  news: NewsItem;
  onSelect: (news: NewsItem) => void;
  isBookmarked: boolean;
  onToggleBookmark: (id: string, e: React.MouseEvent) => void;
  onShare: (news: NewsItem, e: React.MouseEvent) => void;
}

export const FeaturedHero: React.FC<FeaturedHeroProps> = ({
  news,
  onSelect,
  isBookmarked,
  onToggleBookmark,
  onShare
}) => {
  const { isDarkMode, t } = useThemeLanguage();

  return (
    <div
      onClick={() => onSelect(news)}
      className="relative rounded-3xl overflow-hidden cursor-pointer group shadow-xl mb-6 transition-all duration-300 hover:shadow-2xl"
    >
      {/* Background Banner with Gradient */}
      <div className="relative aspect-16/9 sm:aspect-21/9 w-full min-h-[300px] sm:min-h-[380px] bg-gray-900">
        <img
          src={news.imageUrl}
          alt={t(news.titleHi, news.titleEn)}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-80"
        />
        {/* Deep dark gradient overlay for effortless readability */}
        <div className="absolute inset-0 bg-linear-to-t from-black via-black/60 to-black/20"></div>

        {/* Top Badges */}
        <div className="absolute top-4 left-4 sm:top-6 sm:left-6 flex items-center gap-2 flex-wrap">
          <span className="bg-red-600 text-white text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1.5 shadow-lg animate-pulse">
            <Flame className="w-3.5 h-3.5" />
            {t('🔴 मुख्य समाचार (Featured)', 'FEATURED HEADLINE')}
          </span>
          <span className="bg-white/20 backdrop-blur-md text-white text-xs font-bold px-3 py-1 rounded-full border border-white/20">
            {news.subCategory || t('टीम इंडिया', 'Team India')}
          </span>
        </div>

        {/* Bottom Content */}
        <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-8">
          <div className="max-w-4xl">
            <h2 className="text-xl sm:text-3xl md:text-4xl font-extrabold text-white leading-tight sm:leading-snug drop-shadow-md">
              {t(news.titleHi, news.titleEn)}
            </h2>

            <p className="mt-2 sm:mt-3 text-xs sm:text-base text-gray-200 line-clamp-2 max-w-3xl leading-relaxed drop-shadow-xs">
              {t(news.summaryHi, news.summaryEn)}
            </p>

            {/* Meta and actions */}
            <div className="mt-4 flex items-center justify-between flex-wrap gap-3 pt-3 border-t border-white/20 text-xs text-gray-300">
              <div className="flex items-center gap-3">
                <span className="font-semibold text-emerald-400">
                  {news.author}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{t('आज का ताजा अपडेट', 'Latest Today')}</span>
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => onShare(news, e)}
                  className="p-2 rounded-full bg-white/20 backdrop-blur-md text-white hover:bg-white/30 transition-colors cursor-pointer"
                  title={t('शेयर करें', 'Share')}
                  aria-label="Share story"
                >
                  <Share2 className="w-4 h-4" />
                </button>
                <button
                  onClick={(e) => onToggleBookmark(news.id, e)}
                  className={`p-2 rounded-full backdrop-blur-md transition-colors cursor-pointer ${
                    isBookmarked ? 'bg-emerald-600 text-white' : 'bg-white/20 text-white hover:bg-white/30'
                  }`}
                  title={isBookmarked ? t('सेव किया गया', 'Saved') : t('बुकमार्क करें', 'Save story')}
                  aria-label="Bookmark story"
                >
                  <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-white' : ''}`} />
                </button>
                <div className="flex items-center gap-1 font-bold text-white pl-2 group-hover:translate-x-1 transition-transform">
                  <span>{t('पूरी खबर पढ़ें', 'Read Full Story')}</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
