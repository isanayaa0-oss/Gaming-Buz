import React, { useState } from 'react';
import { Globe, Trophy, Users } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { NewsItem } from '../types';
import { NewsCard } from './NewsCard';

interface InternationalHubProps {
  newsList: NewsItem[];
  onSelectNews: (news: NewsItem) => void;
  bookmarks: string[];
  onToggleBookmark: (id: string, e: React.MouseEvent) => void;
  onShare: (news: NewsItem, e: React.MouseEvent) => void;
}

export const InternationalHub: React.FC<InternationalHubProps> = ({
  newsList,
  onSelectNews,
  bookmarks,
  onToggleBookmark,
  onShare
}) => {
  const { isDarkMode, t } = useThemeLanguage();
  const [selectedCountry, setSelectedCountry] = useState<string>('all');

  const nations = [
    { id: 'all', nameHi: 'सभी देश', nameEn: 'All Teams', flag: '🌍' },
    { id: 'aus', nameHi: 'ऑस्ट्रेलिया', nameEn: 'Australia', flag: '🇦🇺' },
    { id: 'eng', nameHi: 'इंग्लैंड', nameEn: 'England', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿' },
    { id: 'sa', nameHi: 'दक्षिण अफ्रीका', nameEn: 'South Africa', flag: '🇿🇦' },
    { id: 'nz', nameHi: 'न्यूजीलैंड', nameEn: 'New Zealand', flag: '🇳🇿' },
    { id: 'pak', nameHi: 'पाकिस्तान', nameEn: 'Pakistan', flag: '🇵🇰' },
    { id: 'wi', nameHi: 'वेस्टइंडीज', nameEn: 'West Indies', flag: '🌴' },
    { id: 'sl', nameHi: 'श्रीलंका', nameEn: 'Sri Lanka', flag: '🇱🇰' },
    { id: 'ban', nameHi: 'बांग्लादेश', nameEn: 'Bangladesh', flag: '🇧🇩' },
    { id: 'afg', nameHi: 'अफगानिस्तान', nameEn: 'Afghanistan', flag: '🇦🇫' },
  ];

  const intlNews = newsList.filter(n => n.category === 'international');

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className={`p-6 sm:p-8 rounded-3xl border relative overflow-hidden ${
        isDarkMode 
          ? 'bg-gradient-to-r from-purple-950/80 via-slate-900 to-blue-950/80 border-purple-900/50' 
          : 'bg-gradient-to-r from-purple-700 via-indigo-700 to-blue-800 text-white shadow-lg'
      }`}>
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-white/20 backdrop-blur-md mb-3">
            <Globe className="w-3.5 h-3.5" />
            {t('अंतरराष्ट्रीय क्रिकेट मंच (ICC International Cricket)', 'International Cricket Hub')}
          </span>
          <h2 className="text-2xl sm:text-4xl font-black leading-tight">
            {t('ग्लोबल क्रिकेट: विश्व टेस्ट चैंपियनशिप व सीरीज', 'Global Cricket: WTC, Series & Rankings')}
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-purple-100/90 leading-relaxed">
            {t(
              'ऑस्ट्रेलिया, इंग्लैंड, दक्षिण अफ्रीका, न्यूजीलैंड समेत सभी प्रमुख क्रिकेट बोर्ड्स की ताजा खबरें और आईसीसी रैंकिंग्स।',
              'Global coverage of bilateral series, Ashes, ICC WTC, and world rankings.'
            )}
          </p>
        </div>
      </div>

      {/* Nation filter pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {nations.map(nat => (
          <button
            key={nat.id}
            onClick={() => setSelectedCountry(nat.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer border ${
              selectedCountry === nat.id
                ? 'bg-purple-600 text-white border-purple-500 shadow-md'
                : isDarkMode
                  ? 'bg-gray-900 border-gray-800 text-gray-300 hover:bg-gray-800'
                  : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-100 shadow-xs'
            }`}
          >
            <span>{nat.flag}</span>
            <span>{t(nat.nameHi, nat.nameEn)}</span>
          </button>
        ))}
      </div>

      {/* International News Articles */}
      <div>
        <h3 className="text-xl font-extrabold mb-4 flex items-center gap-2">
          <span>🌍</span>
          <span>{t('अंतरराष्ट्रीय क्रिकेट समाचार व मैच परिणाम', 'International News & Match Highlights')}</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {intlNews.map(item => (
            <NewsCard
              key={item.id}
              news={item}
              onSelect={onSelectNews}
              isBookmarked={bookmarks.includes(item.id)}
              onToggleBookmark={onToggleBookmark}
              onShare={onShare}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
