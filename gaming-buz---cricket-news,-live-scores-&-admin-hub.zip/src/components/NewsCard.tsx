import React from 'react';
import { 
  Bookmark, 
  Share2, 
  Clock, 
  Eye, 
  ThumbsUp, 
  Flame, 
  Check 
} from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { NewsItem } from '../types';

interface NewsCardProps {
  news: NewsItem;
  onSelect: (news: NewsItem) => void;
  isBookmarked: boolean;
  onToggleBookmark: (id: string, e: React.MouseEvent) => void;
  onShare: (news: NewsItem, e: React.MouseEvent) => void;
}

export const NewsCard: React.FC<NewsCardProps> = ({
  news,
  onSelect,
  isBookmarked,
  onToggleBookmark,
  onShare
}) => {
  const { isDarkMode, t } = useThemeLanguage();

  const getCategoryBadge = () => {
    switch (news.category) {
      case 'team_india':
        return { label: '🇮🇳 टीम इंडिया', labelEn: 'Team India', color: 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300' };
      case 'domestic':
        return { label: '🏏 घरेलू क्रिकेट', labelEn: 'Domestic', color: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' };
      case 'ipl':
        return { label: '🏆 IPL 2026', labelEn: 'IPL 2026', color: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300' };
      case 'international':
        return { label: '🌍 इंटरनेशनल', labelEn: 'International', color: 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300' };
      default:
        return { label: 'क्रिकेट न्यूज़', labelEn: 'Cricket News', color: 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300' };
    }
  };

  const badge = getCategoryBadge();

  // Format relative time
  const formatTime = (isoString: string) => {
    try {
      const diffMs = Date.now() - new Date(isoString).getTime();
      const diffMins = Math.floor(diffMs / (1000 * 60));
      if (diffMins < 60) {
        return t(`${diffMins} मिनट पहले`, `${diffMins}m ago`);
      }
      const diffHours = Math.floor(diffMins / 60);
      if (diffHours < 24) {
        return t(`${diffHours} घंटे पहले`, `${diffHours}h ago`);
      }
      const diffDays = Math.floor(diffHours / 24);
      return t(`${diffDays} दिन पहले`, `${diffDays}d ago`);
    } catch {
      return t('हाल ही में', 'Recently');
    }
  };

  return (
    <article
      onClick={() => onSelect(news)}
      className={`group rounded-2xl border transition-all duration-200 overflow-hidden cursor-pointer flex flex-col justify-between hover:shadow-lg ${
        isDarkMode
          ? 'bg-gray-900 border-gray-800 hover:border-emerald-500/40'
          : 'bg-white border-gray-200 hover:border-emerald-500/40 shadow-xs'
      }`}
    >
      <div>
        {/* Thumbnail with tags */}
        <div className="relative aspect-16/10 overflow-hidden bg-gray-100 dark:bg-gray-800">
          <img
            src={news.imageUrl}
            alt={t(news.titleHi, news.titleEn)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-linear-to-t from-black/60 via-transparent to-transparent opacity-60"></div>

          {/* Badges */}
          <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 flex-wrap">
            <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full backdrop-blur-md shadow-xs ${badge.color}`}>
              {t(badge.label, badge.labelEn)}
            </span>
            {news.isBreaking && (
              <span className="text-[11px] font-black px-2 py-0.5 rounded-full bg-red-600 text-white flex items-center gap-1 animate-pulse shadow-xs">
                <Flame className="w-3 h-3" />
                {t('ब्रेकिंग', 'BREAKING')}
              </span>
            )}
          </div>

          {news.subCategory && (
            <span className="absolute bottom-2.5 left-2.5 text-[10.5px] font-semibold px-2 py-0.5 rounded-md bg-black/70 text-white backdrop-blur-md">
              {news.subCategory}
            </span>
          )}
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className={`font-bold text-base sm:text-lg leading-snug line-clamp-2 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors ${
            isDarkMode ? 'text-gray-100' : 'text-gray-900'
          }`}>
            {t(news.titleHi, news.titleEn)}
          </h3>

          <p className="mt-2 text-xs sm:text-sm text-gray-500 dark:text-gray-400 line-clamp-2 leading-relaxed">
            {t(news.summaryHi, news.summaryEn)}
          </p>
        </div>
      </div>

      {/* Footer: Author, Timestamp, Actions */}
      <div className={`p-4 pt-0 mt-2 border-t border-transparent flex items-center justify-between text-xs text-gray-400`}>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{formatTime(news.publishedAt)}</span>
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Eye className="w-3 h-3" />
            <span>{news.views.toLocaleString()}</span>
          </span>
        </div>

        <div className="flex items-center gap-1">
          {/* Share */}
          <button
            onClick={(e) => onShare(news, e)}
            className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 hover:text-emerald-600 transition-colors cursor-pointer"
            title={t('शेयर करें (WhatsApp/Social)', 'Share')}
            aria-label="Share article"
          >
            <Share2 className="w-4 h-4" />
          </button>

          {/* Bookmark */}
          <button
            onClick={(e) => onToggleBookmark(news.id, e)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              isBookmarked
                ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40'
                : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500'
            }`}
            title={isBookmarked ? t('बुकमार्क हटाया गया', 'Remove Bookmark') : t('बुकमार्क करें', 'Bookmark')}
            aria-label="Bookmark article"
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-emerald-600 text-emerald-600' : ''}`} />
          </button>
        </div>
      </div>
    </article>
  );
};
