import React, { useState } from 'react';
import { Trophy, Flame, Award, Calendar, ChevronRight } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { IPL_STANDINGS, ORANGE_CAP_LEADERS, PURPLE_CAP_LEADERS } from '../data/initialData';
import { NewsItem } from '../types';
import { NewsCard } from './NewsCard';

interface IPLHubProps {
  newsList: NewsItem[];
  onSelectNews: (news: NewsItem) => void;
  bookmarks: string[];
  onToggleBookmark: (id: string, e: React.MouseEvent) => void;
  onShare: (news: NewsItem, e: React.MouseEvent) => void;
}

export const IPLHub: React.FC<IPLHubProps> = ({
  newsList,
  onSelectNews,
  bookmarks,
  onToggleBookmark,
  onShare
}) => {
  const { isDarkMode, t } = useThemeLanguage();
  const [activeTab, setActiveTab] = useState<'table' | 'caps' | 'news'>('table');

  const iplNews = newsList.filter(n => n.category === 'ipl');

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className={`p-6 sm:p-8 rounded-3xl border relative overflow-hidden ${
        isDarkMode 
          ? 'bg-gradient-to-r from-amber-950/80 via-purple-950/50 to-blue-950/80 border-amber-900/50' 
          : 'bg-gradient-to-r from-amber-500 via-orange-600 to-purple-700 text-white shadow-lg'
      }`}>
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-white/20 backdrop-blur-md mb-3">
            <Trophy className="w-3.5 h-3.5" />
            {t('टाटा आईपीएल 2026 स्पेशल', 'TATA IPL 2026 HUB')}
          </span>
          <h2 className="text-2xl sm:text-4xl font-black leading-tight">
            {t('आईपीएल 2026: हर छक्के और विकेट का रोमांच', 'IPL 2026: Live Standings & Stats')}
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-amber-100/90 leading-relaxed">
            {t(
              '10 टीमों की अंकतालिका, ऑरेंज कैप, पर्पल कैप और मैच प्रेडिक्शन की लाइव अपडेट्स।',
              'Official points table, cap leaders, schedule, and team analyses.'
            )}
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200 dark:border-gray-800 text-xs sm:text-sm font-bold">
        <button
          onClick={() => setActiveTab('table')}
          className={`px-4 py-3 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'table' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-500'
          }`}
        >
          {t('📊 अंकतालिका (Points Table)', 'Points Table')}
        </button>
        <button
          onClick={() => setActiveTab('caps')}
          className={`px-4 py-3 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'caps' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-500'
          }`}
        >
          {t('👑 ऑरेंज व पर्पल कैप (Orange & Purple Cap)', 'Orange & Purple Cap')}
        </button>
        <button
          onClick={() => setActiveTab('news')}
          className={`px-4 py-3 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'news' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-500'
          }`}
        >
          {t('📰 आईपीएल खबरें (IPL News)', 'IPL News')}
        </button>
      </div>

      {/* Points Table View */}
      {activeTab === 'table' && (
        <div className={`p-5 rounded-3xl border ${
          isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
        }`}>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-gray-200 dark:border-gray-800 text-gray-400">
                  <th className="py-2.5 font-bold"># {t('टीम', 'Team')}</th>
                  <th className="py-2.5 text-center">P</th>
                  <th className="py-2.5 text-center">W</th>
                  <th className="py-2.5 text-center">L</th>
                  <th className="py-2.5 text-center">NRR</th>
                  <th className="py-2.5 text-right font-black text-amber-600">{t('अंक (Pts)', 'Pts')}</th>
                </tr>
              </thead>
              <tbody>
                {IPL_STANDINGS.map((row) => (
                  <tr 
                    key={row.position} 
                    className={`border-b border-gray-100 dark:border-gray-800/60 hover:bg-gray-50/50 dark:hover:bg-gray-800/40 ${
                      row.position <= 4 ? 'bg-amber-500/5' : ''
                    }`}
                  >
                    <td className="py-3 font-bold flex items-center gap-2">
                      <span className={`w-5 h-5 rounded-full text-[10px] flex items-center justify-center font-bold ${
                        row.position <= 4 ? 'bg-amber-500 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
                      }`}>
                        {row.position}
                      </span>
                      <span className="text-sm">{row.logo}</span>
                      <span>{row.team} ({row.shortName})</span>
                    </td>
                    <td className="py-3 text-center">{row.played}</td>
                    <td className="py-3 text-center font-bold text-emerald-600">{row.won}</td>
                    <td className="py-3 text-center text-red-500">{row.lost}</td>
                    <td className="py-3 text-center font-mono">{row.nrr}</td>
                    <td className="py-3 text-right font-black text-amber-600 text-sm">{row.points}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-[11px] text-gray-400">
            * {t('शीर्ष 4 टीमें प्लेऑफ़ के लिए क्वालिफाई करेंगी।', 'Top 4 teams qualify for IPL Playoffs.')}
          </p>
        </div>
      )}

      {/* Orange & Purple Cap View */}
      {activeTab === 'caps' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Orange Cap */}
          <div className={`p-5 rounded-3xl border ${
            isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
          }`}>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-2xl">🧡</span>
              <div>
                <h3 className="font-black text-base">{t('ऑरेंज कैप - सर्वाधिक रन', 'Orange Cap - Most Runs')}</h3>
                <span className="text-xs text-gray-400">{t('शीर्ष रन स्कोरर 2026', 'Top Run Scorers')}</span>
              </div>
            </div>

            <div className="space-y-3">
              {ORANGE_CAP_LEADERS.map((leader, i) => (
                <div key={i} className={`p-3.5 rounded-2xl border flex items-center justify-between ${
                  i === 0 ? 'bg-orange-500/10 border-orange-500/30' : isDarkMode ? 'bg-gray-800/40 border-gray-800' : 'bg-gray-50 border-gray-100'
                }`}>
                  <div className="flex items-center gap-2.5">
                    <span className="font-bold text-sm text-orange-600">#{i + 1}</span>
                    <div>
                      <p className="font-bold text-xs sm:text-sm">{leader.player}</p>
                      <p className="text-[11px] text-gray-400">Avg: {leader.avg} • SR: {leader.sr}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="font-black text-lg text-orange-600">{leader.runs}</span>
                    <span className="text-xs text-gray-400 block">{leader.matches} M</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Purple Cap */}
          <div className={`p-5 rounded-3xl border ${
            isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
          }`}>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-2xl">💜</span>
              <div>
                <h3 className="font-black text-base">{t('पर्पल कैप - सर्वाधिक विकेट', 'Purple Cap - Most Wickets')}</h3>
                <span className="text-xs text-gray-400">{t('शीर्ष विकेट टेकर 2026', 'Leading Wicket Takers')}</span>
              </div>
            </div>

            <div className="space-y-3">
              {PURPLE_CAP_LEADERS.map((leader, i) => (
                <div key={i} className={`p-3.5 rounded-2xl border flex items-center justify-between ${
                  i === 0 ? 'bg-purple-500/10 border-purple-500/30' : isDarkMode ? 'bg-gray-800/40 border-gray-800' : 'bg-gray-50 border-gray-100'
                }`}>
                  <div className="flex items-center gap-2.5">
                    <span className="font-bold text-sm text-purple-600">#{i + 1}</span>
                    <div>
                      <p className="font-bold text-xs sm:text-sm">{leader.player}</p>
                      <p className="text-[11px] text-gray-400">Econ: {leader.econ} • Avg: {leader.avg}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="font-black text-lg text-purple-600">{leader.wickets} W</span>
                    <span className="text-xs text-gray-400 block">{leader.overs} ov</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* IPL News */}
      <div>
        <h3 className="text-xl font-extrabold mb-4 flex items-center gap-2">
          <span>🏆</span>
          <span>{t('आईपीएल की प्रमुख खबरें व मैच विश्लेषण', 'IPL News & Match Analysis')}</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {iplNews.map(item => (
            <NewsCard
              key={item.id}
              news={item}
              onSelect={onSelectNews}
              isBookmarked={bookmarks.includes(item.id)}
              onToggleBookmark={onToggleBookmark}
              onShare={onShare}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
