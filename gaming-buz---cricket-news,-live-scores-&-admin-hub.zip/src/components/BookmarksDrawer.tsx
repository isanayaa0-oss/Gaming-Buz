import React from 'react';
import { Bookmark, X, Trash2, ArrowRight } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { NewsItem } from '../types';

interface BookmarksDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  bookmarks: string[];
  allNews: NewsItem[];
  onSelectNews: (news: NewsItem) => void;
  onRemoveBookmark: (id: string) => void;
}

export const BookmarksDrawer: React.FC<BookmarksDrawerProps> = ({
  isOpen,
  onClose,
  bookmarks,
  allNews,
  onSelectNews,
  onRemoveBookmark
}) => {
  const { isDarkMode, t } = useThemeLanguage();

  if (!isOpen) return null;

  const bookmarkedArticles = allNews.filter(n => bookmarks.includes(n.id));

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className={`w-full max-w-md h-full flex flex-col shadow-2xl border-l transition-colors ${
        isDarkMode ? 'bg-gray-900 border-gray-800 text-gray-100' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        {/* Header */}
        <div className="p-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-emerald-500 fill-emerald-500" />
            <h3 className="font-extrabold text-base">
              {t('सेव की गई खबरें (Bookmarks)', 'Saved Bookmarks')}
            </h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold">
              {bookmarkedArticles.length}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Saved List */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3">
          {bookmarkedArticles.length > 0 ? (
            bookmarkedArticles.map(item => (
              <div
                key={item.id}
                className={`p-3 rounded-2xl border flex items-center gap-3 group transition-all ${
                  isDarkMode ? 'bg-gray-800/40 border-gray-800' : 'bg-gray-50 border-gray-200'
                }`}
              >
                <img
                  src={item.imageUrl}
                  alt=""
                  className="w-16 h-16 rounded-xl object-cover shrink-0 cursor-pointer"
                  onClick={() => {
                    onSelectNews(item);
                    onClose();
                  }}
                />
                <div 
                  className="flex-1 min-w-0 cursor-pointer"
                  onClick={() => {
                    onSelectNews(item);
                    onClose();
                  }}
                >
                  <span className="text-[10px] font-bold text-emerald-600 block uppercase">
                    {item.subCategory || item.category}
                  </span>
                  <h4 className="font-bold text-xs sm:text-sm line-clamp-2 leading-snug group-hover:text-emerald-600 transition-colors">
                    {t(item.titleHi, item.titleEn)}
                  </h4>
                </div>
                <button
                  onClick={() => onRemoveBookmark(item.id)}
                  className="p-1.5 text-gray-400 hover:text-red-500 rounded-lg cursor-pointer transition-colors"
                  title="Remove"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          ) : (
            <div className="text-center py-16 text-gray-400">
              <Bookmark className="w-12 h-12 mx-auto stroke-1 opacity-40 mb-3" />
              <p className="font-semibold text-sm">
                {t('कोई सेव की गई खबर नहीं है।', 'No bookmarks saved yet.')}
              </p>
              <p className="text-xs mt-1">
                {t('खबरों को बाद में पढ़ने के लिए बुकमार्क आइकन पर टैप करें।', 'Tap the bookmark icon on any article to save it offline.')}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
