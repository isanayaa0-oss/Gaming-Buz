import React, { useState } from 'react';
import { X, RefreshCw, Trophy, Target, Radio, Calendar, MapPin, Users } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { CricketMatch } from '../types';

interface MatchCenterModalProps {
  match: CricketMatch | null;
  onClose: () => void;
}

export const MatchCenterModal: React.FC<MatchCenterModalProps> = ({ match, onClose }) => {
  const { isDarkMode, t } = useThemeLanguage();
  const [activeTab, setActiveTab] = useState<'live' | 'scorecard' | 'commentary' | 'info'>('live');
  const [selectedInningsIdx, setSelectedInningsIdx] = useState<number>(0);

  if (!match) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div 
        className={`w-full max-w-4xl max-h-[92vh] flex flex-col rounded-3xl overflow-hidden shadow-2xl border ${
          isDarkMode ? 'bg-gray-900 border-gray-800 text-gray-100' : 'bg-white border-gray-200 text-gray-900'
        }`}
      >
        {/* Header Bar */}
        <div className={`p-4 border-b flex items-center justify-between ${
          isDarkMode ? 'bg-gray-900/90 border-gray-800' : 'bg-slate-50 border-gray-200'
        }`}>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-600 text-white">
                {match.matchType}
              </span>
              <h3 className="font-bold text-sm sm:text-base truncate max-w-[280px] sm:max-w-md">
                {match.series}
              </h3>
            </div>
            <p className="text-xs text-gray-500 mt-0.5 flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              <span>{t(match.venueHi, match.venueEn)}</span>
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-gray-200 dark:hover:bg-gray-800 text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Score Hero Card */}
        <div className={`p-4 sm:p-6 border-b ${
          isDarkMode ? 'bg-gray-950/60 border-gray-800' : 'bg-linear-to-r from-emerald-50/50 via-teal-50/30 to-blue-50/50 border-gray-200'
        }`}>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            {/* Team 1 */}
            <div className={`p-3.5 rounded-2xl border flex items-center justify-between ${
              isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-100 shadow-xs'
            }`}>
              <div className="flex items-center gap-3">
                <span className="text-3xl">{match.team1.flag}</span>
                <div>
                  <h4 className="font-extrabold text-base">{t(match.team1.nameHi, match.team1.nameEn)}</h4>
                  <span className="text-xs text-gray-400 font-mono">{match.team1.shortName}</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xl sm:text-2xl font-black">{match.team1.score || '-'}</span>
                {match.team1.overs && <p className="text-xs text-gray-400 font-mono">({match.team1.overs} ov)</p>}
              </div>
            </div>

            {/* Team 2 */}
            <div className={`p-3.5 rounded-2xl border flex items-center justify-between ${
              isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-100 shadow-xs'
            }`}>
              <div className="flex items-center gap-3">
                <span className="text-3xl">{match.team2.flag}</span>
                <div>
                  <h4 className="font-extrabold text-base">{t(match.team2.nameHi, match.team2.nameEn)}</h4>
                  <span className="text-xs text-gray-400 font-mono">{match.team2.shortName}</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xl sm:text-2xl font-black">{match.team2.score || '-'}</span>
                {match.team2.overs && <p className="text-xs text-gray-400 font-mono">({match.team2.overs} ov)</p>}
              </div>
            </div>
          </div>

          {/* Match Status Strip */}
          <div className="mt-4 p-3 rounded-xl bg-emerald-600/10 border border-emerald-500/30 flex items-center justify-between flex-wrap gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-emerald-600 dark:text-emerald-400">
                {t(match.statusTextHi, match.statusTextEn)}
              </span>
              {match.requiredRate && (
                <span className="text-gray-500">
                  • {t('जरूरी रन रेट', 'Required RR')}: <b className="text-emerald-600">{match.requiredRate}</b>
                </span>
              )}
            </div>

            {match.tossHi && (
              <span className="text-gray-500 italic">
                🎲 {t(match.tossHi, match.tossEn || '')}
              </span>
            )}
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-gray-200 dark:border-gray-800 text-xs sm:text-sm font-bold">
          <button
            onClick={() => setActiveTab('live')}
            className={`flex-1 py-3 border-b-2 text-center transition-colors cursor-pointer ${
              activeTab === 'live'
                ? 'border-emerald-600 text-emerald-600'
                : 'border-transparent text-gray-500 hover:text-gray-900 dark:hover:text-white'
            }`}
          >
            {t('🔴 लाइव स्थिति', 'Live Summary')}
          </button>
          <button
            onClick={() => setActiveTab('scorecard')}
            className={`flex-1 py-3 border-b-2 text-center transition-colors cursor-pointer ${
              activeTab === 'scorecard'
                ? 'border-emerald-600 text-emerald-600'
                : 'border-transparent text-gray-500 hover:text-gray-900 dark:hover:text-white'
            }`}
          >
            {t('📊 पूरा स्कोरकार्ड', 'Full Scorecard')}
          </button>
          <button
            onClick={() => setActiveTab('commentary')}
            className={`flex-1 py-3 border-b-2 text-center transition-colors cursor-pointer ${
              activeTab === 'commentary'
                ? 'border-emerald-600 text-emerald-600'
                : 'border-transparent text-gray-500 hover:text-gray-900 dark:hover:text-white'
            }`}
          >
            {t('⚡ बॉल-बाय-बॉल कमेंट्री', 'Live Commentary')}
          </button>
        </div>

        {/* Tab Content Area */}
        <div className="overflow-y-auto p-4 sm:p-6 flex-1">
          {activeTab === 'live' && (
            <div className="space-y-6">
              {/* Active Batsmen & Bowler (if live) */}
              {match.currentBatsmen && match.currentBatsmen.length > 0 && (
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-gray-400 mb-2">
                    {t('क्रीज पर बल्लेबाज', 'Batters at Crease')}
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {match.currentBatsmen.map((b, i) => (
                      <div key={i} className={`p-3 rounded-xl border flex items-center justify-between ${
                        isDarkMode ? 'bg-gray-800/40 border-gray-800' : 'bg-gray-50 border-gray-200'
                      }`}>
                        <div>
                          <p className="font-bold text-sm">{b.name} *</p>
                          <p className="text-xs text-gray-400 font-mono">
                            SR: {((b.runs / (b.balls || 1)) * 100).toFixed(1)}
                          </p>
                        </div>
                        <div className="text-right">
                          <span className="font-extrabold text-lg text-emerald-600 dark:text-emerald-400">{b.runs}</span>
                          <span className="text-xs text-gray-400 ml-1">({b.balls})</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Active Bowler */}
              {match.currentBowler && (
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-gray-400 mb-2">
                    {t('वर्तमान गेंदबाज', 'Current Bowler')}
                  </h4>
                  <div className={`p-3 rounded-xl border flex items-center justify-between ${
                    isDarkMode ? 'bg-gray-800/40 border-gray-800' : 'bg-gray-50 border-gray-200'
                  }`}>
                    <div>
                      <p className="font-bold text-sm">{match.currentBowler.name}</p>
                      <p className="text-xs text-gray-400">Right-arm fast</p>
                    </div>
                    <div className="text-right font-mono font-bold text-sm">
                      {match.currentBowler.figures}
                    </div>
                  </div>
                </div>
              )}

              {/* Recent Balls Strip */}
              {match.recentBalls && (
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-gray-400 mb-2">
                    {t('पिछला ओवर (This Over)', 'This Over')}
                  </h4>
                  <div className="flex items-center gap-2">
                    {match.recentBalls.map((b, idx) => (
                      <span
                        key={idx}
                        className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                          b === '6'
                            ? 'bg-purple-600 text-white'
                            : b === '4'
                              ? 'bg-blue-600 text-white'
                              : b === 'W'
                                ? 'bg-red-600 text-white animate-bounce'
                                : 'bg-gray-200 dark:bg-gray-800 text-gray-800 dark:text-gray-200'
                        }`}
                      >
                        {b}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'scorecard' && (
            <div>
              {match.innings && match.innings.length > 0 ? (
                <div>
                  {/* Innings selector buttons */}
                  <div className="flex gap-2 mb-4">
                    {match.innings.map((inn, idx) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedInningsIdx(idx)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                          selectedInningsIdx === idx
                            ? 'bg-emerald-600 text-white'
                            : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300'
                        }`}
                      >
                        {inn.teamName} {inn.score} ({inn.overs} ov)
                      </button>
                    ))}
                  </div>

                  {/* Batting Table */}
                  <div className="mb-6">
                    <h4 className="font-bold text-sm mb-2 text-emerald-600">
                      {match.innings[selectedInningsIdx]?.teamName} - {t('बल्लेबाजी (Batting)', 'Batting')}
                    </h4>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-gray-200 dark:border-gray-800 text-gray-400">
                            <th className="py-2">{t('बल्लेबाज', 'Batter')}</th>
                            <th className="py-2 text-right">R</th>
                            <th className="py-2 text-right">B</th>
                            <th className="py-2 text-right">4s</th>
                            <th className="py-2 text-right">6s</th>
                            <th className="py-2 text-right">SR</th>
                          </tr>
                        </thead>
                        <tbody>
                          {match.innings[selectedInningsIdx]?.batting.map((b, i) => (
                            <tr key={i} className="border-b border-gray-100 dark:border-gray-800/60">
                              <td className="py-2 font-semibold">
                                {b.name}
                                <span className="block text-[10px] text-gray-400 font-normal">{b.dismissal}</span>
                              </td>
                              <td className="py-2 text-right font-bold text-emerald-600">{b.runs}</td>
                              <td className="py-2 text-right">{b.balls}</td>
                              <td className="py-2 text-right">{b.fours}</td>
                              <td className="py-2 text-right">{b.sixes}</td>
                              <td className="py-2 text-right font-mono">{b.strikeRate.toFixed(1)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Bowling Table */}
                  <div>
                    <h4 className="font-bold text-sm mb-2 text-blue-600">
                      {t('गेंदबाजी (Bowling)', 'Bowling')}
                    </h4>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-gray-200 dark:border-gray-800 text-gray-400">
                            <th className="py-2">{t('गेंदबाज', 'Bowler')}</th>
                            <th className="py-2 text-right">O</th>
                            <th className="py-2 text-right">M</th>
                            <th className="py-2 text-right">R</th>
                            <th className="py-2 text-right">W</th>
                            <th className="py-2 text-right">Econ</th>
                          </tr>
                        </thead>
                        <tbody>
                          {match.innings[selectedInningsIdx]?.bowling.map((bw, i) => (
                            <tr key={i} className="border-b border-gray-100 dark:border-gray-800/60">
                              <td className="py-2 font-semibold">{bw.name}</td>
                              <td className="py-2 text-right font-mono">{bw.overs}</td>
                              <td className="py-2 text-right">{bw.maidens}</td>
                              <td className="py-2 text-right">{bw.runs}</td>
                              <td className="py-2 text-right font-bold text-red-500">{bw.wickets}</td>
                              <td className="py-2 text-right font-mono">{bw.economy.toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-center py-8 text-gray-400 text-sm">
                  {t('विस्तृत स्कोरकार्ड जल्द ही अपडेट किया जाएगा।', 'Detailed scorecard will be updated shortly.')}
                </p>
              )}
            </div>
          )}

          {activeTab === 'commentary' && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-xs">
                <span className="font-bold text-emerald-600">18.2: </span>
                <span>पैट कमिंस की गेंद पर हार्दिक पांड्या ने कवर ड्राइव खेल कर 2 रन लिए। भारत अब जीत से सिर्फ 2 रन दूर!</span>
              </div>
              <div className="p-3 rounded-xl border border-gray-200 dark:border-gray-800 text-xs">
                <span className="font-bold text-purple-600">18.1: </span>
                <span>छक्का! सूर्यकुमार यादव का ट्रेडमार्क स्कूप शॉट फाइन लेग के ऊपर से बाउंड्री के पार!</span>
              </div>
              <div className="p-3 rounded-xl border border-gray-200 dark:border-gray-800 text-xs">
                <span className="font-bold text-blue-600">17.6: </span>
                <span>स्टार्क की यॉर्कर गेंद, सिंगल चुराया। शानदार रनिंग बिटवीन द विकेट्स।</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
