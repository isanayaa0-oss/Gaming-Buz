import React, { useState } from 'react';
import { Play, Video, Eye, Clock, X, ExternalLink } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { VideoItem } from '../types';

interface VideosSectionProps {
  videos: VideoItem[];
}

export const VideosSection: React.FC<VideosSectionProps> = ({ videos }) => {
  const { isDarkMode, t } = useThemeLanguage();
  const [selectedVideo, setSelectedVideo] = useState<VideoItem | null>(null);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-black flex items-center gap-2">
            <Video className="w-6 h-6 text-purple-500" />
            <span>{t('क्रिकेट वीडियो व यूट्यूब हाइलाइट्स', 'Cricket Videos & YouTube Highlights')}</span>
          </h2>
          <p className="text-xs text-gray-500 mt-1">
            {t('मैच के खास पल, प्रेस कॉन्फ्रेंस और ऐतिहासिक पारियों के वीडियो', 'Match highlights, press conferences, and top moments')}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {videos.map((vid) => (
          <div
            key={vid.id}
            onClick={() => setSelectedVideo(vid)}
            className={`group rounded-2xl border overflow-hidden cursor-pointer transition-all hover:shadow-lg ${
              isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
            }`}
          >
            {/* Thumbnail with duration badge and play icon */}
            <div className="relative aspect-16/9 bg-gray-900 overflow-hidden">
              <img
                src={vid.thumbnail}
                alt={t(vid.titleHi, vid.titleEn)}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90"
              />
              <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-red-600/90 text-white flex items-center justify-center shadow-lg group-hover:scale-110 group-hover:bg-red-600 transition-all">
                  <Play className="w-5 h-5 fill-white ml-0.5" />
                </div>
              </div>
              <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-white text-[10px] font-mono font-bold backdrop-blur-xs">
                {vid.duration}
              </span>
              <span className="absolute top-2 left-2 px-2 py-0.5 rounded bg-purple-600/90 text-white text-[10px] font-bold">
                {vid.category}
              </span>
            </div>

            {/* Video Meta */}
            <div className="p-3.5">
              <h3 className={`font-bold text-xs sm:text-sm line-clamp-2 leading-snug group-hover:text-purple-600 transition-colors ${
                isDarkMode ? 'text-gray-100' : 'text-gray-900'
              }`}>
                {t(vid.titleHi, vid.titleEn)}
              </h3>
              <div className="mt-2 flex items-center justify-between text-[11px] text-gray-400">
                <span className="flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  <span>{vid.views}</span>
                </span>
                <span>{vid.publishedAt}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Video Player Modal */}
      {selectedVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-4xl bg-gray-950 rounded-3xl overflow-hidden shadow-2xl border border-gray-800">
            <div className="p-4 flex items-center justify-between border-b border-gray-800 text-white">
              <h3 className="font-bold text-sm sm:text-base truncate max-w-xl">
                {t(selectedVideo.titleHi, selectedVideo.titleEn)}
              </h3>
              <button
                onClick={() => setSelectedVideo(null)}
                className="p-1.5 rounded-lg hover:bg-gray-800 text-gray-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Embedded YouTube / Video Player */}
            <div className="relative aspect-16/9 w-full bg-black">
              <iframe
                src={`https://www.youtube.com/embed/${selectedVideo.youtubeId}?autoplay=1`}
                title={t(selectedVideo.titleHi, selectedVideo.titleEn)}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full border-0"
              />
            </div>

            <div className="p-4 bg-gray-900 text-xs text-gray-300 flex items-center justify-between">
              <div>
                <span className="font-bold text-emerald-400">{selectedVideo.category}</span>
                <span className="mx-2">•</span>
                <span>{selectedVideo.views}</span>
              </div>
              <a
                href={`https://www.youtube.com/watch?v=${selectedVideo.youtubeId}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 text-red-400 hover:underline"
              >
                <span>YouTube पर देखें</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
