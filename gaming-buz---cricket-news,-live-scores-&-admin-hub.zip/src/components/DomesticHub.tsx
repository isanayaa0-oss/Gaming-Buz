import React, { useState } from 'react';
import { Trophy, Award, TrendingUp, Users, Calendar, Filter } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { DOMESTIC_TOURNAMENTS } from '../data/initialData';
import { NewsItem } from '../types';
import { NewsCard } from './NewsCard';

interface DomesticHubProps {
  newsList: NewsItem[];
  onSelectNews: (news: NewsItem) => void;
  bookmarks: string[];
  onToggleBookmark: (id: string, e: React.MouseEvent) => void;
  onShare: (news: NewsItem, e: React.MouseEvent) => void;
}

export const DomesticHub: React.FC<DomesticHubProps> = ({
  newsList,
  onSelectNews,
  bookmarks,
  onToggleBookmark,
  onShare
}) => {
  const { isDarkMode, t } = useThemeLanguage();
  const [selectedTournamentId, setSelectedTournamentId] = useState<string>('ranji');

  const currentTournament = DOMESTIC_TOURNAMENTS.find(t => t.id === selectedTournamentId) || DOMESTIC_TOURNAMENTS[0];

  // Domestic news filtered
  const domesticNews = newsList.filter(n => n.category === 'domestic');

  return (
    <div className="space-y-6">
      {/* Hero Header */}
      <div className={`p-6 sm:p-8 rounded-3xl border relative overflow-hidden ${
        isDarkMode 
          ? 'bg-gradient-to-br from-emerald-950/80 via-gray-900 to-teal-950/80 border-emerald-900/50' 
          : 'bg-gradient-to-br from-emerald-600 via-teal-700 to-emerald-800 text-white border-transparent shadow-lg'
      }`}>
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-white/20 backdrop-blur-md mb-3">
            <Trophy className="w-3.5 h-3.5" />
            {t('भारतीय घरेलू क्रिकेट हब (BCCI Domestic)', 'BCCI Domestic Cricket Hub')}
          </span>
          <h2 className="text-2xl sm:text-4xl font-black leading-tight">
            {t('घरेलू क्रिकेट: भविष्य के चैंपियंस की कर्मभूमि', 'Indian Domestic Cricket Hub')}
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
            {t(
              'रणजी ट्रॉफी, विजय हजारे, सैयद मुश्ताक अली, दलीप ट्रॉफी और ईरानी कप के लाइव स्कोर, पॉइंट्स टेबल व उभरते सितारों की एक्सक्लूसिव कवरेज।',
              'Complete standings, top performers, fixtures & insights from Ranji Trophy, Vijay Hazare, SMAT, Duleep Trophy and Irani Cup.'
            )}
          </p>
        </div>
      </div>

      {/* Tournament Selector Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {DOMESTIC_TOURNAMENTS.map(tour => {
          const isSelected = tour.id === selectedTournamentId;
          return (
            <button
              key={tour.id}
              onClick={() => setSelectedTournamentId(tour.id)}
              className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer border ${
                isSelected
                  ? 'bg-emerald-600 border-emerald-500 text-white shadow-md shadow-emerald-600/30'
                  : isDarkMode
                    ? 'bg-gray-900 border-gray-800 text-gray-300 hover:bg-gray-800'
                    : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-100 shadow-xs'
              }`}
            >
              <span>{t(tour.nameHi, tour.nameEn)}</span>
            </button>
          );
        })}
      </div>

      {/* Active Tournament Details & Standings */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Tournament Overview & Points Table */}
        <div className={`lg:col-span-2 p-5 sm:p-6 rounded-3xl border ${
          isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
        }`}>
          <div className="flex items-center justify-between flex-wrap gap-2 mb-4">
            <div>
              <h3 className="text-lg font-black">{t(currentTournament.nameHi, currentTournament.nameEn)}</h3>
              <p className="text-xs text-gray-500 mt-0.5">{t(currentTournament.descriptionHi, currentTournament.descriptionEn)}</p>
            </div>
            <div className="text-right">
              <span className="text-[11px] text-gray-400 block">{t('वर्तमान चैंपियन', 'Defending Champion')}</span>
              <span className="text-xs font-bold text-emerald-600">{currentTournament.currentChampion}</span>
            </div>
          </div>

          {/* Points Table */}
          <h4 className="text-xs font-black uppercase tracking-wider text-gray-400 mb-2">
            {t('अंकतालिका (Points Table)', 'Points Table')}
          </h4>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-gray-200 dark:border-gray-800 text-gray-400">
                  <th className="py-2.5 font-bold"># {t('टीम', 'Team')}</th>
                  <th className="py-2.5 text-center">P</th>
                  <th className="py-2.5 text-center">W</th>
                  <th className="py-2.5 text-center">L</th>
                  {currentTournament.trophyType === 'FirstClass' && <th className="py-2.5 text-center">D</th>}
                  <th className="py-2.5 text-right font-black text-emerald-600">{t('अंक (Pts)', 'Pts')}</th>
                </tr>
              </thead>
              <tbody>
                {currentTournament.table.map((row, i) => (
                  <tr key={i} className="border-b border-gray-100 dark:border-gray-800/60 hover:bg-gray-50/50 dark:hover:bg-gray-800/40">
                    <td className="py-2.5 font-bold flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-500 text-[10px] flex items-center justify-center font-bold">
                        {i + 1}
                      </span>
                      <span>{row.team}</span>
                    </td>
                    <td className="py-2.5 text-center">{row.played}</td>
                    <td className="py-2.5 text-center font-bold text-emerald-600">{row.won}</td>
                    <td className="py-2.5 text-center text-red-500">{row.lost}</td>
                    {currentTournament.trophyType === 'FirstClass' && <td className="py-2.5 text-center text-gray-400">{row.draw ?? 0}</td>}
                    <td className="py-2.5 text-right font-black text-emerald-600">{row.points}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: Top Performers / Future Stars */}
        <div className={`p-5 sm:p-6 rounded-3xl border flex flex-col justify-between ${
          isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
        }`}>
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Award className="w-5 h-5 text-amber-500" />
              <h3 className="text-base font-extrabold">{t('शीर्ष प्रदर्शनकारी (Top Performers)', 'Top Performers')}</h3>
            </div>

            <div className="space-y-3">
              {currentTournament.topPerformers.map((p, idx) => (
                <div key={idx} className={`p-3 rounded-2xl border ${
                  isDarkMode ? 'bg-gray-800/50 border-gray-700' : 'bg-slate-50 border-gray-200'
                }`}>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-bold text-emerald-600 dark:text-emerald-400">{p.player}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-semibold">
                      {p.role}
                    </span>
                  </div>
                  <p className="text-xs text-gray-700 dark:text-gray-300 font-medium">
                    {p.stat}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800 text-center">
            <span className="text-[11px] text-gray-400">
              {t('💡 चयन समिति की इन प्रदर्शनों पर कड़ी नज़र रहती है', 'National selectors closely scout these performances')}
            </span>
          </div>
        </div>
      </div>

      {/* Domestic News Articles */}
      <div>
        <h3 className="text-xl font-extrabold mb-4 flex items-center gap-2">
          <span>🏏</span>
          <span>{t('घरेलू क्रिकेट की ताजा खबरें व मैच रिपोर्ट', 'Latest Domestic Cricket News & Reports')}</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {domesticNews.map(item => (
            <NewsCard
              key={item.id}
              news={item}
              onSelect={onSelectNews}
              isBookmarked={bookmarks.includes(item.id)}
              onToggleBookmark={onToggleBookmark}
              onShare={onShare}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
