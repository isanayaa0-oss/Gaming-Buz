import React, { useState } from 'react';
import { Search, X, Calendar, ArrowRight, Filter } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { NewsItem } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  newsList: NewsItem[];
  onSelectNews: (news: NewsItem) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  newsList,
  onSelectNews
}) => {
  const { isDarkMode, t } = useThemeLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<'all' | 'team_india' | 'domestic' | 'ipl' | 'international'>('all');

  if (!isOpen) return null;

  const filteredNews = newsList.filter(item => {
    const matchesCategory = filterCategory === 'all' || item.category === filterCategory;
    const term = searchTerm.toLowerCase().trim();
    if (!term) return matchesCategory;

    const matchesTitle = item.titleHi.toLowerCase().includes(term) || item.titleEn.toLowerCase().includes(term);
    const matchesSummary = item.summaryHi.toLowerCase().includes(term) || item.summaryEn.toLowerCase().includes(term);
    const matchesTags = item.tags.some(tag => tag.toLowerCase().includes(term));
    const matchesAuthor = item.author.toLowerCase().includes(term);
    return matchesCategory && (matchesTitle || matchesSummary || matchesTags || matchesAuthor);
  });

  const popularSearches = ['रोहित शर्मा', 'विराट कोहली', 'रणजी ट्रॉफी', 'IPL 2026', 'यशस्वी जायसवाल', 'जसप्रीत बुमराह'];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-10 sm:pt-20 p-3 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className={`w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl border flex flex-col max-h-[85vh] ${
        isDarkMode ? 'bg-gray-900 border-gray-800 text-gray-100' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        {/* Search Input Bar */}
        <div className={`p-4 border-b flex items-center gap-3 ${
          isDarkMode ? 'bg-gray-900/90 border-gray-800' : 'bg-white border-gray-100'
        }`}>
          <Search className="w-5 h-5 text-emerald-500 shrink-0" />
          <input
            type="text"
            autoFocus
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={t('खिलाड़ी, टीम, टूर्नामेंट या खबर खोजें...', 'Search players, teams, tournaments or news...')}
            className="w-full text-base font-medium bg-transparent focus:outline-none"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="p-1 text-gray-400 hover:text-gray-600 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 cursor-pointer text-xs font-bold"
          >
            Esc
          </button>
        </div>

        {/* Filter Pills */}
        <div className="p-3 border-b border-gray-100 dark:border-gray-800 flex items-center gap-1.5 overflow-x-auto text-xs font-semibold no-scrollbar">
          <span className="text-gray-400 flex items-center gap-1 pl-1 pr-2">
            <Filter className="w-3 h-3" />
            {t('फ़िल्टर:', 'Filter:')}
          </span>
          {[
            { id: 'all', labelHi: 'सभी', labelEn: 'All' },
            { id: 'team_india', labelHi: '🇮🇳 टीम इंडिया', labelEn: 'Team India' },
            { id: 'domestic', labelHi: '🏏 घरेलू क्रिकेट', labelEn: 'Domestic' },
            { id: 'ipl', labelHi: '🏆 IPL', labelEn: 'IPL' },
            { id: 'international', labelHi: '🌍 इंटरनेशनल', labelEn: 'International' },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilterCategory(f.id as any)}
              className={`px-3 py-1 rounded-full whitespace-nowrap cursor-pointer transition-colors ${
                filterCategory === f.id
                  ? 'bg-emerald-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400'
              }`}
            >
              {t(f.labelHi, f.labelEn)}
            </button>
          ))}
        </div>

        {/* Popular Tags */}
        {!searchTerm && (
          <div className="p-4 border-b border-gray-100 dark:border-gray-800 text-xs">
            <span className="text-gray-400 font-medium block mb-2">
              {t('🔥 लोकप्रिय खोज (Trending Searches):', 'Trending Searches:')}
            </span>
            <div className="flex flex-wrap gap-2">
              {popularSearches.map(tag => (
                <button
                  key={tag}
                  onClick={() => setSearchTerm(tag)}
                  className="px-2.5 py-1 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-emerald-500 text-gray-700 dark:text-gray-300 cursor-pointer text-xs"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Search Results List */}
        <div className="overflow-y-auto p-4 flex-1 space-y-3">
          {filteredNews.length > 0 ? (
            filteredNews.map(item => (
              <div
                key={item.id}
                onClick={() => {
                  onSelectNews(item);
                  onClose();
                }}
                className={`p-3 rounded-2xl border flex items-center justify-between gap-3 cursor-pointer hover:border-emerald-500 transition-all ${
                  isDarkMode ? 'bg-gray-800/40 border-gray-800' : 'bg-gray-50 border-gray-200'
                }`}
              >
                <img src={item.imageUrl} alt="" className="w-16 h-16 rounded-xl object-cover shrink-0" />
                <div className="flex-1 min-w-0">
                  <span className="text-[10px] font-bold text-emerald-600 block uppercase">
                    {item.subCategory || item.category}
                  </span>
                  <h4 className="font-bold text-xs sm:text-sm line-clamp-2 leading-snug">
                    {t(item.titleHi, item.titleEn)}
                  </h4>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-400 shrink-0" />
              </div>
            ))
          ) : (
            <div className="text-center py-12 text-gray-400">
              <p className="text-sm">{t('कोई खबर नहीं मिली।', 'No matching cricket news found.')}</p>
              <p className="text-xs mt-1">{t('कृपया अन्य कीवर्ड खोजें।', 'Try searching for another keyword.')}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
