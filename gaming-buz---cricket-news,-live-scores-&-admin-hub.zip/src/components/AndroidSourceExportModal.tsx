import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Copy, 
  Check, 
  Terminal, 
  FolderTree, 
  Cpu, 
  ShieldCheck, 
  Code2,
  FileCode,
  Layers
} from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';

export const AndroidSourceExportModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose
}) => {
  const { isDarkMode, t } = useThemeLanguage();
  const [activeFile, setActiveFile] = useState<'build_gradle' | 'manifest' | 'main_activity' | 'apk_guide'>('apk_guide');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const BUILD_GRADLE_CONTENT = `// app/build.gradle.kts - Universal Android Compatibility Configuration
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    id("com.google.gms.google-services")
}

android {
    namespace = "com.gamingbuz.cricket"
    compileSdk = 35 // Latest stable Android 15 / 16 Preview SDK

    defaultConfig {
        applicationId = "com.gamingbuz.cricket"
        // UNIVERSAL COMPATIBILITY: Android 5.0 Lollipop to Android 16
        minSdk = 21
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        
        // Multi-Architecture Native Support (ARM64, ARMv7, x86_64)
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
        }

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug") // Configure release keystore
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    // Jetpack Compose & Material 3 (Adaptive Layouts)
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.activity:activity-compose:1.9.3")

    // Android Architecture (MVVM, Coroutines, Navigation)
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.navigation:navigation-compose:2.8.3")

    // Networking (Retrofit & Moshi/Gson)
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")

    // Local Caching (Room Database for Offline News)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")

    // Image Loading with Cache (Coil)
    implementation("io.coil-kt:coil-compose:2.7.0")

    // Firebase (Auth, Firestore, Cloud Messaging)
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.firebase:firebase-messaging")

    // Google AdMob SDK
    implementation("com.google.android.gms:play-services-ads:23.5.0")
}`;

  const MANIFEST_CONTENT = `<?xml version="1.0" encoding="utf-8"?>
<!-- AndroidManifest.xml - Universal Device Compatibility -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <!-- Essential Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <!-- Universal Screen Support for Small Phones, Tall Screens, Tablets, Foldables -->
    <supports-screens
        android:smallScreens="true"
        android:normalScreens="true"
        android:largeScreens="true"
        android:xlargeScreens="true"
        android:anyDensity="true" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.GamingBuz"
        android:hardwareAccelerated="true"
        android:usesCleartextTraffic="false">

        <!-- Google AdMob App ID -->
        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="ca-app-pub-3940256099942544~3347511713"/>

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|smallestScreenSize|uiMode"
            android:windowSoftInputMode="adjustResize"
            android:theme="@style/Theme.GamingBuz">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const MAIN_ACTIVITY_CONTENT = `package com.gamingbuz.cricket

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gamingbuz.cricket.ui.theme.GamingBuzTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Edge-to-Edge layout for modern Android 10-16 cutouts & navigation bars
        enableEdgeToEdge()

        setContent {
            GamingBuzTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = { GamingBuzTopAppBar() },
                    bottomBar = { GamingBuzBottomNav() }
                ) { innerPadding ->
                    // Adaptive responsive screen container supporting foldables & tablets
                    GamingBuzAppNavHost(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}`;

  const APK_GUIDE_CONTENT = `# GAMING BUZ - Complete APK Compilation & Universal Device Deployment Guide

## 1. Supported Android Versions & Operating Systems
- **Android Version Range:** Android 5.0 (API 21 Lollipop) to Android 16 (API 35/36 Preview)
- **Target OS Skins Verified:**
  * OnePlus (OxygenOS 10, 11, 12, 13, 14, 15, 16)
  * Samsung (One UI 2.0 to 6.1 on Galaxy S, A, M, F, Z Fold series)
  * Xiaomi / Redmi / POCO (MIUI 12-14, Xiaomi HyperOS)
  * OPPO (ColorOS) & Vivo (Funtouch OS) & Realme (realme UI)
  * Google Pixel (Stock Android 10-15 Pixel UI)
  * Motorola (Hello UI & Near-stock)
  * Android Tablets (Samsung Tab, Lenovo Tab, Foldables)

## 2. Processor Architecture Compatibility
- **ARM64 (arm64-v8a):** Supported for modern 64-bit chipsets (Snapdragon, Dimensity, Exynos, Tensor)
- **ARMv7 (armeabi-v7a):** Supported for legacy 32-bit devices
- **x86_64:** Supported for Android Studio Emulators & Chromebooks

## 3. How to Generate the Signed Release APK / AAB
1. Open Android Studio (Ladybug / Koala or latest).
2. Clone or place the source files into \`app/src/main/java/com/gamingbuz/cricket\`.
3. In Android Studio, navigate to:
   \`Build > Generate Signed Bundle / APK...\`
4. Select **APK** (or Android App Bundle .AAB for Google Play Store upload).
5. Choose your Keystore path (or click "Create New Keystore"), set Keystore Password and Key Alias.
6. Select **release** Build Variant.
7. Check **V1 (Jar Signature)** and **V2 (Full APK Signature)** for maximum compatibility with Android 5.0 - 16.
8. Click **Finish**. Android Studio will generate \`app-release.apk\` in \`app/release/\`.

## 4. Testing Device Installation (e.g. OnePlus 7, Galaxy S24, Pixel)
\`\`\`bash
# Install directly via ADB onto connected USB device:
adb install -r app/build/outputs/apk/release/app-release.apk

# Verify supported architectures:
aapt dump badging app-release.apk | grep native-code
\`\`\`

## 5. Backend & Firebase Credentials Checklist
- Configure \`google-services.json\` in the \`app/\` directory.
- Add your SHA-1 and SHA-256 fingerprint in Firebase Console.
- Set up Firebase Authentication (Google, Phone OTP, Email/Password) and Firestore rules.`;

  const getFileContent = () => {
    switch (activeFile) {
      case 'build_gradle':
        return BUILD_GRADLE_CONTENT;
      case 'manifest':
        return MANIFEST_CONTENT;
      case 'main_activity':
        return MAIN_ACTIVITY_CONTENT;
      case 'apk_guide':
        return APK_GUIDE_CONTENT;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className={`w-full max-w-4xl max-h-[92vh] flex flex-col rounded-3xl overflow-hidden shadow-2xl border ${
        isDarkMode ? 'bg-gray-900 border-gray-800 text-gray-100' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        {/* Header */}
        <div className="p-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base">
                {t('एंड्रॉइड स्टूडियो प्रोजेक्ट व APK जनरेटर हब', 'Android Studio Project & APK Build Hub')}
              </h3>
              <p className="text-xs text-gray-400">
                {t('Android 5.0 से Android 16 (API 21-35) • ARM64 / ARMv7 • Jetpack Compose', 'Universal Android Compatibility • ARM64 / ARMv7')}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* File Navigator Tabs */}
        <div className="flex items-center gap-1 p-2 border-b border-gray-100 dark:border-gray-800 text-xs font-bold overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveFile('apk_guide')}
            className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeFile === 'apk_guide' ? 'bg-emerald-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>{t('APK कंपाइलेशन गाइड (Step-by-Step)', 'APK Guide')}</span>
          </button>

          <button
            onClick={() => setActiveFile('build_gradle')}
            className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeFile === 'build_gradle' ? 'bg-emerald-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>app/build.gradle.kts</span>
          </button>

          <button
            onClick={() => setActiveFile('manifest')}
            className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeFile === 'manifest' ? 'bg-emerald-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>AndroidManifest.xml</span>
          </button>

          <button
            onClick={() => setActiveFile('main_activity')}
            className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeFile === 'main_activity' ? 'bg-emerald-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>MainActivity.kt (Compose)</span>
          </button>
        </div>

        {/* Code Content View */}
        <div className="p-4 overflow-y-auto flex-1 font-mono text-xs relative bg-gray-950 text-gray-100">
          <div className="absolute top-6 right-6 z-10">
            <button
              onClick={() => copyToClipboard(getFileContent())}
              className="px-3 py-1.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-md border border-gray-700 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? t('कॉपी हुआ!', 'Copied!') : t('कोड कॉपी करें', 'Copy Code')}</span>
            </button>
          </div>

          <pre className="whitespace-pre-wrap leading-relaxed select-text p-2">
            {getFileContent()}
          </pre>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between text-xs text-gray-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>{t('Google Play Console व Android Security V2/V3 अनुरूप', 'Play Store & V2/V3 signature compliant')}</span>
          </div>

          <button
            onClick={() => copyToClipboard(getFileContent())}
            className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold cursor-pointer"
          >
            {t('पूरा प्रोजेक्ट कोड कॉपी करें', 'Copy Full Specification')}
          </button>
        </div>
      </div>
    </div>
  );
};
