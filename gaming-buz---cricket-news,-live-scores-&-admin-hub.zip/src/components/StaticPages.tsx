import React, { useState } from 'react';
import { Shield, FileText, Mail, Info, CheckCircle2 } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';

export const StaticPages: React.FC<{ initialPage?: 'about' | 'privacy' | 'terms' | 'contact'; onClose: () => void }> = ({
  initialPage = 'about',
  onClose
}) => {
  const { isDarkMode, t } = useThemeLanguage();
  const [activePage, setActivePage] = useState<'about' | 'privacy' | 'terms' | 'contact'>(initialPage);
  const [contactSent, setContactSent] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className={`w-full max-w-3xl max-h-[90vh] flex flex-col rounded-3xl overflow-hidden shadow-2xl border ${
        isDarkMode ? 'bg-gray-900 border-gray-800 text-gray-100' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        {/* Header Tabs */}
        <div className="p-3 sm:p-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-1 overflow-x-auto text-xs font-bold no-scrollbar">
            <button
              onClick={() => setActivePage('about')}
              className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer ${
                activePage === 'about' ? 'bg-emerald-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              {t('हमारे बारे में', 'About Us')}
            </button>
            <button
              onClick={() => setActivePage('privacy')}
              className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer ${
                activePage === 'privacy' ? 'bg-emerald-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              {t('गोपनीयता नीति (Privacy)', 'Privacy Policy')}
            </button>
            <button
              onClick={() => setActivePage('terms')}
              className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer ${
                activePage === 'terms' ? 'bg-emerald-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              {t('नियम व शर्तें (Terms)', 'Terms of Service')}
            </button>
            <button
              onClick={() => setActivePage('contact')}
              className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer ${
                activePage === 'contact' ? 'bg-emerald-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              {t('संपर्क करें (Contact)', 'Contact Us')}
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-3 py-1 rounded-lg text-xs font-bold bg-gray-100 dark:bg-gray-800 text-gray-500 hover:text-gray-900 dark:hover:text-white cursor-pointer"
          >
            {t('बंद करें (Close)', 'Close')}
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1 text-sm leading-relaxed space-y-4">
          {activePage === 'about' && (
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white text-2xl font-black shadow-md">
                  🏏
                </div>
                <div>
                  <h2 className="text-xl font-extrabold">GAMING BUZ - क्रिकेट न्यूज़ हब</h2>
                  <p className="text-xs text-gray-500">विश्वसनीय, सटीक और निष्पक्ष खेल पत्रकारिता</p>
                </div>
              </div>
              <p>
                <b>GAMING BUZ</b> भारत का प्रमुख हिंदी और द्विभाषी क्रिकेट डिजिटल प्लेटफॉर्म है। हमारा उद्देश्य हर क्रिकेट प्रेमी तक मैदान की ताजा हलचल, ड्रेसिंग रूम की इनसाइड स्टोरीज़, विस्तृत मैच विश्लेषण और लाइव स्कोरकार्ड सबसे तेज़ गति से पहुँचाना है।
              </p>
              <h4 className="font-bold text-base mt-4 text-emerald-600">हमारे प्रमुख स्तंभ:</h4>
              <ul className="list-disc pl-5 space-y-2 text-xs sm:text-sm">
                <li><b>घरेलू क्रिकेट (BCCI Domestic) का सम्मान:</b> रणजी ट्रॉफी, विजय हजारे और सैयद मुश्ताक अली के प्रदर्शनकारियों को देश के सामने लाना।</li>
                <li><b>टीम इंडिया स्पेशल:</b> कप्तानी, प्लेइंग 11 चयन और आगामी आईसीसी टूर्नामेंट्स का गहन विश्लेषण।</li>
                <li><b>प्रोफेशनल एडमिन टेक्नोलॉजी:</b> बिना किसी देरी के संपादकीय टीम द्वारा त्वरित खबर प्रकाशन।</li>
              </ul>
            </div>
          )}

          {activePage === 'privacy' && (
            <div>
              <h2 className="text-xl font-extrabold mb-3 flex items-center gap-2">
                <Shield className="w-5 h-5 text-emerald-500" />
                <span>गोपनीयता नीति (Privacy Policy)</span>
              </h2>
              <p className="text-xs text-gray-400">अंतिम अपडेट: अक्टूबर 2026</p>
              <p>
                GAMING BUZ उपयोगकर्ता की गोपनीयता का पूर्ण सम्मान करता है। यह नीति स्पष्ट करती है कि हम आपकी जानकारी का संग्रह और उपयोग कैसे करते हैं:
              </p>
              <h4 className="font-bold text-sm text-emerald-600 mt-3">1. एकत्र की जाने वाली जानकारी:</h4>
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300">
                उपयोगकर्ता खाता बनाते समय Google OAuth, मोबाइल नंबर (OTP सत्यापन के लिए) अथवा ईमेल का उपयोग करते हैं। हम किसी भी उपयोगकर्ता का पासवर्ड प्लेन टेक्स्ट में संग्रहीत नहीं करते।
              </p>
              <h4 className="font-bold text-sm text-emerald-600 mt-3">2. Google AdMob व कुकीज़:</h4>
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300">
                ऐप में प्रासंगिक विज्ञापन प्रदर्शित करने के लिए Google AdMob SDK का उपयोग किया जाता है। AdMob Google की मानक विज्ञापन नीतियों और सुरक्षा प्रोटोकॉल का अनुपालन करता है।
              </p>
              <h4 className="font-bold text-sm text-emerald-600 mt-3">3. डेटा सुरक्षा व Play Store नीतियां:</h4>
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300">
                हम Google Play Console की डेटा सुरक्षा (Data Safety) आवश्यकताओं का पूरी तरह पालन करते हैं। आपका डेटा कभी भी तीसरे पक्ष को नहीं बेचा जाता।
              </p>
            </div>
          )}

          {activePage === 'terms' && (
            <div>
              <h2 className="text-xl font-extrabold mb-3 flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-500" />
                <span>नियम और शर्तें (Terms of Service)</span>
              </h2>
              <p>
                GAMING BUZ ऐप का उपयोग करने पर आप निम्नलिखित शर्तों से बाध्य होते हैं:
              </p>
              <ul className="list-disc pl-5 space-y-2 text-xs sm:text-sm text-gray-600 dark:text-gray-300">
                <li>इस प्लेटफॉर्म पर प्रकाशित सभी लेख, विश्लेषण और वीडियो GAMING BUZ एवं संबंधित कंटेंट प्रदाताओं के कॉपीराइट के अधीन हैं।</li>
                <li>कमेंट सेक्शन में किसी भी प्रकार की अभद्र भाषा, जातिवादी अथवा आपत्तिजनक टिप्पणियां प्रतिबंधित हैं और तत्काल ब्लॉक की जाएंगी।</li>
                <li>लाइव क्रिकेट स्कोर सार्वजनिक स्पोर्ट्स एपीआई और आधिकारिक ब्रॉडकास्ट स्रोतों से संदर्भ हेतु संकलित किए जाते हैं।</li>
              </ul>
            </div>
          )}

          {activePage === 'contact' && (
            <div>
              <h2 className="text-xl font-extrabold mb-3 flex items-center gap-2">
                <Mail className="w-5 h-5 text-emerald-500" />
                <span>हमसे संपर्क करें (Contact Us)</span>
              </h2>
              <p className="text-xs sm:text-sm text-gray-500 mb-4">
                समाचार सुझाव, प्रतिक्रिया या विज्ञापन संबंधी पूछताछ के लिए हमारी संपादकीय टीम से संपर्क करें:
              </p>

              {contactSent ? (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-center">
                  <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-600 mb-2" />
                  <p className="font-bold">आपका संदेश सफलतापूर्वक भेज दिया गया है!</p>
                  <p className="text-xs mt-1">हमारी टीम 24 घंटे के भीतर आपसे संपर्क करेगी।</p>
                </div>
              ) : (
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    setContactSent(true);
                  }}
                  className="space-y-3"
                >
                  <div>
                    <label className="text-xs font-bold block mb-1">आपका नाम</label>
                    <input 
                      required 
                      type="text" 
                      placeholder="नाम दर्ज करें" 
                      className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                        isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                      }`}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold block mb-1">ईमेल या फोन</label>
                    <input 
                      required 
                      type="text" 
                      placeholder="ईमेल या मोबाइल नंबर" 
                      className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                        isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                      }`}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold block mb-1">संदेश या खबर का सुझाव</label>
                    <textarea 
                      required 
                      rows={3} 
                      placeholder="अपना संदेश यहाँ लिखें..." 
                      className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                        isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                      }`}
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs cursor-pointer shadow-xs"
                  >
                    संदेश भेजें (Submit)
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
