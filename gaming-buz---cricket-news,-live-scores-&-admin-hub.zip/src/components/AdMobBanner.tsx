import React, { useState } from 'react';
import { X, ExternalLink, Info } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';

interface AdMobBannerProps {
  placement?: 'home_feed' | 'article_bottom' | 'sticky_footer';
}

export const AdMobBanner: React.FC<AdMobBannerProps> = ({ placement = 'home_feed' }) => {
  const { isDarkMode, t } = useThemeLanguage();
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="my-6 w-full">
      <div className={`relative rounded-2xl border p-3 sm:p-4 flex flex-col sm:flex-row items-center justify-between gap-3 transition-colors ${
        isDarkMode 
          ? 'bg-gray-900/90 border-gray-800 text-gray-200' 
          : 'bg-amber-50/70 border-amber-200/80 text-gray-800'
      }`}>
        {/* Ad Label badge required by Google AdMob Policy */}
        <span className="absolute top-2 left-2 text-[9px] font-black tracking-widest uppercase px-1.5 py-0.5 rounded bg-gray-200 dark:bg-gray-800 text-gray-500">
          AD • GOOGLE ADMOB
        </span>

        {/* Close Button */}
        <button
          onClick={() => setDismissed(true)}
          className="absolute top-2 right-2 p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 text-gray-400 hover:text-gray-700 cursor-pointer"
          title="Close Ad"
        >
          <X className="w-3.5 h-3.5" />
        </button>

        <div className="pt-4 sm:pt-0 sm:pl-16 flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-white text-xl font-black shadow-md">
            🏏
          </div>
          <div>
            <h4 className="font-extrabold text-xs sm:text-sm">
              {t('क्रिकेट फैंटेसी प्रो - आज की अपनी ड्रीम टीम बनाएं!', 'Cricket Fantasy Pro - Build your match team today!')}
            </h4>
            <p className="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">
              {t('भारत बनाम इंग्लैंड मैच में हिस्सा लें और नकद पुरस्कार जीतें। (T&C Apply)', 'Join contest for IND vs ENG and win exciting rewards.')}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="https://play.google.com"
            target="_blank"
            rel="noreferrer"
            className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white transition-colors flex items-center gap-1 shadow-xs cursor-pointer"
          >
            <span>{t('अभी इंस्टॉल करें', 'Install Now')}</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
};
