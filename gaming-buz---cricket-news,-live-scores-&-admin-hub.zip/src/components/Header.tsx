import React from 'react';
import { 
  Flame, 
  Search, 
  Bell, 
  Bookmark, 
  Sun, 
  Moon, 
  User, 
  ShieldCheck, 
  Smartphone, 
  Download,
  Languages
} from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { useAuth } from '../context/AuthContext';
import { DeviceModel } from '../types';

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenBookmarks: () => void;
  onOpenNotifications: () => void;
  onOpenExportModal: () => void;
  unreadNotifsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSearch,
  onOpenBookmarks,
  onOpenNotifications,
  onOpenExportModal,
  unreadNotifsCount
}) => {
  const { language, toggleLanguage, isDarkMode, toggleDarkMode, deviceModel, setDeviceModel, t } = useThemeLanguage();
  const { user, isAdmin, openAuthModal, logout } = useAuth();

  return (
    <header className={`sticky top-0 z-40 transition-colors duration-200 border-b ${
      isDarkMode 
        ? 'bg-gray-900 border-gray-800 text-white' 
        : 'bg-white border-gray-200 text-gray-900 shadow-xs'
    }`}>
      {/* Device Mode Bar (when in testing / responsive toolbar) */}
      <div className={`px-4 py-1.5 text-xs border-b flex items-center justify-between flex-wrap gap-2 ${
        isDarkMode ? 'bg-gray-950 border-gray-800 text-gray-400' : 'bg-emerald-50 border-emerald-100 text-emerald-800'
      }`}>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 font-semibold text-emerald-600">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            GAMING BUZ
          </span>
          <span className="hidden sm:inline text-gray-400">|</span>
          <span className="hidden sm:inline">
            {t('यूनिवर्सल एंड्रॉइड कम्पैटिबिलिटी (Android 5.0 - 16+)', 'Universal Android Compatibility (API 21-35+)')}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Device Model Selector */}
          <div className="flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 opacity-70" />
            <select
              value={deviceModel}
              onChange={(e) => setDeviceModel(e.target.value as DeviceModel)}
              className={`text-xs rounded-md px-1.5 py-0.5 border font-medium cursor-pointer ${
                isDarkMode 
                  ? 'bg-gray-900 border-gray-700 text-gray-200' 
                  : 'bg-white border-emerald-200 text-emerald-900'
              }`}
              title="Preview device layout"
            >
              <option value="responsive">📱 Responsive Web</option>
              <option value="oneplus">🔴 OnePlus 7 / 11 (OxygenOS)</option>
              <option value="samsung">🔵 Samsung Galaxy S24 (One UI)</option>
              <option value="pixel">⚪ Google Pixel 8 (Stock Android)</option>
              <option value="redmi">🟠 Xiaomi / Redmi (HyperOS)</option>
              <option value="tablet">💻 10" Android Tablet</option>
            </select>
          </div>

          {/* Android APK & Source code export */}
          <button
            onClick={onOpenExportModal}
            className="flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors cursor-pointer"
            title="Download Android Kotlin Studio project & APK build files"
          >
            <Download className="w-3 h-3" />
            <span>APK / Project</span>
          </button>
        </div>
      </div>

      {/* Main App Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
        {/* Logo & Brand */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 group cursor-pointer">
            <div className="w-10 h-10 rounded-xl bg-linear-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 ring-2 ring-emerald-500/30">
              <span className="text-xl">🏏</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight bg-linear-to-r from-emerald-600 via-teal-700 to-blue-700 bg-clip-text text-transparent">
                  GAMING BUZ
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-red-100 text-red-700 uppercase tracking-wider animate-pulse">
                  LIVE
                </span>
              </div>
              <p className="text-[10.5px] leading-tight font-medium text-gray-500">
                {t('क्रिकेट समाचार, लाइव स्कोर व विश्लेषण', 'Cricket News, Live Scores & Insights')}
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Language Toggle (Hindi / English) */}
          <button
            onClick={toggleLanguage}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              language === 'hi'
                ? 'bg-emerald-50 border-emerald-300 text-emerald-700 dark:bg-emerald-950/50 dark:border-emerald-700 dark:text-emerald-300'
                : 'bg-blue-50 border-blue-300 text-blue-700 dark:bg-blue-950/50 dark:border-blue-700 dark:text-blue-300'
            }`}
            title="Toggle Language (हिंदी / English)"
          >
            <Languages className="w-3.5 h-3.5" />
            <span>{language === 'hi' ? 'हिंदी' : 'English'}</span>
          </button>

          {/* Theme Toggle (Light White Theme vs Dark) */}
          <button
            onClick={toggleDarkMode}
            className={`p-2 rounded-lg border transition-colors cursor-pointer ${
              isDarkMode 
                ? 'bg-gray-800 border-gray-700 text-amber-400 hover:bg-gray-700' 
                : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'
            }`}
            title={isDarkMode ? 'Switch to White Theme' : 'Switch to Dark Mode'}
            aria-label="Toggle theme"
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Search Trigger */}
          <button
            onClick={onOpenSearch}
            className={`p-2 rounded-lg border transition-colors cursor-pointer ${
              isDarkMode 
                ? 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700' 
                : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'
            }`}
            title={t('खोजें (Search)', 'Search')}
            aria-label="Search"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Bookmarks */}
          <button
            onClick={onOpenBookmarks}
            className={`p-2 rounded-lg border transition-colors cursor-pointer ${
              isDarkMode 
                ? 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700' 
                : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'
            }`}
            title={t('सेव की गई खबरें (Bookmarks)', 'Bookmarks')}
            aria-label="Bookmarks"
          >
            <Bookmark className="w-4 h-4" />
          </button>

          {/* Notifications */}
          <button
            onClick={onOpenNotifications}
            className={`relative p-2 rounded-lg border transition-colors cursor-pointer ${
              isDarkMode 
                ? 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700' 
                : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'
            }`}
            title={t('सूचनाएं (Notifications)', 'Notifications')}
            aria-label="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadNotifsCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center animate-bounce">
                {unreadNotifsCount}
              </span>
            )}
          </button>

          {/* User / Admin Authentication State */}
          {user ? (
            <div className="flex items-center gap-1.5 pl-1">
              <div className="relative group">
                <button
                  onClick={() => openAuthModal('user')}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer ${
                    isAdmin
                      ? 'bg-amber-500/10 border-amber-500/30 text-amber-600 dark:text-amber-400'
                      : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
                  }`}
                >
                  {isAdmin ? <ShieldCheck className="w-3.5 h-3.5 text-amber-500" /> : <User className="w-3.5 h-3.5" />}
                  <span className="max-w-[80px] sm:max-w-[120px] truncate">{user.name}</span>
                  {isAdmin && (
                    <span className="text-[10px] font-extrabold px-1.5 py-0.2 bg-amber-500 text-white rounded">
                      ADMIN
                    </span>
                  )}
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => openAuthModal('user')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs cursor-pointer transition-colors"
            >
              <User className="w-3.5 h-3.5" />
              <span>{t('लॉगिन', 'Login')}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
