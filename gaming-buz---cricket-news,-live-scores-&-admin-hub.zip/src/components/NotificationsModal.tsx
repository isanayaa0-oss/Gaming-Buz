import React from 'react';
import { Bell, X, Flame, Radio, CheckCheck } from 'lucide-react';
import { useThemeLanguage } from '../context/ThemeLanguageContext';
import { PushNotification, NewsItem } from '../types';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: PushNotification[];
  onSelectArticle: (articleId: string) => void;
  onMarkAllAsRead: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  notifications,
  onSelectArticle,
  onMarkAllAsRead
}) => {
  const { isDarkMode, t } = useThemeLanguage();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-14 sm:pt-20 p-3 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className={`w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border flex flex-col max-h-[85vh] ${
        isDarkMode ? 'bg-gray-900 border-gray-800 text-gray-100' : 'bg-white border-gray-200 text-gray-900'
      }`}>
        {/* Header */}
        <div className="p-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-emerald-500" />
            <h3 className="font-extrabold text-base">
              {t('सूचनाएं व पुश अलर्ट (Notifications)', 'Notifications & Alerts')}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onMarkAllAsRead}
              className="text-xs text-emerald-600 hover:underline flex items-center gap-1 font-semibold cursor-pointer"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>{t('सभी पढ़ें', 'Mark all read')}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* List */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3">
          {notifications.length > 0 ? (
            notifications.map(notif => (
              <div
                key={notif.id}
                onClick={() => {
                  if (notif.articleId) {
                    onSelectArticle(notif.articleId);
                    onClose();
                  }
                }}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                  notif.isRead 
                    ? isDarkMode ? 'bg-gray-800/30 border-gray-800' : 'bg-gray-50 border-gray-100'
                    : isDarkMode ? 'bg-emerald-950/20 border-emerald-900/60' : 'bg-emerald-50/70 border-emerald-200'
                }`}
              >
                <div className="flex items-center justify-between text-xs mb-1">
                  <div className="flex items-center gap-1.5 font-bold">
                    {notif.type === 'breaking' ? (
                      <Flame className="w-3.5 h-3.5 text-red-500" />
                    ) : (
                      <Radio className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
                    )}
                    <span className={notif.type === 'breaking' ? 'text-red-500' : 'text-emerald-600'}>
                      {notif.title}
                    </span>
                  </div>
                  <span className="text-[10px] text-gray-400">{notif.time}</span>
                </div>
                <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                  {notif.body}
                </p>
              </div>
            ))
          ) : (
            <div className="text-center py-12 text-gray-400">
              <p className="text-sm">{t('कोई नई सूचना नहीं है।', 'No new notifications.')}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
