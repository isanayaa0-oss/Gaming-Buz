import { NewsItem, CricketMatch, DomesticTournament, IPLTeamStanding, VideoItem, PushNotification } from '../types';

export const INITIAL_NEWS: NewsItem[] = [
  {
    id: 'news-1',
    titleHi: 'रोहित शर्मा और विराट कोहली का बड़ा फैसला: युवाओं को मौका देने की बनी नई रणनीति',
    titleEn: 'Rohit Sharma & Virat Kohli Masterplan: Fresh Strategy to Groom Young Cricketers',
    summaryHi: 'बीसीसीआई और टीम मैनेजमेंट की उच्च स्तरीय बैठक में आगामी आईसीसी टूर्नामेंट्स के लिए भारतीय क्रिकेट के नए रोडमैप पर मुहर लगी।',
    summaryEn: 'BCCI and team management finalize a strategic roadmap to transition promising domestic and IPL youngsters into the national squad.',
    contentHi: `भारतीय क्रिकेट टीम के कप्तान रोहित शर्मा और दिग्गज बल्लेबाज विराट कोहली ने आगामी विश्व कप और अंतरराष्ट्रीय सीरीज को ध्यान में रखते हुए टीम के भविष्य का रोडमैप तैयार किया है।

बीसीसीआई सचिव और मुख्य चयनकर्ताओं के साथ हुई समीक्षा बैठक में यह निर्णय लिया गया कि घरेलू क्रिकेट (रणजी ट्रॉफी, विजय हजारे और सैयद मुश्ताक अली ट्रॉफी) में निरंतर 3 सीजन तक असाधारण प्रदर्शन करने वाले खिलाड़ियों को सीधे राष्ट्रीय टीम कैंप में शामिल किया जाएगा।

रोहित शर्मा ने कहा, "हमारी प्राथमिकता अगली पीढ़ी के मैच विनर्स तैयार करना है। टीम में नए युवा तेज गेंदबाज और ऑलराउंडर्स को पर्याप्त मौके दिए जाएंगे।"

विराट कोहली ने फिटनेस कल्चर पर जोर देते हुए कहा कि घरेलू स्तर पर भी यो-यो टेस्ट और आधुनिक रिकवरी प्रोटोकॉल अनिवार्य कर दिए गए हैं।`,
    contentEn: `Indian cricket captain Rohit Sharma and star batsman Virat Kohli have laid out an ambitious long-term roadmap focusing on transitioning top domestic performers to international cricket.

During a high-level review with the selection committee, it was resolved that consistent performers across Ranji Trophy and Syed Mushtaq Ali tournaments will receive accelerated pathways to the national camp.

"Our goal is to build deep bench strength in both fast bowling and middle-order batsmanship," Rohit emphasized in the post-meeting briefing.`,
    category: 'team_india',
    subCategory: 'T20 & ODI',
    imageUrl: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=1200&q=80',
    additionalImages: [
      'https://images.unsplash.com/photo-1531415074868-036b107e775a?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1624526267942-ab0ff8a3e972?auto=format&fit=crop&w=800&q=80'
    ],
    isBreaking: true,
    isFeatured: true,
    publishedAt: new Date(Date.now() - 1000 * 60 * 35).toISOString(), // 35 mins ago
    author: 'राजेश शर्मा (विशेष संवाददाता)',
    views: 18450,
    likes: 1240,
    status: 'published',
    tags: ['Team India', 'Rohit Sharma', 'Virat Kohli', 'BCCI', 'Selection']
  },
  {
    id: 'news-2',
    titleHi: 'रणजी ट्रॉफी फाइनल: मुंबई ने विदर्भ को रोमांचक मुकाबले में हराया, 42वीं बार चैंपियन बनने का रचा इतिहास',
    titleEn: 'Ranji Trophy Final: Mumbai Clinches Historic 42nd Title Defeating Vidarbha in Thriller',
    summaryHi: 'वानखेड़े स्टेडियम में खेले गए ऐतिहासिक फाइनल में मुंबई के गेंदबाजों का कहर, मुशीर खान और तनुष कोटियान बने जीत के हीरो।',
    summaryEn: 'Musheer Khan century and heroic spells from Mumbai bowlers seal the premier first-class domestic crown once again.',
    contentHi: `मुंबई की रणजी टीम ने एक बार फिर साबित कर दिया कि वे भारतीय घरेलू क्रिकेट के बेताज बादशाह क्यों हैं। विदर्भ के खिलाफ खेले गए रणजी ट्रॉफी के फाइनल में मुंबई ने 169 रनों से ऐतिहासिक जीत दर्ज कर 42वीं बार प्रतिष्ठित ट्रॉफी पर कब्जा किया।

मैच के चौथे दिन विदर्भ को जीत के लिए 538 रनों का विशाल लक्ष्य मिला था, जिसके जवाब में टीम 368 रनों पर सिमट गई।

मुंबई के युवा सनसनी मुशीर खान को फाइनल में शतकीय पारी और मैच जिताऊ पार्टनरशिप के लिए 'प्लेयर ऑफ द मैच' चुना गया। अजिंक्य रहाणे की कप्तानी की भी जमकर सराहना की गई।

बीसीसीआई ने मुंबई क्रिकेट एसोसिएशन (MCA) को 5 करोड़ रुपये का नकद पुरस्कार और विदर्भ को 3 करोड़ रुपये देने की घोषणा की।`,
    contentEn: `Mumbai continued their unmatched supremacy in Indian domestic cricket by lifting their 42nd Ranji Trophy title, besting Vidarbha by 169 runs at the historic Wankhede Stadium.

Musheer Khan was adjudged Player of the Match for his gritty fourth-innings century, while captain Ajinkya Rahane praised the discipline of the spin-attack in defending the total.`,
    category: 'domestic',
    subCategory: 'Ranji Trophy',
    imageUrl: 'https://images.unsplash.com/photo-1589487391730-58f20eb2c308?auto=format&fit=crop&w=1200&q=80',
    additionalImages: [
      'https://images.unsplash.com/photo-1512719994953-eabf50895df7?auto=format&fit=crop&w=800&q=80'
    ],
    isBreaking: false,
    isFeatured: true,
    publishedAt: new Date(Date.now() - 1000 * 60 * 95).toISOString(),
    author: 'अमित वर्मा (घरेलू क्रिकेट विशेषज्ञ)',
    views: 14210,
    likes: 890,
    status: 'published',
    tags: ['Ranji Trophy', 'Mumbai Cricket', 'Vidarbha', 'Domestic Cricket', 'Musheer Khan']
  },
  {
    id: 'news-3',
    titleHi: 'IPL 2026: चेन्नई सुपर किंग्स vs मुंबई इंडियंस - महामुकाबले से पहले दोनों टीमों की संभावित प्लेइंग 11',
    titleEn: 'IPL 2026: CSK vs MI El Clasico - Probable Playing XI, Pitch Report & Head-to-Head Analysis',
    summaryHi: 'चेपॉक के एमए चिदंबरम स्टेडियम में कल शाम 7:30 बजे होगा महामुकाबला। स्पिन फ्रेंडली ट्रैक पर धोनी और रोहित की रणनीति पर टिकी निगाहें।',
    summaryEn: 'The biggest rivalry in IPL resumes at Chepauk as CSK host MI with playoff qualifications on the line.',
    contentHi: `आईपीएल 2026 का सबसे बड़ा मुकाबला कल शाम चेन्नई के एमए चिदंबरम स्टेडियम (चेपॉक) में चेन्नई सुपर किंग्स (CSK) और मुंबई इंडियंस (MI) के बीच खेला जाएगा।

पिच रिपोर्ट: चेपॉक की पिच हमेशा की तरह धीमी और स्पिनरों के अनुकूल रहने की संभावना है। ओस (Dew) दूसरी पारी में निर्णायक भूमिका निभा सकती है, इसलिए टॉस जीतने वाला कप्तान पहले गेंदबाजी करना पसंद करेगा।

CSK की संभावित 11:
रुतुराज गायकवाड़ (कप्तान), रचिन रवींद्र, अजिंक्य रहाणे, शिवम दुबे, डेरिल मिचेल, एमएस धोनी (विकेटकीपर), रवींद्र जडेजा, शार्दुल ठाकुर, दीपक चाहर, तुषार देशपांडे, महीश तीक्ष्णा।

MI की संभावित 11:
रोहित शर्मा, ईशान किशन (विकेटकीपर), सूर्यकुमार यादव, तिलक वर्मा, हार्दिक पांड्या (कप्तान), टिम डेविड, मोहम्मद नबी, गेराल्ड कोएट्जी, पीयूष चावला, जसप्रीत बुमराह, आकाश मधवाल।`,
    contentEn: `The classic rivalry of the Indian Premier League takes center stage as Chennai Super Kings take on Mumbai Indians at Chepauk.

Pitch conditions indicate slow-turning surface with spin likely to dominate the middle overs. Bumrah vs Dube and Ruturaj vs Coetzee promise key tactical matchups.`,
    category: 'ipl',
    subCategory: 'CSK vs MI',
    imageUrl: 'https://images.unsplash.com/photo-1531415074868-036b107e775a?auto=format&fit=crop&w=1200&q=80',
    additionalImages: [
      'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=800&q=80'
    ],
    isBreaking: false,
    isFeatured: true,
    publishedAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    author: 'सुनील कश्यप',
    views: 29500,
    likes: 2150,
    status: 'published',
    tags: ['IPL 2026', 'CSK', 'MI', 'MS Dhoni', 'Rohit Sharma', 'Hardik Pandya']
  },
  {
    id: 'news-4',
    titleHi: 'महिला क्रिकेट: हरमनप्रीत कौर और स्मृति मंधाना की धमाकेदार साझेदारी, भारत ने ऑस्ट्रेलिया को रौंदा',
    titleEn: 'Womens Cricket: Harmanpreet & Mandhana Masterclass Guides India to Decisive Victory Over Australia',
    summaryHi: 'मुंबई के डीवाई पाटिल स्टेडियम में भारतीय महिला टीम ने दिखाया दम, रिकॉर्ड रन चेज कर सीरीज में बनाई अपराजेय बढ़त।',
    summaryEn: 'India Women cruise to victory in the third T20I with a dominant 120-run opening stand.',
    contentHi: `भारतीय महिला क्रिकेट टीम ने मुंबई में खेले गए तीसरे टी20 मुकाबले में विश्व चैंपियन ऑस्ट्रेलिया को 7 विकेट से करारी शिकस्त दी।

स्मृति मंधाना ने 45 गेंदों में 82 रनों की आतिशी पारी खेली, जिसमें 9 चौके और 3 गगनचुंबी छक्के शामिल थे। कप्तान हरमनप्रीत कौर ने 34 गेंदों पर नाबाद 54 रन बनाकर टीम को 18.4 ओवर में जीत दिला दी।

गेंदबाजी में रेणुका सिंह ठाकुर और दीप्ति शर्मा ने 2-2 विकेट चटकाकर ऑस्ट्रेलियाई टीम को 168 रनों पर रोक दिया था। स्मृति मंधाना को उनकी शानदार पारी के लिए प्लेयर ऑफ द मैच का खिताब दिया गया।`,
    contentEn: `The Indian Women's Cricket team produced a clinical all-round performance to defeat Australia Women by 7 wickets at the DY Patil Stadium.

Smriti Mandhana played a blistering knock of 82 off 45 deliveries, while Harmanpreet Kaur sealed the chase with a calm unbeaten fifty.`,
    category: 'team_india',
    subCategory: 'Women Cricket',
    imageUrl: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=1200&q=80',
    isBreaking: false,
    isFeatured: false,
    publishedAt: new Date(Date.now() - 1000 * 60 * 240).toISOString(),
    author: 'प्रिया नायर',
    views: 9400,
    likes: 640,
    status: 'published',
    tags: ['Team India', 'Women Cricket', 'Smriti Mandhana', 'Harmanpreet Kaur']
  },
  {
    id: 'news-5',
    titleHi: 'विजय हजारे ट्रॉफी: यशस्वी जायसवाल ने 112 गेंदों में ठोका दोहरा शतक, 16 छक्कों से मचाया कोहराम',
    titleEn: 'Vijay Hazare Trophy: Yashasvi Jaiswal Smashes Record Double Century with 16 Towering Sixes',
    summaryHi: 'घरेलू वनडे टूर्नामेंट में मुंबई की तरफ से खेलते हुए यशस्वी ने तोड़े कई रिकॉर्ड, चयनकर्ताओं की खुली आंखें।',
    summaryEn: 'Yashasvi Jaiswal lights up domestic List A cricket with an astonishing double hundred in Bengaluru.',
    contentHi: `भारत के युवा सलामी बल्लेबाज यशस्वी जायसवाल ने विजय हजारे ट्रॉफी में इतिहास रचते हुए मात्र 112 गेंदों में 204 रनों की तूफानी पारी खेली। उनकी पारी में 18 चौके और 16 विशाल छक्के शामिल रहे।

जायसवाल ने शुरुआत से ही आक्रामक रुख अपनाया और विपक्षी गेंदबाजों की जमकर खबर ली। उन्होंने अपने पहले 100 रन 62 गेंदों में और अगले 100 रन मात्र 45 गेंदों में पूरे किए।

इस प्रदर्शन के बाद पूर्व मुख्य चयनकर्ता एमएसके प्रसाद ने कहा, "यशस्वी की निरंतरता और तीनों फॉर्मेट में खेलने की क्षमता उन्हें विश्व स्तर पर सबसे खतरनाक बल्लेबाज बनाती है।"`,
    contentEn: `Indian dynamic opener Yashasvi Jaiswal continued his sensational run of form by bludgeoning a 112-ball 204 in the Vijay Hazare Trophy, marking one of the fastest List-A double centuries in Indian cricket history.`,
    category: 'domestic',
    subCategory: 'Vijay Hazare Trophy',
    imageUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=1200&q=80',
    isBreaking: false,
    isFeatured: false,
    publishedAt: new Date(Date.now() - 1000 * 60 * 360).toISOString(),
    author: 'अमित वर्मा',
    views: 11200,
    likes: 980,
    status: 'published',
    tags: ['Vijay Hazare Trophy', 'Yashasvi Jaiswal', 'Domestic Cricket', 'Record']
  },
  {
    id: 'news-6',
    titleHi: 'ICC वर्ल्ड टेस्ट चैंपियनशिप: इंग्लैंड ने लॉर्ड्स में ऑस्ट्रेलिया को हराया, पॉइंट्स टेबल में बड़ा उलटफेर',
    titleEn: 'ICC World Test Championship: England Edges Australia at Lords; Points Table Shaken Up',
    summaryHi: 'बेन स्टोक्स की बैजबॉल रणनीति ने फिर किया कमाल, 5वें दिन के अंतिम सत्र में मार्क वुड की तूफानी गेंदबाजी से पलटा मैच।',
    summaryEn: 'Mark Wood four-wicket burst on day five seals a 43-run win for England in an Ashes classic.',
    contentHi: `आईसीसी वर्ल्ड टेस्ट चैंपियनशिप (WTC) के तहत लॉर्ड्स क्रिकेट ग्राउंड पर खेले गए रोमांचक टेस्ट मैच में इंग्लैंड ने ऑस्ट्रेलिया को 43 रनों से पराजित किया।

इस जीत के साथ इंग्लैंड WTC 2025-27 की अंकतालिका में तीसरे स्थान पर पहुंच गया है, जबकि भारत पहले स्थान पर अपनी बढ़त बनाए हुए है।

मार्क वुड को अंतिम पारी में 150 किमी/घंटे की रफ्तार से की गई रिवर्स स्विंग गेंदबाजी के लिए मैन ऑफ द मैच घोषित किया गया।`,
    contentEn: `In an enthralling conclusion at Lord's, England bowled out Australia for 274 in pursuit of 318, keeping their ICC World Test Championship final hopes vibrant.`,
    category: 'international',
    subCategory: 'WTC / Ashes',
    imageUrl: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=1200&q=80',
    isBreaking: false,
    isFeatured: false,
    publishedAt: new Date(Date.now() - 1000 * 60 * 480).toISOString(),
    author: 'क्रिकेट डेस्क',
    views: 8200,
    likes: 490,
    status: 'published',
    tags: ['International Cricket', 'WTC', 'England', 'Australia', 'Ben Stokes']
  }
];

export const INITIAL_MATCHES: CricketMatch[] = [
  {
    id: 'match-1',
    series: 'India vs Australia T20I Series 2026 (3rd Match)',
    matchType: 'T20',
    team1: {
      id: 'ind',
      nameHi: 'भारत',
      nameEn: 'India',
      shortName: 'IND',
      flag: '🇮🇳',
      score: '188/3',
      overs: '18.2'
    },
    team2: {
      id: 'aus',
      nameHi: 'ऑस्ट्रेलिया',
      nameEn: 'Australia',
      shortName: 'AUS',
      flag: '🇦🇺',
      score: '184/7',
      overs: '20.0'
    },
    status: 'live',
    statusTextHi: 'भारत को 10 गेंदों में 2 रन चाहिए',
    statusTextEn: 'India need 2 runs in 10 balls',
    venueHi: 'नरेंद्र मोदी स्टेडियम, अहमदाबाद',
    venueEn: 'Narendra Modi Stadium, Ahmedabad',
    startTime: 'Today, 7:00 PM IST',
    tossHi: 'भारत ने टॉस जीतकर पहले गेंदबाजी चुनी',
    tossEn: 'India won the toss and elected to field',
    currentInnings: 2,
    currentBatsmen: [
      { name: 'हार्दिक पांड्या', runs: 34, balls: 14 },
      { name: 'सूर्यकुमार यादव', runs: 68, balls: 38 }
    ],
    currentBowler: { name: 'पैट कमिंस', figures: '3.2-0-38-1' },
    target: 185,
    requiredRate: '1.20',
    recentBalls: ['1', '4', '6', '1', '2', '4'],
    innings: [
      {
        teamName: 'Australia',
        teamShort: 'AUS',
        score: '184/7',
        overs: '20.0',
        batting: [
          { name: 'ट्रेविस हेड', runs: 54, balls: 28, fours: 6, sixes: 3, strikeRate: 192.8, dismissal: 'c रोहित b बुमराह', isOut: true },
          { name: 'मिचेल मार्श', runs: 38, balls: 26, fours: 4, sixes: 1, strikeRate: 146.1, dismissal: 'b कुलदीप', isOut: true },
          { name: 'ग्लेन मैक्सवेल', runs: 42, balls: 21, fours: 3, sixes: 4, strikeRate: 200.0, dismissal: 'c जडेजा b अर्शदीप', isOut: true },
          { name: 'टिम डेविड', runs: 18, balls: 12, fours: 1, sixes: 1, strikeRate: 150.0, dismissal: 'not out', isOut: false }
        ],
        bowling: [
          { name: 'जसप्रीत बुमराह', overs: '4.0', maidens: 0, runs: 28, wickets: 2, economy: 7.0 },
          { name: 'अर्शदीप सिंह', overs: '4.0', maidens: 0, runs: 39, wickets: 2, economy: 9.75 },
          { name: 'कुलदीप यादव', overs: '4.0', maidens: 0, runs: 31, wickets: 2, economy: 7.75 },
          { name: 'हार्दिक पांड्या', overs: '4.0', maidens: 0, runs: 44, wickets: 1, economy: 11.0 }
        ]
      },
      {
        teamName: 'India',
        teamShort: 'IND',
        score: '188/3',
        overs: '18.2',
        batting: [
          { name: 'रोहित शर्मा', runs: 32, balls: 19, fours: 4, sixes: 2, strikeRate: 168.4, dismissal: 'b स्टार्क', isOut: true },
          { name: 'शुभमन गिल', runs: 45, balls: 31, fours: 5, sixes: 1, strikeRate: 145.1, dismissal: 'c कैरी b ज़म्पा', isOut: true },
          { name: 'सूर्यकुमार यादव', runs: 68, balls: 38, fours: 6, sixes: 4, strikeRate: 178.9, dismissal: 'not out', isOut: false },
          { name: 'हार्दिक पांड्या', runs: 34, balls: 14, fours: 3, sixes: 2, strikeRate: 242.8, dismissal: 'not out', isOut: false }
        ],
        bowling: [
          { name: 'मिचेल स्टार्क', overs: '4.0', maidens: 0, runs: 42, wickets: 1, economy: 10.5 },
          { name: 'पैट कमिंस', overs: '3.2', maidens: 0, runs: 38, wickets: 1, economy: 11.4 },
          { name: 'एडम ज़म्पा', overs: '4.0', maidens: 0, runs: 34, wickets: 1, economy: 8.5 }
        ]
      }
    ]
  },
  {
    id: 'match-2',
    series: 'IPL 2026 (Match 18)',
    matchType: 'IPL',
    team1: {
      id: 'csk',
      nameHi: 'चेन्नई सुपर किंग्स',
      nameEn: 'Chennai Super Kings',
      shortName: 'CSK',
      flag: '🦁',
      score: '142/2',
      overs: '14.0'
    },
    team2: {
      id: 'mi',
      nameHi: 'मुंबई इंडियंस',
      nameEn: 'Mumbai Indians',
      shortName: 'MI',
      flag: '⚡',
      score: '178/6',
      overs: '20.0'
    },
    status: 'live',
    statusTextHi: 'CSK को 36 गेंदों में 37 रन चाहिए',
    statusTextEn: 'CSK need 37 runs in 36 balls',
    venueHi: 'एमए चिदंबरम स्टेडियम, चेन्नई (चेपॉक)',
    venueEn: 'MA Chidambaram Stadium, Chennai',
    startTime: 'Today, 7:30 PM IST',
    tossHi: 'चेन्नई ने टॉस जीतकर पहले गेंदबाजी चुनी',
    tossEn: 'CSK won the toss and elected to field',
    currentInnings: 2,
    currentBatsmen: [
      { name: 'रुतुराज गायकवाड़', runs: 62, balls: 44 },
      { name: 'शिवम दुबे', runs: 31, balls: 16 }
    ],
    currentBowler: { name: 'जसप्रीत बुमराह', figures: '3.0-0-21-1' },
    target: 179,
    requiredRate: '6.16',
    recentBalls: ['1', '6', '4', '0', '1', '2']
  },
  {
    id: 'match-3',
    series: 'Ranji Trophy 2025-26 (Final)',
    matchType: 'DOMESTIC',
    team1: {
      id: 'mum',
      nameHi: 'मुंबई',
      nameEn: 'Mumbai',
      shortName: 'MUM',
      flag: '🏏',
      score: '418 & 287'
    },
    team2: {
      id: 'vid',
      nameHi: 'विदर्भ',
      nameEn: 'Vidarbha',
      shortName: 'VID',
      flag: '🏏',
      score: '345 & 220'
    },
    status: 'completed',
    statusTextHi: 'मुंबई ने विदर्भ को 140 रनों से हराया (चैंपियन)',
    statusTextEn: 'Mumbai won by 140 runs (Champions)',
    venueHi: 'वानखेड़े स्टेडियम, मुंबई',
    venueEn: 'Wankhede Stadium, Mumbai',
    startTime: 'Match Ended'
  },
  {
    id: 'match-4',
    series: 'India Tour of England 2026 (1st ODI)',
    matchType: 'ODI',
    team1: {
      id: 'ind',
      nameHi: 'भारत',
      nameEn: 'India',
      shortName: 'IND',
      flag: '🇮🇳'
    },
    team2: {
      id: 'eng',
      nameHi: 'इंग्लैंड',
      nameEn: 'England',
      shortName: 'ENG',
      flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿'
    },
    status: 'upcoming',
    statusTextHi: 'कल दोपहर 1:30 बजे शुरू होगा',
    statusTextEn: 'Starts tomorrow at 1:30 PM IST',
    venueHi: 'लॉर्ड्स क्रिकेट ग्राउंड, लंदन',
    venueEn: 'Lords Cricket Ground, London',
    startTime: 'Tomorrow, 1:30 PM IST'
  }
];

export const DOMESTIC_TOURNAMENTS: DomesticTournament[] = [
  {
    id: 'ranji',
    nameHi: 'रणजी ट्रॉफी (Ranji Trophy)',
    nameEn: 'Ranji Trophy',
    descriptionHi: 'भारत की प्रमुख प्रथम श्रेणी (First-Class) घरेलू क्रिकेट प्रतियोगिता। 1934 से आयोजित, 38 टीमें भाग लेती हैं।',
    descriptionEn: 'The premier domestic first-class cricket championship played in India, contested by 38 state and regional associations.',
    trophyType: 'FirstClass',
    currentChampion: 'मुंबई (42वां खिताब)',
    table: [
      { team: 'मुंबई (Mumbai)', played: 7, won: 5, lost: 0, draw: 2, points: 34 },
      { team: 'विदर्भ (Vidarbha)', played: 7, won: 4, lost: 1, draw: 2, points: 28 },
      { team: 'तमिलनाडु (Tamil Nadu)', played: 7, won: 4, lost: 1, draw: 2, points: 27 },
      { team: 'कर्नाटक (Karnataka)', played: 7, won: 3, lost: 1, draw: 3, points: 24 },
      { team: 'सौराष्ट्र (Saurashtra)', played: 7, won: 3, lost: 2, draw: 2, points: 21 },
      { team: 'दिल्ली (Delhi)', played: 7, won: 2, lost: 3, draw: 2, points: 16 }
    ],
    topPerformers: [
      { player: 'मुशीर खान (मुंबई)', team: 'मुंबई', stat: '824 रन (औसत 68.6)', role: 'बल्लेबाज' },
      { player: 'तनुष कोटियान (मुंबई)', team: 'मुंबई', stat: '42 विकेट + 480 रन', role: 'ऑलराउंडर' },
      { player: 'आदित्य सरवटे (विदर्भ)', team: 'विदर्भ', stat: '45 विकेट', role: 'स्पिन गेंदबाज' }
    ]
  },
  {
    id: 'vijay_hazare',
    nameHi: 'विजय हजारे ट्रॉफी (Vijay Hazare Trophy)',
    nameEn: 'Vijay Hazare Trophy (One Day)',
    descriptionHi: 'भारतीय घरेलू 50-ओवर लिस्ट-ए क्रिकेट प्रतियोगिता। अंतरराष्ट्रीय चयन के लिए सबसे अहम वनडे टूर्नामेंट।',
    descriptionEn: 'India premier List-A domestic 50-overs one-day tournament determining white-ball national selection.',
    trophyType: 'ListA',
    currentChampion: 'हरियाणा',
    table: [
      { team: 'हरियाणा (Haryana)', played: 6, won: 6, lost: 0, points: 24, nrr: '+1.45' },
      { team: 'राजस्थान (Rajasthan)', played: 6, won: 5, lost: 1, points: 20, nrr: '+1.12' },
      { team: 'महाराष्ट्र (Maharashtra)', played: 6, won: 4, lost: 2, points: 16, nrr: '+0.78' },
      { team: 'कर्नाटक (Karnataka)', played: 6, won: 4, lost: 2, points: 16, nrr: '+0.54' }
    ],
    topPerformers: [
      { player: 'यशस्वी जायसवाल', team: 'मुंबई', stat: '680 रन (स्ट्राइक रेट 122)', role: 'सलामी बल्लेबाज' },
      { player: 'युजवेंद्र चहल', team: 'हरियाणा', stat: '19 विकेट (इकोनॉमी 3.8)', role: 'लेग स्पिनर' }
    ]
  },
  {
    id: 'smat',
    nameHi: 'सैयद मुश्ताक अली ट्रॉफी (Syed Mushtaq Ali Trophy - T20)',
    nameEn: 'Syed Mushtaq Ali Trophy (SMAT T20)',
    descriptionHi: 'भारत की प्रमुख घरेलू टी20 लीग, जहाँ से आईपीएल और भारतीय टी20 टीम के लिए नए खिलाड़ी चुने जाते हैं।',
    descriptionEn: 'India premier inter-state domestic T20 tournament, the talent factory for IPL franchises and national T20 squad.',
    trophyType: 'T20',
    currentChampion: 'पंजाब',
    table: [
      { team: 'पंजाब (Punjab)', played: 7, won: 6, lost: 1, points: 24, nrr: '+1.82' },
      { team: 'बड़ौदा (Baroda)', played: 7, won: 5, lost: 2, points: 20, nrr: '+1.20' },
      { team: 'असम (Assam)', played: 7, won: 5, lost: 2, points: 20, nrr: '+0.95' },
      { team: 'उत्तर प्रदेश (UP)', played: 7, won: 4, lost: 3, points: 16, nrr: '+0.42' }
    ],
    topPerformers: [
      { player: 'अभिषेक शर्मा (पंजाब)', team: 'पंजाब', stat: '485 रन (स्ट्राइक रेट 198.5)', role: 'विस्फोटक ओपनर' },
      { player: 'अतीत शेठ (बड़ौदा)', team: 'बड़ौदा', stat: '18 विकेट', role: 'तेज गेंदबाज' }
    ]
  },
  {
    id: 'duleep',
    nameHi: 'दलीप ट्रॉफी (Duleep Trophy)',
    nameEn: 'Duleep Trophy (Zonal)',
    descriptionHi: 'भारतीय क्षेत्रीय टीमों (नॉर्थ, साउथ, ईस्ट, वेस्ट, सेंट्रल, नॉर्थ-ईस्ट) के बीच खेला जाने वाला प्रतिष्ठित फर्स्ट-क्लास टूर्नामेंट।',
    descriptionEn: 'First-class zonal cricket tournament representing six geographical zones of India.',
    trophyType: 'FirstClass',
    currentChampion: 'साउथ ज़ोन (South Zone)',
    table: [
      { team: 'साउथ ज़ोन (South Zone)', played: 3, won: 2, lost: 0, draw: 1, points: 15 },
      { team: 'वेस्ट ज़ोन (West Zone)', played: 3, won: 2, lost: 1, draw: 0, points: 12 },
      { team: 'सेंट्रल ज़ोन (Central Zone)', played: 3, won: 1, lost: 1, draw: 1, points: 8 }
    ],
    topPerformers: [
      { player: 'हनुमा विहारी (साउथ ज़ोन)', team: 'साउथ ज़ोन', stat: '412 रन', role: 'मध्यक्रम बल्लेबाज' },
      { player: 'विद्वथ कवेरप्पा', team: 'साउथ ज़ोन', stat: '16 विकेट', role: 'तेज गेंदबाज' }
    ]
  },
  {
    id: 'irani_cup',
    nameHi: 'ईरानी कप (Irani Cup)',
    nameEn: 'Irani Cup',
    descriptionHi: 'रणजी ट्रॉफी चैंपियन टीम और शेष भारत (Rest of India) टीम के बीच खेला जाने वाला वार्षिक प्रथम श्रेणी मैच।',
    descriptionEn: 'Annual first-class match played between current Ranji Trophy champions and Rest of India.',
    trophyType: 'FirstClass',
    currentChampion: 'शेष भारत (Rest of India)',
    table: [
      { team: 'Rest of India', played: 1, won: 1, lost: 0, points: 6 },
      { team: 'Mumbai (Ranji Champion)', played: 1, won: 0, lost: 1, points: 0 }
    ],
    topPerformers: [
      { player: 'अभिमन्यु ईश्वरन', team: 'Rest of India', stat: '154 रन', role: 'ओपनर' },
      { player: 'मुकेश कुमार', team: 'Rest of India', stat: '6 विकेट', role: 'फास्ट बॉलर' }
    ]
  }
];

export const IPL_STANDINGS: IPLTeamStanding[] = [
  { position: 1, team: 'कोलकाता नाइट राइडर्स', shortName: 'KKR', played: 12, won: 9, lost: 3, nrr: '+1.428', points: 18, logo: '💜' },
  { position: 2, team: 'राजस्थान रॉयल्स', shortName: 'RR', played: 12, won: 8, lost: 4, nrr: '+0.890', points: 16, logo: '💖' },
  { position: 3, team: 'सनराइजर्स हैदराबाद', shortName: 'SRH', played: 12, won: 8, lost: 4, nrr: '+0.740', points: 16, logo: '🧡' },
  { position: 4, team: 'चेन्नई सुपर किंग्स', shortName: 'CSK', played: 12, won: 7, lost: 5, nrr: '+0.528', points: 14, logo: '💛' },
  { position: 5, team: 'रॉयल चैलेंजर्स बेंगलुरु', shortName: 'RCB', played: 12, won: 6, lost: 6, nrr: '+0.217', points: 12, logo: '❤️' },
  { position: 6, team: 'दिल्ली कैपिटल्स', shortName: 'DC', played: 12, won: 6, lost: 6, nrr: '-0.120', points: 12, logo: '💙' },
  { position: 7, team: 'लखनऊ सुपर जायंट्स', shortName: 'LSG', played: 12, won: 6, lost: 6, nrr: '-0.340', points: 12, logo: '🩵' },
  { position: 8, team: 'गुजरात टाइटंस', shortName: 'GT', played: 12, won: 5, lost: 7, nrr: '-0.450', points: 10, logo: '🔷' },
  { position: 9, team: 'पंजाब किंग्स', shortName: 'PBKS', played: 12, won: 4, lost: 8, nrr: '-0.620', points: 8, logo: '🔴' },
  { position: 10, team: 'मुंबई इंडियंस', shortName: 'MI', played: 12, won: 4, lost: 8, nrr: '-0.710', points: 8, logo: '💙' }
];

export const ORANGE_CAP_LEADERS = [
  { player: 'विराट कोहली (RCB)', runs: 741, matches: 15, avg: 61.75, sr: 154.6 },
  { player: 'रुतुराज गायकवाड़ (CSK)', runs: 583, matches: 14, avg: 53.00, sr: 141.2 },
  { player: 'ट्रेविस हेड (SRH)', runs: 567, matches: 14, avg: 43.61, sr: 191.5 }
];

export const PURPLE_CAP_LEADERS = [
  { player: 'जसप्रीत बुमराह (MI)', wickets: 24, overs: 54.0, econ: 6.48, avg: 14.5 },
  { player: 'हर्षल पटेल (PBKS)', wickets: 24, overs: 49.0, econ: 9.73, avg: 19.8 },
  { player: 'वरुण चक्रवर्ती (KKR)', wickets: 21, overs: 50.0, econ: 8.04, avg: 19.1 }
];

export const INITIAL_VIDEOS: VideoItem[] = [
  {
    id: 'vid-1',
    titleHi: 'IND vs AUS: हार्दिक पांड्या और सूर्यकुमार यादव की मैच जिताऊ पारी के खास मोमेंट्स',
    titleEn: 'IND vs AUS: Highlights of Hardik & Suryakumar Game-Winning Partnership',
    thumbnail: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=600&q=80',
    youtubeId: 'kJQP7kiw5Fk', // cricket highlights clip placeholder
    duration: '09:42',
    category: 'Match Highlights',
    publishedAt: '2 घंटे पहले',
    views: '1.4M views'
  },
  {
    id: 'vid-2',
    titleHi: 'रणजी ट्रॉफी फाइनल विनिंग मोमेंट्स: मुंबई के ड्रेसिंग रूम का सेलिब्रेशन और ट्रॉफी प्रेजेंटेशन',
    titleEn: 'Ranji Trophy Trophy Presentation & Mumbai Dressing Room Celebration',
    thumbnail: 'https://images.unsplash.com/photo-1589487391730-58f20eb2c308?auto=format&fit=crop&w=600&q=80',
    youtubeId: 'L_LUpnjgPso',
    duration: '06:15',
    category: 'Domestic',
    publishedAt: '5 घंटे पहले',
    views: '620K views'
  },
  {
    id: 'vid-3',
    titleHi: 'रोहित शर्मा की प्रेस कॉन्फ्रेंस: T20 वर्ल्ड कप जीत के बाद नए युवाओं के चयन पर क्या कहा?',
    titleEn: 'Rohit Sharma Press Conference on Transition and Team Future',
    thumbnail: 'https://images.unsplash.com/photo-1531415074868-036b107e775a?auto=format&fit=crop&w=600&q=80',
    youtubeId: 'kJQP7kiw5Fk',
    duration: '14:20',
    category: 'Press Conference',
    publishedAt: '12 घंटे पहले',
    views: '890K views'
  },
  {
    id: 'vid-4',
    titleHi: 'यशस्वी जायसवाल के 16 छक्के: विजय हजारे ट्रॉफी में 204 रनों की ऐतिहासिक आतिशी पारी',
    titleEn: 'Yashasvi Jaiswal 16 Towering Sixes in Historic 204 Vijay Hazare Knock',
    thumbnail: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=600&q=80',
    youtubeId: 'kJQP7kiw5Fk',
    duration: '08:05',
    category: 'Special Innings',
    publishedAt: '1 दिन पहले',
    views: '2.1M views'
  }
];

export const INITIAL_NOTIFICATIONS: PushNotification[] = [
  {
    id: 'notif-1',
    title: '🚨 ब्रेकिंग न्यूज़: टीम इंडिया का नया रोडमैप घोषित',
    body: 'रोहित शर्मा और विराट कोहली ने घरेलू प्रदर्शन को राष्ट्रीय टीम चयन का मुख्य आधार बनाया।',
    time: '25 मिनट पहले',
    isRead: false,
    type: 'breaking',
    articleId: 'news-1'
  },
  {
    id: 'notif-2',
    title: '🏏 लाइव स्कोर अपडेट: IND vs AUS',
    body: 'भारत को जीत के लिए केवल 2 रनों की दरकार, सूर्यकुमार 68* पर क्रीज पर!',
    time: '5 मिनट पहले',
    isRead: false,
    type: 'match'
  },
  {
    id: 'notif-3',
    title: '🏆 रणजी ट्रॉफी 2026: मुंबई बनी चैंपियन',
    body: 'विदर्भ को 140 रनों से हराकर मुंबई ने 42वीं बार खिताब जीता।',
    time: '2 घंटे पहले',
    isRead: true,
    type: 'breaking',
    articleId: 'news-2'
  }
];
