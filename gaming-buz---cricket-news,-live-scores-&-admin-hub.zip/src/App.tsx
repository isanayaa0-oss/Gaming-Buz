import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeLanguageProvider, useThemeLanguage } from './context/ThemeLanguageContext';
import { Header } from './components/Header';
import { CategoryNav } from './components/CategoryNav';
import { LiveScoreTicker } from './components/LiveScoreTicker';
import { FeaturedHero } from './components/FeaturedHero';
import { NewsCard } from './components/NewsCard';
import { ArticleModal } from './components/ArticleModal';
import { MatchCenterModal } from './components/MatchCenterModal';
import { DomesticHub } from './components/DomesticHub';
import { IPLHub } from './components/IPLHub';
import { TeamIndiaHub } from './components/TeamIndiaHub';
import { InternationalHub } from './components/InternationalHub';
import { VideosSection } from './components/VideosSection';
import { AdminDashboard } from './components/AdminDashboard';
import { SearchModal } from './components/SearchModal';
import { BookmarksDrawer } from './components/BookmarksDrawer';
import { NotificationsModal } from './components/NotificationsModal';
import { AuthModal } from './components/AuthModal';
import { AdMobBanner } from './components/AdMobBanner';
import { StaticPages } from './components/StaticPages';
import { AndroidDeviceFrame } from './components/AndroidDeviceFrame';
import { AndroidSourceExportModal } from './components/AndroidSourceExportModal';
import { api, initializeLocalStorage } from './services/api';
import { Category, NewsItem, CricketMatch, VideoItem, PushNotification } from './types';
import { 
  Flame, 
  Radio, 
  ArrowRight, 
  ShieldCheck, 
  Globe, 
  Heart, 
  Share2, 
  Smartphone,
  Info,
  Calendar,
  RefreshCw
} from 'lucide-react';

function GamingBuzApp() {
  const { isDarkMode, language, t } = useThemeLanguage();
  const { user, isAdmin, token, openAuthModal } = useAuth();

  // Navigation State
  const [activeCategory, setActiveCategory] = useState<Category>('all');
  const [isAdminActive, setIsAdminActive] = useState<boolean>(false);

  // Data State
  const [newsList, setNewsList] = useState<NewsItem[]>([]);
  const [matches, setMatches] = useState<CricketMatch[]>([]);
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [notifications, setNotifications] = useState<PushNotification[]>([]);
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Modals & Drawers
  const [selectedArticle, setSelectedArticle] = useState<NewsItem | null>(null);
  const [selectedMatch, setSelectedMatch] = useState<CricketMatch | null>(null);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isBookmarksOpen, setIsBookmarksOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [staticPage, setStaticPage] = useState<'about' | 'privacy' | 'terms' | 'contact' | null>(null);

  // Initial Load
  useEffect(() => {
    initializeLocalStorage();
    loadAllData();
    setBookmarks(api.getBookmarks());
  }, []);

  const loadAllData = async () => {
    setIsRefreshing(true);
    try {
      const [fetchedNews, fetchedMatches, fetchedVideos, fetchedNotifs] = await Promise.all([
        api.getNews(),
        api.getMatches(),
        api.getVideos(),
        api.getNotifications()
      ]);
      setNewsList(fetchedNews);
      setMatches(fetchedMatches);
      setVideos(fetchedVideos);
      setNotifications(fetchedNotifs);
    } catch {
      // error handling
    } finally {
      setIsRefreshing(false);
    }
  };

  // Toggle Bookmark
  const handleToggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    api.toggleBookmark(id);
    setBookmarks(api.getBookmarks());
  };

  // Share Article
  const handleShare = (news: NewsItem, e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.share) {
      navigator.share({
        title: t(news.titleHi, news.titleEn),
        text: t(news.summaryHi, news.summaryEn),
        url: window.location.href
      }).catch(() => {});
    } else {
      const shareText = encodeURIComponent(`${t(news.titleHi, news.titleEn)}\n\n${window.location.href}`);
      window.open(`https://api.whatsapp.com/send?text=${shareText}`, '_blank');
    }
  };

  // Admin CRUD Handlers
  const handleAddNews = async (item: Omit<NewsItem, 'id' | 'publishedAt' | 'views' | 'likes'>) => {
    const created = await api.createNews(item, token || undefined);
    setNewsList(prev => [created, ...prev]);
    return created;
  };

  const handleUpdateNews = async (id: string, updates: Partial<NewsItem>) => {
    const updated = await api.updateNews(id, updates, token || undefined);
    setNewsList(prev => prev.map(n => n.id === id ? updated : n));
    return updated;
  };

  const handleDeleteNews = async (id: string) => {
    await api.deleteNews(id, token || undefined);
    setNewsList(prev => prev.filter(n => n.id !== id));
    return true;
  };

  const handleAddVideo = async (vid: Omit<VideoItem, 'id' | 'views'>) => {
    const created = await api.createVideo(vid, token || undefined);
    setVideos(prev => [created, ...prev]);
    return created;
  };

  const handleBroadcastNotif = async (notif: { title: string; body: string; type: 'breaking' | 'match' | 'system'; articleId?: string }) => {
    const created = await api.broadcastNotification(notif, token || undefined);
    setNotifications(prev => [created, ...prev]);
    return created;
  };

  const handleMarkAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  // Unread notification count
  const unreadNotifsCount = notifications.filter(n => !n.isRead).length;

  // Filtered views
  const featuredArticle = newsList.find(n => n.isFeatured) || newsList[0];
  const breakingArticles = newsList.filter(n => n.isBreaking);
  const latestArticles = newsList.filter(n => n.id !== featuredArticle?.id);

  return (
    <div className={`min-h-screen transition-colors duration-200 ${
      isDarkMode ? 'bg-gray-950 text-gray-100' : 'bg-gray-50 text-gray-900'
    }`}>
      {/* Universal Android Device Frame (or full responsive container) */}
      <AndroidDeviceFrame>
        {/* Header App Bar */}
        <Header
          onOpenSearch={() => setIsSearchOpen(true)}
          onOpenBookmarks={() => setIsBookmarksOpen(true)}
          onOpenNotifications={() => setIsNotificationsOpen(true)}
          onOpenExportModal={() => setIsExportModalOpen(true)}
          unreadNotifsCount={unreadNotifsCount}
        />

        {/* Live Score Strip */}
        <LiveScoreTicker
          matches={matches}
          onSelectMatch={(m) => setSelectedMatch(m)}
          onRefresh={loadAllData}
          isRefreshing={isRefreshing}
        />

        {/* Categories Navigation Bar */}
        <CategoryNav
          activeCategory={activeCategory}
          onSelectCategory={(cat) => {
            setActiveCategory(cat);
            setIsAdminActive(false);
          }}
          showAdminTab={true}
          onSelectAdmin={() => {
            setIsAdminActive(true);
          }}
          isAdminActive={isAdminActive}
        />

        {/* Main View Container */}
        <main className="max-w-7xl mx-auto px-4 py-6">
          {/* 1. ADMIN DASHBOARD VIEW (Option C) */}
          {isAdminActive ? (
            <AdminDashboard
              newsList={newsList}
              onAddNews={handleAddNews}
              onUpdateNews={handleUpdateNews}
              onDeleteNews={handleDeleteNews}
              onAddVideo={handleAddVideo}
              onBroadcastNotif={handleBroadcastNotif}
              onBackToApp={() => setIsAdminActive(false)}
            />
          ) : activeCategory === 'domestic' ? (
            /* 2. DEDICATED DOMESTIC CRICKET HUB */
            <DomesticHub
              newsList={newsList}
              onSelectNews={(n) => setSelectedArticle(n)}
              bookmarks={bookmarks}
              onToggleBookmark={handleToggleBookmark}
              onShare={handleShare}
            />
          ) : activeCategory === 'ipl' ? (
            /* 3. IPL 2026 HUB */
            <IPLHub
              newsList={newsList}
              onSelectNews={(n) => setSelectedArticle(n)}
              bookmarks={bookmarks}
              onToggleBookmark={handleToggleBookmark}
              onShare={handleShare}
            />
          ) : activeCategory === 'team_india' ? (
            /* 4. TEAM INDIA HUB */
            <TeamIndiaHub
              newsList={newsList}
              matchesList={matches}
              onSelectNews={(n) => setSelectedArticle(n)}
              bookmarks={bookmarks}
              onToggleBookmark={handleToggleBookmark}
              onShare={handleShare}
            />
          ) : activeCategory === 'international' ? (
            /* 5. INTERNATIONAL CRICKET HUB */
            <InternationalHub
              newsList={newsList}
              onSelectNews={(n) => setSelectedArticle(n)}
              bookmarks={bookmarks}
              onToggleBookmark={handleToggleBookmark}
              onShare={handleShare}
            />
          ) : activeCategory === 'videos' ? (
            /* 6. CRICKET VIDEOS SECTION */
            <VideosSection videos={videos} />
          ) : activeCategory === 'live_matches' ? (
            /* 7. LIVE MATCHES FULL VIEW */
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-black flex items-center gap-2">
                  <Radio className="w-6 h-6 text-red-600 animate-pulse" />
                  <span>{t('सभी क्रिकेट मैच व लाइव स्कोर', 'All Cricket Matches & Live Scores')}</span>
                </h2>
                <button
                  onClick={loadAllData}
                  className="text-xs font-bold px-3 py-1.5 rounded-lg border flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                  <span>{t('ताजा करें', 'Refresh')}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {matches.map(m => (
                  <div
                    key={m.id}
                    onClick={() => setSelectedMatch(m)}
                    className={`p-4 rounded-3xl border cursor-pointer hover:border-emerald-500 transition-all ${
                      isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200 shadow-xs'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                      <span className="font-bold">{m.series}</span>
                      <span className="font-mono text-emerald-600 font-bold">{m.matchType}</span>
                    </div>

                    <div className="flex items-center justify-between my-2">
                      <span className="font-bold text-base flex items-center gap-2">
                        <span>{m.team1.flag}</span>
                        <span>{t(m.team1.nameHi, m.team1.nameEn)}</span>
                      </span>
                      <span className="font-black text-lg">{m.team1.score || '-'}</span>
                    </div>

                    <div className="flex items-center justify-between my-2">
                      <span className="font-bold text-base flex items-center gap-2">
                        <span>{m.team2.flag}</span>
                        <span>{t(m.team2.nameHi, m.team2.nameEn)}</span>
                      </span>
                      <span className="font-black text-lg">{m.team2.score || '-'}</span>
                    </div>

                    <div className="mt-3 pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between text-xs">
                      <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                        {t(m.statusTextHi, m.statusTextEn)}
                      </span>
                      <span className="text-gray-400">{t(m.venueHi, m.venueEn)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* 8. DEFAULT HOMEPAGE VIEW (White Theme default) */
            <div className="space-y-8">
              {/* Breaking News Flash Ticker */}
              {breakingArticles.length > 0 && (
                <div className={`p-3 rounded-2xl border flex items-center gap-3 overflow-hidden ${
                  isDarkMode ? 'bg-red-950/30 border-red-900/60 text-red-200' : 'bg-red-50 border-red-200 text-red-900'
                }`}>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-red-600 text-white shrink-0 flex items-center gap-1 animate-pulse">
                    <Flame className="w-3 h-3" />
                    {t('फ्लैश न्यूज़', 'FLASH NEWS')}
                  </span>
                  <div 
                    onClick={() => setSelectedArticle(breakingArticles[0])}
                    className="font-bold text-xs sm:text-sm truncate cursor-pointer hover:underline flex-1"
                  >
                    {t(breakingArticles[0].titleHi, breakingArticles[0].titleEn)}
                  </div>
                  <ArrowRight className="w-4 h-4 shrink-0 text-red-500" />
                </div>
              )}

              {/* Big Featured Hero Article */}
              {featuredArticle && (
                <FeaturedHero
                  news={featuredArticle}
                  onSelect={(n) => setSelectedArticle(n)}
                  isBookmarked={bookmarks.includes(featuredArticle.id)}
                  onToggleBookmark={handleToggleBookmark}
                  onShare={handleShare}
                />
              )}

              {/* Latest News Feed (ताजा खबरें) */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl sm:text-2xl font-black flex items-center gap-2">
                    <span className="w-2.5 h-6 bg-emerald-600 rounded-full inline-block"></span>
                    <span>{t('ताजा क्रिकेट समाचार (Latest News)', 'Latest Cricket Stories')}</span>
                  </h3>
                  <span className="text-xs text-gray-400 font-medium">
                    {t('लगातार अपडेटेड', 'Updated continuously')}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {latestArticles.map(item => (
                    <NewsCard
                      key={item.id}
                      news={item}
                      onSelect={(n) => setSelectedArticle(n)}
                      isBookmarked={bookmarks.includes(item.id)}
                      onToggleBookmark={handleToggleBookmark}
                      onShare={handleShare}
                    />
                  ))}
                </div>
              </div>

              {/* AdMob Banner Slot (AdMob Compliance) */}
              <AdMobBanner placement="home_feed" />

              {/* Domestic Cricket Spotlight Section */}
              <div className={`p-6 sm:p-8 rounded-3xl border ${
                isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-linear-to-br from-emerald-50 via-teal-50 to-white border-emerald-100 shadow-sm'
              }`}>
                <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                  <div>
                    <span className="text-xs font-black uppercase text-emerald-600 block">
                      {t('विशेष घरेलू क्रिकेट अनुभाग', 'DOMESTIC SPOTLIGHT')}
                    </span>
                    <h3 className="text-xl font-extrabold mt-0.5">
                      {t('रणजी, विजय हजारे व सैयद मुश्ताक अली ट्रॉफी', 'Ranji, Vijay Hazare & SMAT')}
                    </h3>
                  </div>
                  <button
                    onClick={() => setActiveCategory('domestic')}
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 text-white hover:bg-emerald-700 transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <span>{t('घरेलू हब खोलें', 'Open Domestic Hub')}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {newsList.filter(n => n.category === 'domestic').slice(0, 2).map(item => (
                    <div
                      key={item.id}
                      onClick={() => setSelectedArticle(item)}
                      className={`p-3.5 rounded-2xl border flex items-center gap-3 cursor-pointer hover:border-emerald-500 transition-all ${
                        isDarkMode ? 'bg-gray-800/40 border-gray-800' : 'bg-white border-gray-200'
                      }`}
                    >
                      <img src={item.imageUrl} alt="" className="w-20 h-20 rounded-xl object-cover shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="text-[10px] font-bold text-emerald-600 block uppercase">
                          {item.subCategory}
                        </span>
                        <h4 className="font-bold text-xs sm:text-sm line-clamp-2 leading-snug">
                          {t(item.titleHi, item.titleEn)}
                        </h4>
                        <span className="text-[10px] text-gray-400 mt-1 block">
                          {item.author}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Cricket Videos Reel */}
              <VideosSection videos={videos} />
            </div>
          )}
        </main>

        {/* Footer */}
        <footer className={`mt-16 border-t transition-colors ${
          isDarkMode ? 'bg-gray-950 border-gray-800 text-gray-400' : 'bg-white border-gray-200 text-gray-600'
        }`}>
          <div className="max-w-7xl mx-auto px-4 py-10">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {/* Brand Info */}
              <div className="md:col-span-2">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold">
                    🏏
                  </div>
                  <span className="font-extrabold text-xl tracking-tight text-gray-900 dark:text-white">
                    GAMING BUZ
                  </span>
                </div>
                <p className="text-xs leading-relaxed max-w-sm">
                  {t(
                    'GAMING BUZ भारत का अग्रणी हिंदी क्रिकेट न्यूज़ ऐप है। हम लाइव स्कोर, घरेलू क्रिकेट, टीम इंडिया और आईपीएल की प्रामाणिक व निष्पक्ष खबरें आप तक पहुँचाते हैं।',
                    'GAMING BUZ is a leading cricket digital destination featuring Live match scores, Domestic tournaments, Team India and IPL coverage.'
                  )}
                </p>
              </div>

              {/* Quick Links */}
              <div>
                <h4 className="font-bold text-xs uppercase tracking-wider text-gray-900 dark:text-white mb-3">
                  {t('प्रमुख अनुभाग', 'Sections')}
                </h4>
                <ul className="text-xs space-y-2">
                  <li>
                    <button onClick={() => { setActiveCategory('all'); setIsAdminActive(false); }} className="hover:text-emerald-600 cursor-pointer">
                      {t('🏠 होमपेज', 'Home')}
                    </button>
                  </li>
                  <li>
                    <button onClick={() => { setActiveCategory('team_india'); setIsAdminActive(false); }} className="hover:text-emerald-600 cursor-pointer">
                      {t('🇮🇳 टीम इंडिया', 'Team India')}
                    </button>
                  </li>
                  <li>
                    <button onClick={() => { setActiveCategory('domestic'); setIsAdminActive(false); }} className="hover:text-emerald-600 cursor-pointer">
                      {t('🏏 घरेलू क्रिकेट (रणजी/हजारे)', 'Domestic Cricket')}
                    </button>
                  </li>
                  <li>
                    <button onClick={() => { setActiveCategory('ipl'); setIsAdminActive(false); }} className="hover:text-emerald-600 cursor-pointer">
                      {t('🏆 IPL 2026', 'IPL 2026')}
                    </button>
                  </li>
                  <li>
                    <button onClick={() => setIsAdminActive(true)} className="hover:text-amber-600 font-bold cursor-pointer text-amber-600">
                      {t('🖥️ एडमिन डैशबोर्ड (Option C)', 'Admin Dashboard')}
                    </button>
                  </li>
                </ul>
              </div>

              {/* Policy & Legal Pages */}
              <div>
                <h4 className="font-bold text-xs uppercase tracking-wider text-gray-900 dark:text-white mb-3">
                  {t('कानूनी व नीतियां', 'Policies & Legal')}
                </h4>
                <ul className="text-xs space-y-2">
                  <li>
                    <button onClick={() => setStaticPage('about')} className="hover:text-emerald-600 cursor-pointer">
                      {t('हमारे बारे में (About Us)', 'About Us')}
                    </button>
                  </li>
                  <li>
                    <button onClick={() => setStaticPage('privacy')} className="hover:text-emerald-600 cursor-pointer">
                      {t('गोपनीयता नीति (Privacy Policy)', 'Privacy Policy')}
                    </button>
                  </li>
                  <li>
                    <button onClick={() => setStaticPage('terms')} className="hover:text-emerald-600 cursor-pointer">
                      {t('नियम व शर्तें (Terms of Service)', 'Terms of Service')}
                    </button>
                  </li>
                  <li>
                    <button onClick={() => setStaticPage('contact')} className="hover:text-emerald-600 cursor-pointer">
                      {t('संपर्क करें (Contact Us)', 'Contact Us')}
                    </button>
                  </li>
                </ul>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between flex-wrap gap-2 text-xs">
              <p>© 2026 GAMING BUZ. सर्वाधिकार सुरक्षित (All Rights Reserved).</p>
              <div className="flex items-center gap-3">
                <span className="text-emerald-600 font-semibold">
                  {t('सफेद थीम (White Theme) व डार्क मोड समर्थित', 'Light & Dark Mode Enabled')}
                </span>
              </div>
            </div>
          </div>
        </footer>

        {/* Global Modals */}
        <ArticleModal
          news={selectedArticle}
          onClose={() => setSelectedArticle(null)}
          isBookmarked={selectedArticle ? bookmarks.includes(selectedArticle.id) : false}
          onToggleBookmark={handleToggleBookmark}
          onSelectRelated={(r) => setSelectedArticle(r)}
          allNews={newsList}
        />

        <MatchCenterModal
          match={selectedMatch}
          onClose={() => setSelectedMatch(null)}
        />

        <SearchModal
          isOpen={isSearchOpen}
          onClose={() => setIsSearchOpen(false)}
          newsList={newsList}
          onSelectNews={(n) => setSelectedArticle(n)}
        />

        <BookmarksDrawer
          isOpen={isBookmarksOpen}
          onClose={() => setIsBookmarksOpen(false)}
          bookmarks={bookmarks}
          allNews={newsList}
          onSelectNews={(n) => setSelectedArticle(n)}
          onRemoveBookmark={(id) => {
            api.toggleBookmark(id);
            setBookmarks(api.getBookmarks());
          }}
        />

        <NotificationsModal
          isOpen={isNotificationsOpen}
          onClose={() => setIsNotificationsOpen(false)}
          notifications={notifications}
          onSelectArticle={(articleId) => {
            const found = newsList.find(n => n.id === articleId);
            if (found) setSelectedArticle(found);
          }}
          onMarkAllAsRead={handleMarkAllRead}
        />

        <AuthModal />

        <AndroidSourceExportModal
          isOpen={isExportModalOpen}
          onClose={() => setIsExportModalOpen(false)}
        />

        {staticPage && (
          <StaticPages
            initialPage={staticPage}
            onClose={() => setStaticPage(null)}
          />
        )}
      </AndroidDeviceFrame>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ThemeLanguageProvider>
        <GamingBuzApp />
      </ThemeLanguageProvider>
    </AuthProvider>
  );
}
